# Lovable workspace instructions

Upload this ZIP in Lovable at **Workspace settings → Skills → Add → Upload ZIP**.

Skill name: `i18n-key-parity`
Role: Translator Agent for {{YOUR_COMPANY}}
Tagline: Context-aware localization for UI strings, docs & marketing copy

When the skill is on:

- Follow `skills/i18n-key-parity/SKILL.md`.
- Read `context/business-profile.md` first.
- Use `scripts/verify_i18n_keys.py` for the deterministic check. It supports `--help` and `--dry-run`.
- Replace placeholders with `python3 setup_workspace.py --help` before production drafts.
- Treat {{YOUR_MCP_SERVER_URL}} as optional and owner-supplied.
- Produce drafts. Do not send email, post publicly, spend money, or delete records from this skill.

Company: {{YOUR_COMPANY}}
Domain: {{YOUR_DOMAIN}}
Support: {{YOUR_SUPPORT_EMAIL}}
Owner: {{YOUR_OWNER_NAME}}
