# Sample

Run `python3 scripts/aging_ar_report.py --dry-run` from the package root.
Expected exit code: 0. Expected stdout: a JSON object with `dry_run` true.
