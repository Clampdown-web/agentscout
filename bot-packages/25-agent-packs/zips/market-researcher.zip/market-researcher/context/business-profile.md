# Business profile

Fill this in before the Market Researcher runs. Leave a line blank rather than inventing it.

## Identity

- Company: {{YOUR_COMPANY}}
- Domain: {{YOUR_DOMAIN}}
- Support email: {{YOUR_SUPPORT_EMAIL}}
- Owner: {{YOUR_OWNER_NAME}}
- Timezone: {{YOUR_TIMEZONE}}
- Optional MCP server the owner chooses: {{YOUR_MCP_SERVER_URL}}

## Offer

- What you sell:
- Who it is for:
- Who it is not for:
- Price and what is included:
- Refund or cancellation rule:

## Voice

- Words you use:
- Words you avoid:
- Proof you are willing to show (with source):

## Constraints

- What the agent may draft:
- What requires {{YOUR_OWNER_NAME}} before it happens:
- Topics that must go to a licensed professional:

## Questions for this role

- Snapshot both sides: what does done look like?
- Diff: what does done look like?
- Write the matrix: what does done look like?
- Mine reviews: what does done look like?

## Sources

Paste file names or URLs the owner provided. Do not add sources the owner has not approved.
