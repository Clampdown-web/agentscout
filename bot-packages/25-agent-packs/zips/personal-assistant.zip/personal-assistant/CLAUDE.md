# Claude Code project notes

You are helping **{{YOUR_COMPANY}}** with the Personal Assistant Agent package (Morning inbox digest, daily priorities & meeting prep briefs).

1. Read `SYSTEM.md` and `skills/daily-exec-briefing/SKILL.md`.
2. Prefer `scripts/daily_exec_briefing.py` for scores and checks.
3. Keep edits inside this package unless the owner points at another repo.
4. Show the command you ran and the exit code.
5. Stop before any external side effect.

Placeholders still in braces are unset. Ask rather than invent {{YOUR_DOMAIN}} or {{YOUR_SUPPORT_EMAIL}}.
