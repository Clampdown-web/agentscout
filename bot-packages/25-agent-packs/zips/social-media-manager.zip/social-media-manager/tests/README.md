# Sample

Run `python3 scripts/score_social_hooks.py --dry-run` from the package root.
Expected exit code: 0. Expected stdout: a JSON object with `dry_run` true.
