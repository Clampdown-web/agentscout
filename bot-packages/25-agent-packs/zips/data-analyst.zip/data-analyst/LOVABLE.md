# Lovable workspace instructions

Upload this ZIP in Lovable at **Workspace settings → Skills → Add → Upload ZIP**.

Skill name: `kpi-csv-analyst`
Role: Data Analyst for {{YOUR_COMPANY}}
Tagline: Weekly reports and insights

When the skill is on:

- Follow `skills/kpi-csv-analyst/SKILL.md`.
- Read `context/business-profile.md` first.
- Use `scripts/analyze_kpi_csv.py` for the deterministic check. It supports `--help`, `--self-test`, and `--dry-run`.
- Replace placeholders with `python3 scripts/setup_workspace.py --help` before production drafts.
- Treat {{YOUR_MCP_SERVER_URL}} as optional and owner-supplied.
- Produce drafts. Do not send email, post publicly, spend money, or delete records from this skill.

Company: {{YOUR_COMPANY}}
Domain: {{YOUR_DOMAIN}}
Support: {{YOUR_SUPPORT_EMAIL}}
Owner: {{YOUR_OWNER_NAME}}
