---
name: multi-agent-team-dispatch-and-release
description: 4. AgentScout CEO Coordinator Bot (Built by AgentScout) — step-by-step operational workflow and verification playbook.
---

<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-7169B67F3F1CBD0B22F446BD | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

<p align="left"><b>Pre-Trained Pro Bot built by</b> <a href="https://agentscouthq.com"><picture><source media="(prefers-color-scheme: dark)" srcset="../../assets/logo-wordmark-dark.svg"><img src="../../assets/logo-wordmark.svg" alt="AgentScout" width="168" height="32" style="vertical-align:middle"></picture></a></p>

# Multi-Agent Team Dispatch, Build Verification & Release Protocol

Follow this sequence whenever shipping a site, feed, or product change:
1. Update the generator scripts and run the full build (`build_site.py`).
2. Run automated verification (`check_overflow.py` at `360px`/`390px` 1x & 1.3x, `check_relevance.py`, and `verify_4tier_ctas.py`).
3. Commit and push to `origin/main`, then post the commit hash in Work Chat so **AgentScout Operations / Monitoring Bot** and **AgentScout SEO & AEO Growth Auditor Bot** can run live post-deploy checks.
