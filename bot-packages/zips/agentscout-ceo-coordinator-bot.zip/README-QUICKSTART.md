<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-7169B67F3F1CBD0B22F446BD | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

<p align="left"><b>Pre-Trained Pro Bot built by</b> <a href="https://agentscouthq.com"><picture><source media="(prefers-color-scheme: dark)" srcset="assets/logo-wordmark-dark.svg"><img src="assets/logo-wordmark.svg" alt="AgentScout" width="168" height="32" style="vertical-align:middle"></picture></a></p>

# 4. AgentScout CEO Coordinator Bot (Built by AgentScout) — 5-Minute Quickstart Guide

- **Package Price:** $69 one-time (Sold Separately)
- **Theme Accent:** Neon Crimson Red (#ef4444)
- **Licensed Buyer:** `UNASSIGNED-STOCK-BUILD@agentscouthq.com` (`Order #STOCK-MASTER-20261028` · Fingerprint `AS-7169B67F3F1CBD0B22F446BD`)
- **Custom MCP Config Template:** `mcp.json` (`{YOUR_MCP_SERVER_URL}`)

## What's Inside This 100% Original AgentScout Package
1. `SYSTEM.md` — Complete role instructions, safety guardrails, and output formatting rules.
2. `routines/routines.json` — Ready-to-enable cron schedules and prompts.
3. `skills/multi-agent-team-dispatch-and-release/SKILL.md` — Reusable step-by-step operational playbook.
4. `scripts/handoff_coordinator.py` — Standalone Python 3 automation script (zero paid third-party libraries required).
5. `handoff/AGENTSCOUT-BOT-BRIEFING.md` — Shared multi-agent handoff protocol so this bot coordinates seamlessly with the rest of the AgentScout Pro Bot lineup.
6. `LICENSE.txt` & `WATERMARK.json` — Single-Organization Commercial License and buyer order verification metadata.

## Step-by-Step Setup & Usage Instructions (By Platform)

### Option A — Grok Bot (Native Turnkey Setup · Recommended)
1. **Create or open your bot:** In Grok Bot, create a new teammate (or open an existing one) and paste the contents of `SYSTEM.md` into its **Description / Instructions** (`UpdateProfile`).
2. **Copy workspace files to `/workspace`:**
   ```bash
   mkdir -p /workspace/scripts /workspace/handoff /workspace/skills/multi-agent-team-dispatch-and-release
   cp scripts/*.py /workspace/scripts/
   cp handoff/*.md /workspace/handoff/
   cp skills/multi-agent-team-dispatch-and-release/SKILL.md /workspace/skills/multi-agent-team-dispatch-and-release/SKILL.md
   ```
3. **Enable Scheduled Cron Routines:** Ask your Grok Bot: *"Read `routines/routines.json` and create each routine with `UpdateRoutine` in my local timezone."*
4. **Optional Custom MCP Server (`mcp.json`):** Point `{YOUR_MCP_SERVER_URL}` in `mcp.json` to your own internal MCP server if your business uses one.

### Option B — Claude Code (`CLAUDE.md` + `.claude/skills/`)
1. Copy `SYSTEM.md` to your project root as `CLAUDE.md` (or append it to your existing `CLAUDE.md`).
2. Copy `skills/` into `.claude/skills/` and `scripts/` + `handoff/` into your workspace root.
3. Optionally merge `mcp.json` into `~/.claude.json` or `.mcp.json` after setting `{YOUR_MCP_SERVER_URL}` to your own MCP server.

### Option C — Cursor (`.cursor/rules/` + `.cursor/mcp.json`)
1. Copy `SYSTEM.md` into `.cursor/rules/agentscout-bot.mdc` and `skills/` into `.cursor/skills/`.
2. Copy `mcp.json` to `.cursor/mcp.json` and `scripts/*.py` into `scripts/`.

### Option D — OpenAI Codex CLI (`AGENTS.md`)
1. Copy `SYSTEM.md` to `AGENTS.md` in your repository root and place `scripts/` + `handoff/` alongside it.

## Placeholder Variables to Customize
Search and replace these 3 placeholders across `SYSTEM.md`, `handoff/*.md`, and `scripts/*.py`:
- `{{YOUR_DOMAIN}}` → your production domain (e.g. `example.com`)
- `{{YOUR_SUPPORT_EMAIL}}` → your support or operations inbox (e.g. `support@example.com`)
- `{{YOUR_OWNER_NAME}}` → your name or team handle

## First-Run Verification Command
Run the bundled script right now to verify everything works out of the box:
```bash
python3 scripts/handoff_coordinator.py
```
