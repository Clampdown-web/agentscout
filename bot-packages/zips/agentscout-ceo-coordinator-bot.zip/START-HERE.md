# START HERE: 4. AgentScout CEO Coordinator Bot (Built by AgentScout)

4. AgentScout CEO Coordinator Bot (Built by AgentScout). Use this folder for {{YOUR_COMPANY}} on {{YOUR_DOMAIN}}.

## What's inside

- `SYSTEM.md`, the role instructions
- `skills/multi-agent-team-dispatch-and-release/SKILL.md`
- `scripts/handoff_coordinator.py`
- `scripts/pre_deploy_qa.py`
- `README-QUICKSTART.md`
- `mcp.json`, an optional MCP server entry
- `setup_workspace.py`, which writes your company name and domain
- `routines/` (2 files)

## 10-minute setup

1. Import the template. In Grok Bot, create a teammate and paste SYSTEM.md into its instructions. In Lovable, import this ZIP under Workspace settings, then Skills, then Add, then Upload ZIP. Lovable reads SKILL.md. This folder also includes Claude Code (CLAUDE.md), Cursor (.cursorrules), Codex (AGENTS.md).
2. Replace {{YOUR_COMPANY}} and {{YOUR_DOMAIN}}. From the unzipped folder run `python3 setup_workspace.py --company "Your Company" --domain "yourdomain.com"`. That writes those two values through the package.
3. Connect tools. Open mcp.json and, if your company already runs an MCP server, put that server's URL in the entry. If you do not have one, leave the file unchanged. The file does not connect a tool by itself.
4. Run the first task. From the unzipped folder run `python3 scripts/handoff_coordinator.py`.

## What to expect on the first run

`python3 scripts/handoff_coordinator.py` prints a JSON list of the four bot roles and exits. It does not send email, post, or spend.

## Help

Questions about this download: support@agentscouthq.com
