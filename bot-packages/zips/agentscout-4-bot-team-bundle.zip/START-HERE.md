# START HERE: Full 4-Bot "Company-in-a-Box" Team Bundle (Built by AgentScout)

Full 4-Bot "Company-in-a-Box" Team Bundle (Built by AgentScout). Use this folder for {{YOUR_COMPANY}} on {{YOUR_DOMAIN}}.

## What's inside

- Bot folders: `01-ops-monitor-bot`, `02-seo-aeo-bot`, `03-competitive-intel-bot`, `04-ceo-coordinator-bot`
- `SYSTEM.md` in 4 folders, including `01-ops-monitor-bot/SYSTEM.md`
- 6 skill files, including `01-ops-monitor-bot/skills/ops-site-and-checkout-audit/SKILL.md`
- `01-ops-monitor-bot/scripts/daily_deep_audit.py`
- `01-ops-monitor-bot/scripts/verify_4tier_ctas.py`
- `02-seo-aeo-bot/scripts/audit_jsonld_and_llms.py`
- `02-seo-aeo-bot/scripts/check_seo_aeo.py`
- 5 more Python scripts under the bot folders
- `README-TEAM-BUNDLE.md`, the four-bot handoff notes
- `mcp.json`, an optional MCP server entry
- `setup_workspace.py`, which writes your company name and domain
- `routines/` (5 files)

## 10-minute setup

1. Import the template. In Grok Bot, create a teammate and paste SYSTEM.md into its instructions. In Lovable, import this ZIP under Workspace settings, then Skills, then Add, then Upload ZIP. Lovable reads SKILL.md. This folder also includes Claude Code (CLAUDE.md), Cursor (.cursorrules), Codex (AGENTS.md).
2. Replace {{YOUR_COMPANY}} and {{YOUR_DOMAIN}}. From the unzipped folder run `python3 setup_workspace.py --company "Your Company" --domain "yourdomain.com"`. That writes those two values through the package.
3. Connect tools. Open mcp.json and, if your company already runs an MCP server, put that server's URL in the entry. If you do not have one, leave the file unchanged. The file does not connect a tool by itself.
4. Run the first task. From the unzipped folder run `python3 01-ops-monitor-bot/scripts/daily_deep_audit.py`, `python3 02-seo-aeo-bot/scripts/check_seo_aeo.py`, `python3 03-competitive-intel-bot/scripts/outlier_scanner.py`, `python3 04-ceo-coordinator-bot/scripts/handoff_coordinator.py`.

## What to expect on the first run

If {{YOUR_DOMAIN}} is still unfilled, python3 01-ops-monitor-bot/scripts/daily_deep_audit.py prints a dry-run line and does not open a connection. After you replace {{YOUR_DOMAIN}}, it requests that site's homepage and prints a pass or a failure. It does not send email, post, or spend. `python3 02-seo-aeo-bot/scripts/check_seo_aeo.py` scans HTML files in that folder and prints how many JSON-LD blocks it found. An empty folder reports zero files. It does not send email, post, or spend. `python3 03-competitive-intel-bot/scripts/outlier_scanner.py` prints JSON from built-in sample posts. It does not post, send email, or spend. `python3 04-ceo-coordinator-bot/scripts/handoff_coordinator.py` prints a JSON list of the four bot roles and exits. It does not send email, post, or spend.

## Help

Questions about this download: support@agentscouthq.com
