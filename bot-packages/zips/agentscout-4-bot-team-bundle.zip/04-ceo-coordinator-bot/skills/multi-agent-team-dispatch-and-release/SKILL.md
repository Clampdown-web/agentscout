---
name: multi-agent-team-dispatch-and-release
description: 4. AgentScout CEO Coordinator Bot (Built by AgentScout) — step-by-step operational workflow and verification playbook.
---

<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261125 | Fingerprint: AS-BUNDLE-2FE5DDA2F36EF3EF2443 | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

<p align="left"><b>Pre-Trained Pro Bot built by</b> <a href="https://agentscouthq.com"><picture><source media="(prefers-color-scheme: dark)" srcset="../../../assets/logo-wordmark-dark.svg"><img src="../../../assets/logo-wordmark.svg" alt="AgentScout" width="168" height="32" style="vertical-align:middle"></picture></a></p>

# Multi-Agent Team Dispatch, Build Verification & Release Protocol

Follow this sequence whenever shipping a site, feed, or product change:
1. Update your generator/build scripts and run `python3 scripts/pre_deploy_qa.py`.
2. Preview-test all changed templates at phone (`360px`/`390px` portrait & `844x390` landscape at `1x` & `1.3x`) and desktop (`1280px`/`1440px`) sizes with 0px horizontal overflow and zero legacy SSE MCP links.
3. Merge only after green CI (at most one retry on any failed check/deploy), then trigger **Operations / Monitoring** and **SEO & AEO Growth Auditor** to re-verify live URLs after deploy.
