<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-BUNDLE-23F3104A69B3F6ED84FA | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

<p align="left"><b>Pre-Trained Pro Bot built by</b> <a href="https://agentscouthq.com"><picture><source media="(prefers-color-scheme: dark)" srcset="../assets/logo-wordmark-dark.svg"><img src="../assets/logo-wordmark.svg" alt="AgentScout" width="168" height="32" style="vertical-align:middle"></picture></a></p>

# 4. AgentScout CEO Coordinator Bot (Built by AgentScout) — Quickstart Guide

See `../README-TEAM-BUNDLE.md` for the full 4-bot team setup across Grok Bot, Claude Code, Cursor, and OpenAI Codex, or follow the standalone steps below:

1. Paste `SYSTEM.md` into your bot's instructions/profile (`CLAUDE.md`, `.cursor/rules/`, or `AGENTS.md`).
2. Copy `skills/multi-agent-team-dispatch-and-release/SKILL.md` into your skills directory and `scripts/handoff_coordinator.py` into `/workspace/scripts/`.
3. Replace `{{YOUR_DOMAIN}}` and `{{YOUR_SUPPORT_EMAIL}}`, import `../mcp.json`, and enable `routines/routines.json`.
4. Run `python3 scripts/handoff_coordinator.py` to verify.
