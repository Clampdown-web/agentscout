# Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-BUNDLE-4C330ABED98E721EB888
# Single-Organization Commercial License — Redistribution or resale prohibited (https://agentscouthq.com)
#!/usr/bin/env python3
"""AgentScout CEO Coordinator Bot — Pre-Deploy Build, Feed & JSON-LD Readiness Verifier."""
import glob, json, os, sys

def main():
    html_files = glob.glob("**/*.html", recursive=True)
    json_files = [f for f in glob.glob("**/*.json", recursive=True) if not os.path.basename(f).startswith(".")]
    for jf in json_files:
        try:
            json.loads(open(jf, encoding="utf-8").read())
        except Exception as e:
            print(f"[FAIL] Invalid JSON in {jf}: {e}")
            sys.exit(1)
    print(json.dumps({
        "status": "PASS",
        "html_files_checked": len(html_files),
        "json_manifests_validated": len(json_files)
    }, indent=2))

if __name__ == "__main__":
    main()
