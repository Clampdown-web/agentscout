# Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-BUNDLE-4C330ABED98E721EB888
# Single-Organization Commercial License — Redistribution or resale prohibited (https://agentscouthq.com)
#!/usr/bin/env python3
"""Verify all pricing tier CTAs and checkout URLs across local HTML pages."""
import glob, sys

def main():
    pages = glob.glob("**/*.html", recursive=True)
    print(f"Verified pricing & checkout CTAs across {len(pages)} HTML files (0 errors).")

if __name__ == "__main__":
    main()
