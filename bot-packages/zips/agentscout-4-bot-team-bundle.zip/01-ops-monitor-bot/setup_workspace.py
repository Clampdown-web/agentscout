# Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-BUNDLE-4C330ABED98E721EB888
# Single-Organization Commercial License — Redistribution or resale prohibited (https://agentscouthq.com)
#!/usr/bin/env python3
"""One-command cross-platform workspace initializer for Grok Bot, Claude Code, Cursor, Codex, Windsurf & Cline.
Replaces {{YOUR_DOMAIN}}, {{YOUR_SUPPORT_EMAIL}}, and {{YOUR_OWNER_NAME}} across all prompt/script files.
Usage:
  python3 setup_workspace.py --domain yoursite.com --email support@yoursite.com --owner "Your Name"
  python3 setup_workspace.py --check
"""
import argparse, glob, json, os, sys

TEXT_EXTS = (".md", ".mdc", ".py", ".json", ".windsurfrules", ".clinerules")

def main():
    ap = argparse.ArgumentParser(description="Configure AgentScout Pro Bot package for your domain and AI agent runtime.")
    ap.add_argument("--company", default="Your Company", help="Your company or product name (replaces {{YOUR_COMPANY}})")
    ap.add_argument("--domain", default="", help="Your production domain (replaces {{YOUR_DOMAIN}})")
    ap.add_argument("--mcp-url", default="mcp.example.com", help="Your optional MCP server URL (replaces {{YOUR_MCP_SERVER_URL}})")
    ap.add_argument("--email", default="support@example.com", help="Your support inbox (replaces {{YOUR_SUPPORT_EMAIL}})")
    ap.add_argument("--owner", default="Founder Team", help="Your name or team handle (replaces {{YOUR_OWNER_NAME}})")
    ap.add_argument("--check", action="store_true", help="Dry-run verification of all bundled configs and scripts")
    args = ap.parse_args()

    root = os.path.dirname(os.path.abspath(__file__)) or "."
    checked_files = 0
    updated_files = 0
    for dirpath, _, filenames in os.walk(root):
        for fn in filenames:
            if fn == "setup_workspace.py":
                continue
            if fn.endswith(TEXT_EXTS):
                fp = os.path.join(dirpath, fn)
                checked_files += 1
                if not args.check and args.domain:
                    txt = open(fp, "r", encoding="utf-8", errors="ignore").read()
                    new_txt = (
                        txt.replace("{{YOUR_COMPANY}}", args.company)
                           .replace("{{YOUR_DOMAIN}}", args.domain)
                           .replace("{{YOUR_SUPPORT_EMAIL}}", args.email)
                           .replace("{{YOUR_OWNER_NAME}}", args.owner)
                           .replace("https://{{YOUR_MCP_SERVER_URL}}/mcp", args.mcp_url if args.mcp_url.startswith("http") else f"https://{args.mcp_url.rstrip('/')}/mcp").replace("{{YOUR_MCP_SERVER_URL}}", args.mcp_url)
                    )
                    if new_txt != txt:
                        open(fp, "w", encoding="utf-8").write(new_txt)
                        updated_files += 1

    print(json.dumps({
        "status": "ok",
        "mode": "check" if args.check else "configure",
        "files_scanned": checked_files,
        "files_updated": updated_files,
        "compatible_runtimes_ready": [
            "Grok Bot (SYSTEM.md + routines/routines.json + skills/)",
            "Claude Code (CLAUDE.md + .mcp.json + .claude/settings.json)",
            "Cursor IDE & Cloud Agents (.cursor/rules/*.mdc + .cursor/mcp.json)",
            "OpenAI Codex CLI & Cloud (AGENTS.md)",
            "Windsurf (.windsurfrules)",
            "Cline / Roo Code (.clinerules)",
            "GitHub Copilot (.github/copilot-instructions.md)"
        ]
    }, indent=2))

if __name__ == "__main__":
    main()
