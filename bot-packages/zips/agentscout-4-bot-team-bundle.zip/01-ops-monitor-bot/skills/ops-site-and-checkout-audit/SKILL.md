---
name: ops-site-and-checkout-audit
description: 1. AgentScout Operations / Monitoring Bot (Built by AgentScout) — step-by-step operational workflow and verification playbook.
---

<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261125 | Fingerprint: AS-BUNDLE-2FE5DDA2F36EF3EF2443 | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

<p align="left"><b>Pre-Trained Pro Bot built by</b> <a href="https://agentscouthq.com"><picture><source media="(prefers-color-scheme: dark)" srcset="../../../assets/logo-wordmark-dark.svg"><img src="../../../assets/logo-wordmark.svg" alt="AgentScout" width="168" height="32" style="vertical-align:middle"></picture></a></p>

# Operations Site, 8-Viewport Overflow & Checkout Audit

Run this skill both in preview before merging/publishing and live after every production deployment:
1. Verify all core URLs return HTTP 200 in under 500ms and never reference legacy SSE MCP endpoints (always use Streamable HTTP `/mcp`).
2. Check phone (`360x800`, `390x844`, `844x390` landscape at `1x` and `1.3x` font scale), tablet (`768x1024`), and desktop (`1280x900`, `1440x900`) in light and dark themes; assert `document.documentElement.scrollWidth <= window.innerWidth`.
3. Validate `/api/products.json` and `/.well-known/acp.json` against active checkout links (`HTTP 200`, non-expired session).
4. Retry a failed check at most once, then stop and report.
