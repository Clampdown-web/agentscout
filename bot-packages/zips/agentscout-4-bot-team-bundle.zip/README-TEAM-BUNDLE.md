<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-BUNDLE-23F3104A69B3F6ED84FA | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

<p align="left"><b>Pre-Trained Pro Bot built by</b> <a href="https://agentscouthq.com"><picture><source media="(prefers-color-scheme: dark)" srcset="assets/logo-wordmark-dark.svg"><img src="assets/logo-wordmark.svg" alt="AgentScout" width="168" height="32" style="vertical-align:middle"></picture></a></p>

# Full 4-Bot "Company-in-a-Box" Team Bundle (Built by AgentScout)

- **Bundle Price:** $149 one-time (saves $77 vs. $226 separately)
- **Theme Accent:** Neon Mint-Emerald (`#10b981`)
- **Licensed Buyer:** `UNASSIGNED-STOCK-BUILD@agentscouthq.com` (`Order #STOCK-MASTER-20261028` · Fingerprint `AS-BUNDLE-23F3104A69B3F6ED84FA`)

## Included Bots (All 4 Pre-Wired Together)
1. `01-ops-monitor-bot/` — **1. AgentScout Operations / Monitoring Bot (`$39` value · Neon Lime)**
2. `02-seo-aeo-bot/` — **2. AgentScout SEO & AEO Growth Auditor Bot (`$59` value · Neon Electric Gold)**
3. `03-competitive-intel-bot/` — **3. AgentScout Market & Launch Intel Bot (`$59` value · Neon Sunset Orange)**
4. `04-ceo-coordinator-bot/` — **4. AgentScout CEO Coordinator Bot (`$69` value · Neon Crimson Red)**
5. `handoff/AGENTSCOUT-BOT-BRIEFING.md` — Shared multi-agent coordination & Work Chat handoff protocol.
6. `handoff/OPS-BOT-HANDOFF.md` — Operational runbook, standing rules, and inbox/audit checklist.
7. `mcp.json` — Generic MCP configuration template (`{YOUR_MCP_SERVER_URL}`) for your own business tools.

## Step-by-Step Team Setup Instructions (Grok Bot, Claude Code, Cursor & Codex)

### 1. Grok Bot 4-Bot "Company-in-a-Box" Setup (Recommended)
1. **Unpack shared computer files into `/workspace`:**
   ```bash
   mkdir -p /workspace/scripts /workspace/handoff
   cp handoff/*.md /workspace/handoff/
   cp 01-ops-monitor-bot/scripts/*.py 02-seo-aeo-bot/scripts/*.py 03-competitive-intel-bot/scripts/*.py 04-ceo-coordinator-bot/scripts/*.py /workspace/scripts/
   ```
2. **Create the 4 Teammates & Group Room (`Work Chat`):**
   - Create 4 teammates in Grok Bot (**CEO Coordinator**, **Operations / Monitoring**, **SEO & AEO Growth Auditor**, and **Market & Launch Intel**) and paste each folder's `SYSTEM.md` into that bot's profile description.
   - Add all 4 bots to a shared group chat named **`Work Chat`** so they coordinate handoffs automatically via `/workspace/handoff/AGENTSCOUT-BOT-BRIEFING.md`.
3. **Install Skills & Enable Routines:**
   - Copy each bot's `skills/<slug>/SKILL.md` into `/workspace/skills/<slug>/SKILL.md`.
   - Have each bot load its `routines/routines.json` via `UpdateRoutine`.

### 2. Claude Code / Cursor / OpenAI Codex Setup
- **Claude Code:** Copy any bot folder's `SYSTEM.md` to `CLAUDE.md`, copy `skills/` into `.claude/skills/`, and merge `mcp.json` into `.mcp.json`.
- **Cursor:** Copy `SYSTEM.md` into `.cursor/rules/`, `skills/` into `.cursor/skills/`, and `mcp.json` into `.cursor/mcp.json`.
- **OpenAI Codex:** Copy `SYSTEM.md` into `AGENTS.md` at your repo root.

### 3. Customize Placeholders & Run Your First Team Audit
Replace `{YOUR_DOMAIN}`, `{YOUR_SUPPORT_EMAIL}`, and `{YOUR_OWNER_NAME}` across `SYSTEM.md`, `handoff/*.md`, and `scripts/*.py`, then test all 4 bot pipelines:
```bash
python3 01-ops-monitor-bot/scripts/daily_deep_audit.py
python3 02-seo-aeo-bot/scripts/check_seo_aeo.py
python3 03-competitive-intel-bot/scripts/outlier_scanner.py
python3 04-ceo-coordinator-bot/scripts/handoff_coordinator.py
```
