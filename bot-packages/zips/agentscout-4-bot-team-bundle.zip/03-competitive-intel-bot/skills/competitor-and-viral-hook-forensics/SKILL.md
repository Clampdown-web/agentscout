---
name: competitor-and-viral-hook-forensics
description: 3. AgentScout Market & Launch Intel Bot (Built by AgentScout) — step-by-step operational workflow and verification playbook.
---

<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-BUNDLE-23F3104A69B3F6ED84FA | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

<p align="left"><b>Pre-Trained Pro Bot built by</b> <a href="https://agentscouthq.com"><picture><source media="(prefers-color-scheme: dark)" srcset="../../../assets/logo-wordmark-dark.svg"><img src="../../../assets/logo-wordmark.svg" alt="AgentScout" width="168" height="32" style="vertical-align:middle"></picture></a></p>

# Competitor Launch Radar & 5x X Outlier Hook Forensics

1. **Outlier Detection Rule:** A post qualifies as a true viral outlier when `impressions >= 5 * account_median_impressions` or `bookmark_rate >= 3%`.
2. **Hook Deconstruction:** Record (a) the opening 12 words, (b) the contrast/numbers pattern, (c) the native asset type (60fps MP4 terminal demo vs. annotated comparison graphic), and (d) the direct link + auto-plug structure in `HOOKS.md`.
