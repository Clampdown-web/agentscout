---
name: mention-and-buying-signal-watch
description: Scan X, Reddit, Hacker News, and Product Hunt for mentions, competitor launches, and high-intent buying signals.
---

<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-BUNDLE-23F3104A69B3F6ED84FA | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

# Mention & Buying-Signal Watch

1. Scan X, Reddit, Hacker News, and Product Hunt for high-intent buyer questions and competitor launches.
2. Score outlier posts (`>=5x` 21-day median impressions) and append winning hook formulas to `HOOKS.md`.
