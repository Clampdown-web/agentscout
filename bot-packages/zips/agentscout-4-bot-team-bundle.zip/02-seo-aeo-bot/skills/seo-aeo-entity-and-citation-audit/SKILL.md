---
name: seo-aeo-entity-and-citation-audit
description: 2. AgentScout SEO & AEO Growth Auditor Bot (Built by AgentScout) — step-by-step operational workflow and verification playbook.
---

<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-BUNDLE-4C330ABED98E721EB888 | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

<p align="left"><b>Pre-Trained Pro Bot built by</b> <a href="https://agentscouthq.com"><picture><source media="(prefers-color-scheme: dark)" srcset="../../../assets/logo-wordmark-dark.svg"><img src="../../../assets/logo-wordmark.svg" alt="AgentScout" width="168" height="32" style="vertical-align:middle"></picture></a></p>

# SEO & AEO Entity Graph, llms.txt & Citation Audit

Use this workflow to audit a site's readiness for both Google Search and LLM Answer Engines (ChatGPT Search, Perplexity, Claude, Grok):
1. Check `robots.txt` allows `GPTBot`, `OAI-SearchBot`, `ChatGPT-User`, `PerplexityBot`, `ClaudeBot`, `anthropic-ai`, and `Google-Extended`.
2. Verify `/llms.txt` and `/llms-full.txt` expose clean Markdown tables with direct canonical URLs, pricing, and last-verified dates.
3. Run `scripts/audit_jsonld_and_llms.py` to confirm zero broken JSON-LD blocks across the site.
