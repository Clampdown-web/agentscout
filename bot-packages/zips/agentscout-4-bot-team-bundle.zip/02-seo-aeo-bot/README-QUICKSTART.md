<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261125 | Fingerprint: AS-BUNDLE-2FE5DDA2F36EF3EF2443 | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

<p align="left"><b>Pre-Trained Pro Bot built by</b> <a href="https://agentscouthq.com"><picture><source media="(prefers-color-scheme: dark)" srcset="../assets/logo-wordmark-dark.svg"><img src="../assets/logo-wordmark.svg" alt="AgentScout" width="168" height="32" style="vertical-align:middle"></picture></a></p>

# 2. AgentScout SEO & AEO Growth Auditor Bot (Built by AgentScout) — Quickstart Guide

See `../README-TEAM-BUNDLE.md` for the full 4-bot team setup across Grok Bot, Claude Code, Cursor, and OpenAI Codex, or follow the standalone steps below:

1. Paste `SYSTEM.md` into your bot's instructions/profile (`CLAUDE.md`, `.cursor/rules/`, or `AGENTS.md`).
2. Copy `skills/seo-aeo-entity-and-citation-audit/SKILL.md` into your skills directory and `scripts/audit_jsonld_and_llms.py` into `scripts/`.
3. Replace `{{YOUR_DOMAIN}}` and `{{YOUR_SUPPORT_EMAIL}}`, import `../mcp.json`, and enable `routines/routines.json`.
4. Run `python3 scripts/audit_jsonld_and_llms.py` to verify.
