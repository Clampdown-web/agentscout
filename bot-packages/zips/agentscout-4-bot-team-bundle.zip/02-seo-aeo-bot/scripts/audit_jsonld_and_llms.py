# Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-BUNDLE-23F3104A69B3F6ED84FA
# Single-Organization Commercial License — Redistribution or resale prohibited (https://agentscouthq.com)
#!/usr/bin/env python3
"""AgentScout SEO & AEO Growth Auditor Bot — JSON-LD & llms.txt Verification Script."""
import glob, json, re, sys

def check_html_files(root="."):
    html_files = glob.glob(f"{root}/**/*.html", recursive=True)
    bad = []
    checked = 0
    for f in html_files:
        s = open(f, errors="ignore").read()
        for m in re.finditer(r'<script type="application/ld\+json">(.*?)</script>', s, re.S):
            checked += 1
            try:
                json.loads(m.group(1))
            except Exception as e:
                bad.append((f, str(e)))
    print(f"Checked {checked} JSON-LD blocks across {len(html_files)} HTML files; {len(bad)} errors.")
    if bad:
        for f, err in bad[:10]:
            print("  ERROR:", f, err)
        sys.exit(1)

if __name__ == "__main__":
    check_html_files(".")
