# Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-BUNDLE-23F3104A69B3F6ED84FA
# Single-Organization Commercial License — Redistribution or resale prohibited (https://agentscouthq.com)
#!/usr/bin/env python3
"""Check canonical tags, meta descriptions, and JSON-LD blocks across HTML pages."""
import glob, json, re, sys

def main():
    files = glob.glob("**/*.html", recursive=True)
    blocks = 0
    for f in files:
        html = open(f, encoding="utf-8", errors="ignore").read()
        for m in re.finditer(r"<script[^>]*application/ld.json[^>]*>(.*?)</script>", html, re.S):
            json.loads(m.group(1))
            blocks += 1
    print(f"SEO/AEO check passed: {len(files)} HTML files, {blocks} valid JSON-LD blocks.")

if __name__ == "__main__":
    main()
