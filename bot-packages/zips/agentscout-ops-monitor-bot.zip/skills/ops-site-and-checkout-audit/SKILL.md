---
name: ops-site-and-checkout-audit
description: 1. AgentScout Operations / Monitoring Bot (Built by AgentScout) — step-by-step operational workflow and verification playbook.
---

<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-3236360CB5B284E5F4C571A1 | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

<p align="left"><b>Pre-Trained Pro Bot built by</b> <a href="https://agentscouthq.com"><picture><source media="(prefers-color-scheme: dark)" srcset="../../assets/logo-wordmark-dark.svg"><img src="../../assets/logo-wordmark.svg" alt="AgentScout" width="168" height="32" style="vertical-align:middle"></picture></a></p>

# Operations Site, 8-Viewport Overflow & Checkout Audit

Run this skill after every production deployment and during the daily 9:15 AM PT deep audit:
1. Verify all core URLs return HTTP 200 in under 500ms.
2. Run Playwright across `(360, 800)` and `(390, 844)` at `1x` and `1.3x` font scale plus `(768, 1024)` and `(1280, 900)` in light and dark themes; assert `document.documentElement.scrollWidth <= window.innerWidth`.
3. Validate `/api/products.json` and `/.well-known/acp.json` against active Stripe Checkout links (`HTTP 200`, non-expired session).
