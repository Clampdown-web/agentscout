# START HERE: 1. AgentScout Operations / Monitoring Bot (Built by AgentScout)

1. AgentScout Operations / Monitoring Bot (Built by AgentScout). Use this folder for {{YOUR_COMPANY}} on {{YOUR_DOMAIN}}.

## What's inside

- `SYSTEM.md`, the role instructions
- `skills/ops-site-and-checkout-audit/SKILL.md`
- `scripts/daily_deep_audit.py`
- `scripts/verify_4tier_ctas.py`
- `README-QUICKSTART.md`
- `mcp.json`, an optional MCP server entry
- `setup_workspace.py`, which writes your company name and domain
- `routines/` (2 files)

## 10-minute setup

1. Import the template. In Grok Bot, create a teammate and paste SYSTEM.md into its instructions. In Lovable, import this ZIP under Workspace settings, then Skills, then Add, then Upload ZIP. Lovable reads SKILL.md. This folder also includes Claude Code (CLAUDE.md), Cursor (.cursorrules), Codex (AGENTS.md).
2. Replace {{YOUR_COMPANY}} and {{YOUR_DOMAIN}}. From the unzipped folder run `python3 setup_workspace.py --company "Your Company" --domain "yourdomain.com"`. That writes those two values through the package.
3. Connect tools. Open mcp.json and, if your company already runs an MCP server, put that server's URL in the entry. If you do not have one, leave the file unchanged. The file does not connect a tool by itself.
4. Run the first task. From the unzipped folder run `python3 scripts/daily_deep_audit.py`.

## What to expect on the first run

If {{YOUR_DOMAIN}} is still unfilled, python3 scripts/daily_deep_audit.py prints a dry-run line and does not open a connection. After you replace {{YOUR_DOMAIN}}, it requests that site's homepage and prints a pass or a failure. It does not send email, post, or spend.

## Help

Questions about this download: support@agentscouthq.com
