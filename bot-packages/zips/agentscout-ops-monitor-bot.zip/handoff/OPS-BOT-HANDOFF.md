<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-3236360CB5B284E5F4C571A1 | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

# OPS-BOT-HANDOFF.md — Operations & Monitoring Handoff Log

- **Domain:** `https://{{YOUR_DOMAIN}}`
- **Support Inbox:** `{{YOUR_SUPPORT_EMAIL}}`
- **Standing Check Schedule:** Every 4 hours (`0 */4 * * *` PT)
- **Audit Script:** `python3 scripts/daily_deep_audit.py && python3 scripts/verify_4tier_ctas.py`
