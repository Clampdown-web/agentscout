<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261125 | Fingerprint: AS-8F4049B65B6424FC9849352E | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

# HOOKS.md — Proven Outlier Hook Library (>5x Median Impressions)

1. **Contrarian Audit Hook:** `I audited {{N}} {{CATEGORY}} tools so you don't have to. Only {{K}} passed all {{M}} production checks:`
2. **Tear-Down Comparison Hook:** `Everyone talks about {{TOOL_A}}, but builders shipping in production are quietly switching to {{TOOL_B}}. Here is the benchmark:`
3. **Open-Source Stack Hook:** `The exact 4-agent autonomous stack running {{YOUR_DOMAIN}} 24/7 for under $5/day:`
