---
name: competitor-and-viral-hook-forensics
description: 3. AgentScout Market & Launch Intel Bot (Built by AgentScout) — step-by-step operational workflow and verification playbook.
---

<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261125 | Fingerprint: AS-8F4049B65B6424FC9849352E | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

<p align="left"><b>Pre-Trained Pro Bot built by</b> <a href="https://agentscouthq.com"><picture><source media="(prefers-color-scheme: dark)" srcset="../../assets/logo-wordmark-dark.svg"><img src="../../assets/logo-wordmark.svg" alt="AgentScout" width="168" height="32" style="vertical-align:middle"></picture></a></p>

# Competitor Launch Radar & 5x X Outlier Hook Forensics

1. **Outlier Detection Rule:** A post qualifies as a true viral outlier when `impressions >= 5 * account_median_impressions` or `bookmark_rate >= 3%`.
2. **Hook Deconstruction:** Record (a) the opening 12 words, (b) the contrast/numbers pattern, (c) the native asset type (30fps MP4 terminal demo — schedulers like Buffer reject higher framerates — vs. annotated comparison graphic), and (d) safe link placement in `HOOKS.md`.
3. **X Reply & Publishing Guardrails:** Stay within account daily limits (e.g., <=20 posts/day including replies), check past replies to that person first, avoid unquoted domains/filenames X could auto-link, and require explicit owner approval before posting (one approved post per confirmation).
