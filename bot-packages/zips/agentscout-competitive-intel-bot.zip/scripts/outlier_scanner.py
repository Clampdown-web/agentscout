# Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-36C7032F680AC51F17A51425
# Single-Organization Commercial License — Redistribution or resale prohibited (https://agentscouthq.com)
#!/usr/bin/env python3
"""Scan recent X posts against a 21-day rolling median and output >=5x outlier hooks."""
import json, statistics

SAMPLE = [1100, 1350, 980, 1200, 1420, 1150, 8900]
med = statistics.median(SAMPLE)
outliers = [x for x in SAMPLE if x >= 5 * med]
print(json.dumps({"median": med, "outliers_found": len(outliers), "outliers": outliers}, indent=2))
