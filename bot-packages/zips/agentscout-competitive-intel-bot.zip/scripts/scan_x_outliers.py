# Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-36C7032F680AC51F17A51425
# Single-Organization Commercial License — Redistribution or resale prohibited (https://agentscouthq.com)
#!/usr/bin/env python3
"""AgentScout Market & Launch Intel Bot — X Outlier & Bookmark-to-Impression Scorer."""
import json, statistics

def score_posts(posts):
    if not posts:
        return []
    med_imp = statistics.median([max(p.get("impressions", 1), 1) for p in posts])
    outliers = []
    for p in posts:
        imp = p.get("impressions", 0)
        bkm = p.get("bookmarks", 0)
        mult = round(imp / max(med_imp, 1), 2)
        bkm_rate = round((bkm / max(imp, 1)) * 100, 2)
        if mult >= 5.0 or bkm_rate >= 3.0:
            outliers.append({"id": p.get("id"), "multiplier": mult, "bookmark_rate_pct": bkm_rate, "text": p.get("text", "")[:140]})
    return sorted(outliers, key=lambda x: x["multiplier"], reverse=True)

if __name__ == "__main__":
    sample = [{"id": "demo-1", "impressions": 420, "bookmarks": 4, "text": " baseline post"},
              {"id": "demo-2", "impressions": 5800, "bookmarks": 210, "text": "We benchmarked 50 production workflows across 30 days — here is what moved conversion:"}]
    print(json.dumps(score_posts(sample), indent=2))
