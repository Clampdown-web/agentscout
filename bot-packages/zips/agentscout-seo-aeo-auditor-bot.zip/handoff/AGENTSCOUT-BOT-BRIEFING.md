<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-90327A1FD2350A48387310A4 | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

<p align="left"><b>Pre-Trained Pro Bot built by</b> <a href="https://agentscouthq.com"><picture><source media="(prefers-color-scheme: dark)" srcset="../assets/logo-wordmark-dark.svg"><img src="../assets/logo-wordmark.svg" alt="AgentScout" width="168" height="32" style="vertical-align:middle"></picture></a></p>

# AGENTSCOUT-BOT-BRIEFING.md — 4-Bot "Company-in-a-Box" Shared Protocol

## How the 4 Bots Work Together
1. **4. AgentScout CEO Coordinator Bot (`$69` · Neon Crimson Red `#ef4444`)**: Owns full-stack code builds, product releases, X/newsletter growth campaigns, and final owner deliverables.
2. **1. AgentScout Operations / Monitoring Bot (`$39` · Neon Lime `#84cc16`)**: Owns 4-hour inbox triage, 8-viewport Playwright layout/overflow QA, Stripe Checkout verification, and 4-hour X Velocity Guard scoring.
3. **2. AgentScout SEO & AEO Growth Auditor Bot (`$59` · Neon Gold `#eab308`)**: Owns Search Console/GA4 baselines, JSON-LD schema graphs, `llms.txt` / `llms-full.txt`, and ChatGPT/Perplexity/Claude/Grok citation audits.
4. **3. AgentScout Market & Launch Intel Bot (`$59` · Neon Sunset Orange `#f97316`)**: Owns competitor product/pricing radar, Product Hunt/HN breakout tracking, and the 20-account X Outlier & Hook Forensics scanner (`HOOKS.md`).

## Placeholders to Configure (`config.example.json`)
Replace these placeholders with your own business values after importing (`python3 setup_workspace.py --domain yourcompany.com --company "Your Company"`):
- `{{YOUR_COMPANY}}` -> e.g. `Acme Corp`
- `{{YOUR_DOMAIN}}` -> e.g. `yourcompany.com`
- `{{YOUR_SUPPORT_EMAIL}}` -> e.g. `support@yourcompany.com`
- `{{YOUR_OWNER_NAME}}` -> Your name or team handle
- `{{YOUR_MCP_SERVER_URL}}` -> e.g. `https://mcp.yourcompany.com/mcp` (your own optional MCP server endpoint)
