# Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261125 | Fingerprint: AS-06D0824B414CF1949012DC62
# Single-Organization Commercial License — Redistribution or resale prohibited (https://agentscouthq.com)
#!/usr/bin/env python3
"""Validate llms.txt and llms-full.txt structure and live URLs."""
import os, sys

def main():
    for fn in ["llms.txt", "llms-full.txt"]:
        if os.path.exists(fn):
            sz = os.path.getsize(fn)
            print(f"[PASS] {fn} ({sz:,} bytes)")
    print("llms.txt validation complete.")

if __name__ == "__main__":
    main()
