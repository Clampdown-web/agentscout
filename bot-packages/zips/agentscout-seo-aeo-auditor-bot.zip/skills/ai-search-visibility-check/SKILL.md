---
name: ai-search-visibility-check
description: Check how a site or product shows up in AI answers and search results, compare against rivals, and verify llms.txt and JSON-LD entity graphs.
---

<!-- Licensed to: UNASSIGNED-STOCK-BUILD@agentscouthq.com | Order: STOCK-MASTER-20261028 | Fingerprint: AS-90327A1FD2350A48387310A4 | Single-Organization License — Redistribution or resale strictly prohibited (https://agentscouthq.com) -->

# AI Search Visibility & Citation Check (AEO)

1. Test real buyer prompts across ChatGPT, Perplexity, Claude, and Grok.
2. Verify `llms.txt`, `llms-full.txt`, and `JSON-LD` entity graphs.
