import React, { useEffect, useState } from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet, Linking } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getFavorites, toggleFavorite, isNew, fmtDate } from '../api/tools';
import { useTheme, useStyles } from '../theme';


export default function ToolDetailScreen({ route, navigation }) {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  const tool = route.params?.tool;
  const [fav, setFav] = useState(false);

  useEffect(() => {
    if (tool) getFavorites().then((f) => setFav(f.includes(tool.id)));
  }, [tool]);

  useEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity onPress={onFav} hitSlop={10}>
          <Ionicons name={fav ? 'heart' : 'heart-outline'} size={24} color={fav ? C.heart : C.accent} />
        </TouchableOpacity>
      ),
    });
  });

  async function onFav() {
    const f = await toggleFavorite(tool.id);
    setFav(f.includes(tool.id));
  }

  if (!tool) return <View style={s.screen}><Text style={s.body}>Tool not found.</Text></View>;

  return (
    <ScrollView style={s.screen} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <View style={s.card}>
        <View style={s.row}>
          <View style={s.icon}>
            {tool.logo ? <Image source={{ uri: tool.logo }} style={s.img} />
              : <Text style={s.letter}>{tool.name[0]}</Text>}
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.name}>{tool.name}</Text>
            <View style={s.tags}>
              <Text style={s.tag}>{tool.category}</Text>
              <Text style={[s.tag, s.price]}>{tool.priceTag}</Text>
              {isNew(tool) ? <Text style={[s.tag, s.newTag]}>New</Text> : null}
            </View>
          </View>
        </View>
      </View>

      <View style={s.card}>
        <Text style={s.h2}>About</Text>
        <Text style={s.body}>{tool.description || 'No description yet.'}</Text>
        <Text style={s.meta}>Pricing: {tool.pricing}</Text>
        {tool.skill ? <Text style={s.meta}>Best for: {tool.skill}</Text> : null}
        {tool.added ? <Text style={s.meta}>Added {fmtDate(tool.added)}{tool.source ? ' · Source: ' + tool.source : ''}</Text> : null}
      </View>

      {tool.features.length > 0 && (
        <View style={s.card}>
          <Text style={s.h2}>Top features</Text>
          {tool.features.map((f, i) => (
            <View key={i} style={s.feat}>
              <Ionicons name="checkmark-circle" size={18} color={C.accent} />
              <Text style={s.featText}>{f}</Text>
            </View>
          ))}
        </View>
      )}

      <View style={s.card}>
        <Text style={s.h2}>Available on</Text>
        <View style={s.tags}>
          {tool.platforms.map((p) => (
            <View key={p} style={s.plat}>
              <Ionicons name={/android/i.test(p) ? 'logo-android' : /ios|mac|apple/i.test(p) ? 'logo-apple'
                : /cli|terminal/i.test(p) ? 'terminal' : 'globe-outline'} size={14} color={C.text} />
              <Text style={s.platText}>{p}</Text>
            </View>
          ))}
        </View>
      </View>

      {tool.website ? (
        <TouchableOpacity style={s.btn} onPress={() => Linking.openURL(tool.website)}>
          <Ionicons name="globe-outline" size={18} color={C.onAccent} />
          <Text style={s.btnText}>Website</Text>
        </TouchableOpacity>
      ) : null}
      {tool.github && tool.github !== tool.website ? (
        <TouchableOpacity style={tool.website ? s.btn2 : s.btn} onPress={() => Linking.openURL(tool.github)}>
          <Ionicons name="logo-github" size={18} color={tool.website ? C.accentText : C.onAccent} />
          <Text style={tool.website ? s.btn2Text : s.btnText}>GitHub</Text>
        </TouchableOpacity>
      ) : null}
      {!tool.website && !tool.github && tool.url ? (
        <TouchableOpacity style={s.btn} onPress={() => Linking.openURL(tool.url)}>
          <Ionicons name="open-outline" size={18} color={C.onAccent} />
          <Text style={s.btnText}>Open Website</Text>
        </TouchableOpacity>
      ) : null}
    </ScrollView>
  );
}

const makeStyles = (C) => StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.soft },
  card: { backgroundColor: C.card, borderRadius: 16, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: C.line },
  row: { flexDirection: 'row', alignItems: 'center' },
  icon: { width: 64, height: 64, borderRadius: 16, backgroundColor: C.accentSoft, alignItems: 'center',
    justifyContent: 'center', marginRight: 14 },
  img: { width: 40, height: 40, borderRadius: 8 },
  letter: { fontSize: 26, fontWeight: '800', color: C.accentText },
  name: { fontSize: 20, fontWeight: '800', color: C.text },
  tags: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 6 },
  tag: { backgroundColor: C.line, color: C.accentText, fontSize: 12, fontWeight: '700', paddingHorizontal: 10,
    paddingVertical: 4, borderRadius: 10, marginRight: 6, marginBottom: 4, overflow: 'hidden', textTransform: 'capitalize' },
  price: { backgroundColor: C.accentSoft, color: C.accentText },
  newTag: { backgroundColor: C.newBg, color: C.newText },
  h2: { fontSize: 16, fontWeight: '700', color: C.text, marginBottom: 8 },
  body: { fontSize: 15, color: C.text, lineHeight: 22 },
  meta: { fontSize: 13, color: C.muted, marginTop: 8 },
  feat: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 6 },
  featText: { flex: 1, marginLeft: 8, fontSize: 14, color: C.text },
  plat: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.soft, borderRadius: 10,
    paddingHorizontal: 10, paddingVertical: 5, marginRight: 6, marginBottom: 6 },
  platText: { marginLeft: 4, fontSize: 13, color: C.text },
  btn: { backgroundColor: C.accent, borderRadius: 14, height: 52, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'center', marginTop: 4 },
  btnText: { color: C.onAccent, fontSize: 16, fontWeight: '700', marginLeft: 8 },
  btn2: { backgroundColor: C.card, borderColor: C.accent, borderWidth: 1, borderRadius: 14, height: 52,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 10 },
  btn2Text: { color: C.accentText, fontSize: 16, fontWeight: '700', marginLeft: 8 },
  link: { color: C.accentText, textAlign: 'center', marginTop: 14, fontWeight: '600' },
});
