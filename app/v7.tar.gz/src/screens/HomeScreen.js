import React, { useEffect, useMemo, useState, useCallback } from 'react';
import { View, Text, TextInput, FlatList, ScrollView, Image, TouchableOpacity,
  StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { getTools, LOGO_URL, newest, isThisWeek, fmtDate, stats } from '../api/tools';
import NewChip from '../components/NewChip';
import { useTheme, useStyles } from '../theme';


function Tile({ tool, onPress }) {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  return (
    <TouchableOpacity style={s.tile} onPress={onPress} activeOpacity={0.7}>
      <View style={s.tileIcon}>
        {tool.logo ? <Image source={{ uri: tool.logo }} style={s.tileImg} />
          : <Text style={s.letter}>{tool.name[0]}</Text>}
      </View>
      <Text style={s.tileName} numberOfLines={2}>{tool.name}</Text>
    </TouchableOpacity>
  );
}

export default function HomeScreen({ navigation }) {
  const { C, isDark, toggle } = useTheme();
  const s = useStyles(makeStyles);
  const [tools, setTools] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);
  const [query, setQuery] = useState('');
  const [chip, setChip] = useState('All');

  const load = useCallback(async (force) => {
    try {
      setError(null);
      setTools(await getTools(force));
    } catch (e) {
      setError('Could not load tools. Pull down to retry.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { load(false); }, [load]);

  const chips = useMemo(() => {
    const counts = {};
    tools.forEach((t) => { counts[t.category] = (counts[t.category] || 0) + 1; });
    return ['All', 'Free', ...Object.keys(counts).sort((a, b) => counts[b] - counts[a])];
  }, [tools]);

  const ordered = useMemo(() => newest(tools), [tools]);
  const thisWeek = useMemo(() => ordered.filter(isThisWeek), [ordered]);
  const recent = useMemo(() => ordered.slice(0, 12), [ordered]);
  const st = useMemo(() => stats(tools), [tools]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return tools.filter((t) => {
      if (chip === 'Free' && t.priceTag !== 'free' && t.priceTag !== 'freemium') return false;
      if (chip !== 'All' && chip !== 'Free' && t.category !== chip) return false;
      if (!q) return true;
      return (t.name + ' ' + t.description + ' ' + t.category).toLowerCase().includes(q);
    });
  }, [tools, query, chip]);

  const open = (tool) => navigation.navigate('ToolDetail', { tool });

  const header = (
    <View>
      <View style={s.top}>
        <Image source={{ uri: LOGO_URL }} style={s.logo} />
        <View style={{ flex: 1 }}>
          <Text style={s.h1}>Agent<Text style={{ color: C.accentText }}>Scout</Text></Text>
          <Text style={s.sub}>Find the right AI agent for the job</Text>
        </View>
        <View style={s.count}><Text style={s.countText}>{tools.length}</Text></View>
        <TouchableOpacity style={s.themeBtn} onPress={toggle} hitSlop={8}
          accessibilityLabel={isDark ? 'Switch to light mode' : 'Switch to dark mode'}>
          <Ionicons name={isDark ? 'sunny-outline' : 'moon-outline'} size={18} color={C.text} />
        </TouchableOpacity>
      </View>

      <View style={s.search}>
        <Ionicons name="search" size={18} color={C.faint} />
        <TextInput style={s.input} placeholder={"Search " + tools.length + " AI agent tools"} placeholderTextColor={C.faint}
          value={query} onChangeText={setQuery} />
        {query ? <Ionicons name="close-circle" size={18} color={C.faint} onPress={() => setQuery('')} /> : null}
      </View>

      <View style={s.stats}>
        {[['Total tools', st.total], ['Added today', st.today], ['This week', st.week], ['This month', st.month], ['Categories', st.cats]].map(([k, v]) => (
          <View key={k} style={s.stat}><Text style={s.statNum}>{v}</Text><Text style={s.statLab} numberOfLines={1}>{k}</Text></View>
        ))}
      </View>

      {!query && chip === 'All' && thisWeek.length > 0 && (
        <View>
          <Text style={s.section}>New this week · {thisWeek.length}</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16 }}>
            {thisWeek.slice(0, 20).map((t) => (
              <TouchableOpacity key={t.id} style={s.pick} onPress={() => open(t)}>
                {t.logo ? <Image source={{ uri: t.logo }} style={s.pickImg} /> : null}
                <Text style={s.pickName} numberOfLines={1}>{t.name}</Text>
                <Text style={s.pickCat} numberOfLines={1}>New · {fmtDate(t.added)}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}

      {!query && chip === 'All' && recent.length > 0 && (
        <View>
          <View style={s.rhead}>
            <Text style={[s.section, { marginHorizontal: 0 }]}>Recently added</Text>
            <TouchableOpacity onPress={() => navigation.navigate('NewTools')} hitSlop={8}>
              <Text style={s.seeAll}>See all new →</Text>
            </TouchableOpacity>
          </View>
          {recent.map((t) => (
            <TouchableOpacity key={t.id} style={s.rcard} onPress={() => open(t)}>
              <View style={s.ricon}>
                {t.logo ? <Image source={{ uri: t.logo }} style={s.rimg} /> : <Text style={s.letter}>{t.name[0]}</Text>}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={s.rname} numberOfLines={1}>{t.name}</Text>
                <Text style={s.rdesc} numberOfLines={2}>{t.description}</Text>
                <View style={s.rmeta}><NewChip tool={t} /><Text style={s.rdate}>Added {fmtDate(t.added)}</Text></View>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      )}

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 14 }}
        contentContainerStyle={{ paddingHorizontal: 16 }}>
        {chips.map((c) => (
          <TouchableOpacity key={c} onPress={() => setChip(c)} style={[s.chip, chip === c && s.chipOn]}>
            <Text style={[s.chipText, chip === c && s.chipTextOn]}>{c}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <Text style={s.section}>{chip === 'All' ? 'All tools' : chip} · {filtered.length}</Text>
      {error ? <Text style={s.error}>{error}</Text> : null}
    </View>
  );

  if (loading) {
    return <View style={s.loading}><ActivityIndicator size="large" color={C.accent} /></View>;
  }

  return (
    <SafeAreaView style={s.screen} edges={['top']}>
      <FlatList
        data={filtered}
        keyExtractor={(t) => t.id}
        numColumns={3}
        ListHeaderComponent={header}
        columnWrapperStyle={{ paddingHorizontal: 10 }}
        renderItem={({ item }) => <Tile tool={item} onPress={() => open(item)} />}
        refreshControl={<RefreshControl refreshing={refreshing} colors={[C.accent]}
          onRefresh={() => { setRefreshing(true); load(true); }} />}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ paddingBottom: 24 }}
      />
    </SafeAreaView>
  );
}

const makeStyles = (C) => StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: C.bg },
  top: { flexDirection: 'row', alignItems: 'center', padding: 16, paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: C.line },
  logo: { width: 44, height: 44, borderRadius: 12, marginRight: 12, backgroundColor: C.card },
  h1: { fontSize: 22, fontWeight: '800', color: C.text },
  sub: { fontSize: 13, color: C.muted },
  count: { backgroundColor: C.accentSoft, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4 },
  themeBtn: { width: 36, height: 36, borderRadius: 8, borderWidth: 1, borderColor: C.line, backgroundColor: C.card,
    alignItems: 'center', justifyContent: 'center', marginLeft: 8 },
  countText: { color: C.accentText, fontWeight: '700' },
  search: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, marginHorizontal: 16,
    marginTop: 8, borderRadius: 10, paddingHorizontal: 12, height: 46, borderWidth: 1, borderColor: C.line },
  input: { flex: 1, marginLeft: 8, fontSize: 15, color: C.text },
  section: { fontSize: 16, fontWeight: '700', color: C.text, marginHorizontal: 16, marginTop: 16, marginBottom: 8 },
  pick: { width: 130, backgroundColor: C.accentSoft, borderRadius: 12, padding: 12, marginRight: 10,
    borderWidth: 1, borderColor: C.accent },
  pickImg: { width: 36, height: 36, borderRadius: 8, marginBottom: 8 },
  pickName: { fontWeight: '700', color: C.text },
  pickCat: { fontSize: 12, color: C.accentText, marginTop: 2 },
  chip: { height: 30, justifyContent: 'center', paddingHorizontal: 12, borderRadius: 999, backgroundColor: C.card,
    marginRight: 8, borderWidth: 1, borderColor: C.line },
  chipOn: { backgroundColor: C.accent, borderColor: C.accent },
  chipText: { color: C.text, fontWeight: '600', textTransform: 'capitalize' },
  chipTextOn: { color: C.onAccent },
  tile: { flex: 1 / 3, alignItems: 'center', padding: 6, marginBottom: 8 },
  tileIcon: { width: 72, height: 72, borderRadius: 12, backgroundColor: C.card, alignItems: 'center',
    justifyContent: 'center', borderWidth: 1, borderColor: C.line },
  tileImg: { width: 48, height: 48, borderRadius: 10 },
  letter: { fontSize: 28, fontWeight: '800', color: C.accentText },
  tileName: { fontSize: 12, color: C.text, textAlign: 'center', marginTop: 6, fontWeight: '600' },
  error: { color: C.danger, marginHorizontal: 16 },
  stats: { flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: 12, marginTop: 10 },
  stat: { width: '31%', margin: '1%', backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 12, paddingVertical: 8, paddingHorizontal: 10 },
  statNum: { fontSize: 18, fontWeight: '800', color: C.text },
  statLab: { fontSize: 11, color: C.muted },
  total: { color: C.muted, fontSize: 13, marginHorizontal: 16, marginTop: 10, fontWeight: '600' },
  rhead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginHorizontal: 16 },
  seeAll: { color: C.accentText, fontWeight: '700', marginTop: 8 },
  rcard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: 14, padding: 12, marginHorizontal: 16,
    marginBottom: 8, borderWidth: 1, borderColor: C.line },
  ricon: { width: 44, height: 44, borderRadius: 12, backgroundColor: C.accentSoft, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  rimg: { width: 28, height: 28, borderRadius: 6 },
  rname: { fontSize: 15, fontWeight: '700', color: C.text },
  rdesc: { fontSize: 12, color: C.muted, marginTop: 2 },
  rmeta: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
  rdate: { fontSize: 12, color: C.muted },
});
