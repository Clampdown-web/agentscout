import React, { useRef, useEffect, useMemo, useState, useCallback } from 'react';
import { View, Text, TextInput, FlatList, ScrollView, Image, TouchableOpacity,
  StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { getTools, getFavorites, LOGO_URL, newest, isThisWeek, fmtDate, stats, summaryLine, getMeta } from '../api/tools';
import ToolCard from '../components/ToolCard';
import { useWindowDimensions } from 'react-native';
import { useTheme, useStyles } from '../theme';
import { useScrollButtons } from '../components/ScrollButtons';



export default function HomeScreen({ navigation }) {
  const { C, isDark, toggle } = useTheme();
  const s = useStyles(makeStyles);
  const [tools, setTools] = useState([]);
  const listRef = useRef(null);
  const scroll = useScrollButtons(listRef);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);
  const [query, setQuery] = useState('');
  const [chip, setChip] = useState('All');
  const [favs, setFavs] = useState([]);
  const { width } = useWindowDimensions();
  const cols = width >= 700 ? 2 : 1;
  useEffect(() => navigation.addListener('focus', () => { getFavorites().then(setFavs); }), [navigation]);

  const load = useCallback(async (force) => {
    try {
      setError(null);
      setTools(await getTools(force));
    } catch (e) {
      setError('Could not load tools. Pull down to retry.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { load(false); }, [load]);

  const chips = useMemo(() => {
    const counts = {};
    tools.forEach((t) => { counts[t.category] = (counts[t.category] || 0) + 1; });
    return ['All', 'Saved', 'Free', ...Object.keys(counts).sort((a, b) => counts[b] - counts[a])];
  }, [tools]);

  const ordered = useMemo(() => newest(tools), [tools]);
  const thisWeek = useMemo(() => ordered.filter(isThisWeek), [ordered]);
  const recent = useMemo(() => ordered.slice(0, 12), [ordered]);
  const st = useMemo(() => stats(tools), [tools]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return tools.filter((t) => {
      if (chip === 'Free' && t.priceTag !== 'free' && t.priceTag !== 'freemium') return false;
      if (chip === 'Saved' && !favs.includes(t.id)) return false;
      if (chip !== 'All' && chip !== 'Free' && chip !== 'Saved' && t.category !== chip) return false;
      if (!q) return true;
      return (t.name + ' ' + t.description + ' ' + t.category).toLowerCase().includes(q);
    });
  }, [tools, query, chip, favs]);

  const open = (tool) => navigation.navigate('ToolDetail', { tool });

  const header = (
    <View>
      <View style={s.top}>
        <Image source={{ uri: LOGO_URL }} style={s.logo} />
        <View style={{ flex: 1 }}>
          <Text style={s.h1}>Agent<Text style={{ color: C.accentText }}>Scout</Text></Text>
          <Text style={s.sub}>Find the right AI agent for the job</Text>
        </View>
      </View>

      <View style={s.searchRow}>
        <View style={s.search}>
          <Ionicons name="search" size={18} color={C.faint} />
          <TextInput style={s.input} placeholder={"Search " + tools.length + " AI agent tools"} placeholderTextColor={C.faint}
            value={query} onChangeText={setQuery} />
          {query ? <Ionicons name="close-circle" size={18} color={C.faint} onPress={() => setQuery('')} /> : null}
        </View>
        <TouchableOpacity style={s.themeBtn} onPress={toggle} hitSlop={8}
          accessibilityLabel={isDark ? 'Switch to light mode' : 'Switch to dark mode'}>
          <Ionicons name={isDark ? 'sunny-outline' : 'moon-outline'} size={18} color={C.text} />
        </TouchableOpacity>
      </View>

      <Text style={s.total}>{summaryLine(tools)}</Text>
      {getMeta().lastChecked ? <Text style={s.checked}>Links last checked {fmtDate(getMeta().lastChecked)}</Text> : null}
      <View style={s.stats}>
        {[['Total tools', st.total], ['Added today', st.today], ['This week', st.week], ['This month', st.month], ['Categories', st.cats]].map(([k, v]) => (
          <View key={k} style={s.stat}><Text style={s.statNum}>{v}</Text><Text style={s.statLab} numberOfLines={1}>{k}</Text></View>
        ))}
      </View>

      {!query && chip === 'All' && thisWeek.length > 0 && (
        <View>
          <Text style={s.section}>New this week · {thisWeek.length}</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 4 }}>
            {thisWeek.slice(0, 20).map((t) => (
              <ToolCard key={t.id} tool={t} variant="wide" onPress={() => open(t)} />
            ))}
          </ScrollView>
        </View>
      )}

      {!query && chip === 'All' && recent.length > 0 && (
        <View>
          <View style={s.rhead}>
            <Text style={[s.section, { marginHorizontal: 0 }]}>Recently added</Text>
            <TouchableOpacity onPress={() => navigation.navigate('NewTools')} hitSlop={8}>
              <Text style={s.seeAll}>See all new →</Text>
            </TouchableOpacity>
          </View>
          <View style={cols > 1 ? s.grid2 : null}>
            {recent.map((t) => (
              <ToolCard key={t.id} tool={t} onPress={() => open(t)} style={[{ marginHorizontal: 16 }, cols > 1 && s.half]} />
            ))}
          </View>
        </View>
      )}

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 14 }}
        contentContainerStyle={{ paddingHorizontal: 16 }}>
        {chips.map((c) => (
          <TouchableOpacity key={c} onPress={() => setChip(c)} style={[s.chip, chip === c && s.chipOn]}>
            <Text style={[s.chipText, chip === c && s.chipTextOn]}>{c}</Text>
        </TouchableOpacity>
        ))}
      </ScrollView>
      <Text style={s.section}>{chip === 'All' ? 'All tools' : chip === 'Saved' ? 'Saved tools' : chip} · {filtered.length}</Text>
      {error ? <Text style={s.error}>{error}</Text> : null}
    </View>
  );

  if (loading) {
    return <View style={s.loading}><ActivityIndicator size="large" color={C.accent} /></View>;
  }

  return (
    <SafeAreaView style={s.screen} edges={['top']}>
      <FlatList
        ref={listRef}
        {...scroll.listProps}
        data={filtered}
        keyExtractor={(t) => t.id}
        key={'cols' + cols}
        numColumns={cols}
        ListHeaderComponent={header}
        columnWrapperStyle={cols > 1 ? { paddingHorizontal: 10 } : undefined}
        renderItem={({ item }) => <ToolCard tool={item} onPress={() => open(item)} style={cols > 1 ? { flex: 1, marginHorizontal: 6 } : { marginHorizontal: 16 }} />}
        refreshControl={<RefreshControl refreshing={refreshing} colors={[C.accent]}
          onRefresh={() => { setRefreshing(true); load(true); }} />}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ paddingBottom: 24 }}
      />
      {scroll.buttons}
    </SafeAreaView>
  );
}

const makeStyles = (C) => StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: C.bg },
  top: { flexDirection: 'row', alignItems: 'center', padding: 16, paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: C.line },
  logo: { width: 44, height: 44, borderRadius: 12, marginRight: 12, backgroundColor: C.card },
  h1: { fontSize: 22, fontWeight: '800', color: C.text },
  sub: { fontSize: 13, color: C.muted },
  themeBtn: { width: 46, height: 46, marginLeft: 8, borderRadius: 10, borderWidth: 1, borderColor: C.line, backgroundColor: C.card,
    alignItems: 'center', justifyContent: 'center' },
  searchRow: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 16, marginTop: 8 },
  search: { flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: C.card,
    borderRadius: 10, paddingHorizontal: 12, height: 46, borderWidth: 1, borderColor: C.line },
  input: { flex: 1, marginLeft: 8, fontSize: 15, color: C.text },
  section: { fontSize: 16, fontWeight: '700', color: C.text, marginHorizontal: 16, marginTop: 16, marginBottom: 8 },
  pick: { width: 130, backgroundColor: C.accentSoft, borderRadius: 12, padding: 12, marginRight: 10,
    borderWidth: 1, borderColor: C.accent },
  pickImg: { width: 36, height: 36, borderRadius: 8, marginBottom: 8 },
  pickName: { fontWeight: '700', color: C.text },
  pickCat: { fontSize: 12, color: C.accentText, marginTop: 2 },
  chip: { height: 30, justifyContent: 'center', paddingHorizontal: 12, borderRadius: 999, backgroundColor: C.card,
    marginRight: 8, borderWidth: 1, borderColor: C.line },
  chipOn: { backgroundColor: C.accent, borderColor: C.accent },
  chipText: { color: C.text, fontWeight: '600', textTransform: 'capitalize' },
  chipTextOn: { color: C.onAccent },
  tile: { flex: 1 / 3, alignItems: 'center', padding: 6, marginBottom: 8 },
  tileIcon: { width: 72, height: 72, borderRadius: 12, backgroundColor: C.card, alignItems: 'center',
    justifyContent: 'center', borderWidth: 1, borderColor: C.line },
  tileImg: { width: 48, height: 48, borderRadius: 10 },
  letter: { fontSize: 28, fontWeight: '800', color: C.accentText },
  tileName: { fontSize: 12, color: C.text, textAlign: 'center', marginTop: 6, fontWeight: '600' },
  error: { color: C.danger, marginHorizontal: 16 },
  stats: { flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: 12, marginTop: 10 },
  stat: { width: '31%', margin: '1%', backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 12, paddingVertical: 8, paddingHorizontal: 10 },
  statNum: { fontSize: 18, fontWeight: '800', color: C.text },
  statLab: { fontSize: 11, color: C.muted },
  checked: { color: C.faint, fontSize: 12, marginHorizontal: 16, marginTop: 2 },
  grid2: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 10 },
  half: { width: '47%', marginHorizontal: '1.5%' },
  total: { color: C.muted, fontSize: 13, marginHorizontal: 16, marginTop: 10, fontWeight: '600' },
  rhead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginHorizontal: 16 },
  seeAll: { color: C.accentText, fontWeight: '700', marginTop: 8 },
  rcard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: 14, padding: 12, marginHorizontal: 16,
    marginBottom: 8, borderWidth: 1, borderColor: C.line },
  ricon: { width: 44, height: 44, borderRadius: 12, backgroundColor: C.accentSoft, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  rimg: { width: 28, height: 28, borderRadius: 6 },
  rname: { fontSize: 15, fontWeight: '700', color: C.text },
  rdesc: { fontSize: 12, color: C.muted, marginTop: 2 },
  rmeta: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
  rdate: { fontSize: 12, color: C.muted },
});
