import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, SectionList, Image, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { getTools, lastDays, fmtDate, isThisWeek } from '../api/tools';
import NewChip from '../components/NewChip';
import { useTheme, useStyles } from '../theme';

// Mirrors the website's new.html: last 30 days, "This week" then "Earlier", grouped by added date.
export default function NewToolsScreen({ navigation }) {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  const [tools, setTools] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => { getTools().then(setTools).catch(() => {}).finally(() => setLoading(false)); }, []);
  const sections = useMemo(() => {
    const groups = {};
    lastDays(tools, 30).forEach((t) => { (groups[t.added] = groups[t.added] || []).push(t); });
    return Object.keys(groups).sort().reverse().map((d) => ({ title: d, data: groups[d] }));
  }, [tools]);
  const recentCount = sections.reduce((n, x) => n + x.data.length, 0);
  if (loading) return <View style={s.loading}><ActivityIndicator size="large" color={C.accent} /></View>;
  let shownEarlier = false;
  return (
    <SectionList
      style={s.screen}
      sections={sections}
      keyExtractor={(t) => t.id}
      stickySectionHeadersEnabled={false}
      contentContainerStyle={{ padding: 16, paddingBottom: 32 }}
      ListHeaderComponent={<Text style={s.lede}>{recentCount} tools added in the last 30 days, newest first.</Text>}
      ListEmptyComponent={<Text style={s.lede}>No tools added in the last 30 days.</Text>}
      renderSectionHeader={({ section }) => {
        const week = isThisWeek({ added: section.title });
        const groupLabel = week ? (section === sections[0] ? 'This week' : null) : (!shownEarlier ? ((shownEarlier = true), 'Earlier') : null);
        return (
          <View>
            {groupLabel ? <Text style={s.group}>{groupLabel}</Text> : null}
            <Text style={s.day}>{fmtDate(section.title)} · {section.data.length} tool{section.data.length === 1 ? '' : 's'}</Text>
          </View>
        );
      }}
      renderItem={({ item }) => (
        <TouchableOpacity style={s.card} onPress={() => navigation.navigate('ToolDetail', { tool: item })}>
          <View style={s.icon}>
            {item.logo ? <Image source={{ uri: item.logo }} style={s.img} /> : <Text style={s.letter}>{item.name[0]}</Text>}
          </View>
          <View style={{ flex: 1 }}>
            <View style={s.row}><NewChip tool={item} /><Text style={s.name} numberOfLines={1}>{item.name}</Text></View>
            <Text style={s.desc} numberOfLines={2}>{item.description}</Text>
          </View>
        </TouchableOpacity>
      )}
    />
  );
}
const makeStyles = (C) => StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: C.bg },
  lede: { color: C.muted, fontSize: 14, marginBottom: 4 },
  group: { fontSize: 20, fontWeight: '800', color: C.text, marginTop: 18 },
  day: { fontSize: 15, fontWeight: '700', color: C.muted, marginTop: 12, marginBottom: 8 },
  row: { flexDirection: 'row', alignItems: 'center' },
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: 14, padding: 12,
    marginBottom: 8, borderWidth: 1, borderColor: C.line },
  icon: { width: 44, height: 44, borderRadius: 12, backgroundColor: C.accentSoft, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  img: { width: 28, height: 28, borderRadius: 6 },
  letter: { fontSize: 20, fontWeight: '800', color: C.accentText },
  name: { flex: 1, fontSize: 15, fontWeight: '700', color: C.text },
  desc: { fontSize: 12, color: C.muted, marginTop: 2 },
});
