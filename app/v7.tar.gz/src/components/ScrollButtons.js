import React, { useState, useCallback } from 'react';
import { View, TouchableOpacity, StyleSheet, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../theme';

// Floating up/down buttons, matching the website: bottom-right, up above down, 16px apart,
// 52px/40px inset on tablet, 48px/24px on phone, plus safe area. Screens sit above the tab bar already.
export function useScrollButtons(ref) {
  const [y, setY] = useState(0);
  const [content, setContent] = useState(0);
  const [view, setView] = useState(0);
  const onScroll = useCallback((e) => setY(e.nativeEvent.contentOffset.y), []);
  const onContentSizeChange = useCallback((w, h) => setContent(h), []);
  const onLayout = useCallback((e) => setView(e.nativeEvent.layout.height), []);
  const scrollable = content > view + 200;
  const showUp = scrollable && y > 300;
  const showDown = scrollable && y < content - view - 300;
  const responder = () => ref.current && (ref.current.getScrollResponder ? ref.current.getScrollResponder() : ref.current);
  const toTop = () => {
    const l = ref.current; if (!l) return;
    if (l.scrollToOffset) l.scrollToOffset({ offset: 0, animated: true });
    else { const r = responder(); r && r.scrollTo && r.scrollTo({ y: 0, animated: true }); }
  };
  const toEnd = () => {
    const l = ref.current; if (!l) return;
    if (l.scrollToEnd) l.scrollToEnd({ animated: true });
    else { const r = responder(); r && r.scrollToEnd && r.scrollToEnd({ animated: true }); }
  };
  return { listProps: { onScroll, onContentSizeChange, onLayout, scrollEventThrottle: 32 }, buttons: <ScrollButtons showUp={showUp} showDown={showDown} onUp={toTop} onDown={toEnd} /> };
}

export default function ScrollButtons({ showUp, showDown, onUp, onDown }) {
  const { C, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const tablet = width >= 600;
  const size = tablet ? 52 : 48, edge = tablet ? 40 : 24;
  const btn = { width: size, height: size, borderRadius: size / 2, backgroundColor: C.card, borderWidth: 1, borderColor: C.line,
    alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOpacity: isDark ? 0.5 : 0.15, shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 }, elevation: 4 };
  if (!showUp && !showDown) return null;
  return (
    <View pointerEvents="box-none" style={[s.wrap, { right: edge + insets.right, bottom: edge + insets.bottom }]}>
      {showUp ? (
        <TouchableOpacity style={[btn, showDown && { marginBottom: 16 }]} onPress={onUp} accessibilityLabel="Scroll to top">
          <Ionicons name="arrow-up" size={22} color={C.text} />
        </TouchableOpacity>
      ) : null}
      {showDown ? (
        <TouchableOpacity style={btn} onPress={onDown} accessibilityLabel="Scroll to bottom">
          <Ionicons name="arrow-down" size={22} color={C.text} />
        </TouchableOpacity>
      ) : null}
    </View>
  );
}
const s = StyleSheet.create({ wrap: { position: 'absolute', alignItems: 'center', zIndex: 10 } });
