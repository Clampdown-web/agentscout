import AsyncStorage from '@react-native-async-storage/async-storage';

export const TOOLS_URL = 'https://agentscouthq.com/api/tools.json';
export const LOGO_URL = 'https://agentscouthq.com/logo-square.png';
const CACHE_KEY = 'agentscout_tools_v8'; // v8: adds seed flag
const FAV_KEY = 'agentscout_favs_v1';
const MAX_AGE = 0; // always fetch fresh, cache only as offline fallback

// Same date logic as the website (stats.js.html): calendar days in Pacific time.
export function ptToday() {
  try {
    return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Los_Angeles', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
  } catch (e) {
    return new Date(Date.now() - 7 * 36e5).toISOString().slice(0, 10);
  }
}
function back(s, n) { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() - n); return d.toISOString().slice(0, 10); }
const daysAgo = (n) => back(ptToday(), n - 1); // last n calendar days including today
// "seed" = the starting catalog (Oct 14 launch + Oct 16 bulk import). It is never counted as new;
// only tools added later by the daily discovery run are. Same rule as the website.
export const isNew = (t) => !t.seed && !!t.added && t.added >= daysAgo(14);
export const isThisWeek = (t) => !t.seed && !!t.added && t.added >= daysAgo(7);
export function stats(tools) {
  const t = ptToday(), w = back(t, 6), m = back(t, 29);
  const fresh = tools.filter((x) => !x.seed && x.added);
  const src = fresh.length ? fresh : tools.filter((x) => x.added);
  const last = src.reduce((a, x) => (x.added > a ? x.added : a), '');
  return {
    total: tools.length,
    today: fresh.filter((x) => x.added === t).length,
    week: fresh.filter((x) => x.added >= w).length,
    month: fresh.filter((x) => x.added >= m).length,
    last, // most recent date the daily run added tools (falls back to newest overall)
    lastN: src.filter((x) => x.added === last).length,
    seed: tools.filter((x) => x.seed).length,
    cats: new Set(tools.map((x) => x.category)).size,
  };
}
export function shortDate(d) {
  if (!d) return '–';
  const [, m, day] = d.split('-').map(Number);
  return ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][m - 1] + ' ' + day;
}
export function fmtDate(d) {
  if (!d) return '';
  const [y, m, day] = d.split('-').map(Number);
  return ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][m - 1] + ' ' + day + ', ' + y;
}
export const newest = (tools) => [...tools].sort((a, b) => (b.added || '').localeCompare(a.added || '') || (b.order - a.order));
export const lastDays = (tools, n) => newest(tools).filter((t) => !t.seed && t.added && t.added >= daysAgo(n));

function normalize(t, i) {
  const url = t.url || t.page || '';
  let host = '';
  try { host = url.replace(/^https?:\/\//, '').split('/')[0]; } catch (e) {}
  return {
    id: t.slug || String(i),
    name: t.name || 'Untitled',
    url,
    page: t.page || url,
    category: t.category || 'other',
    description: t.description || '',
    features: Array.isArray(t.key_features) ? t.key_features : [],
    pricing: t.pricing || 'See site',
    priceTag: t.price_tag || 'unknown',
    platforms: Array.isArray(t.platforms) && t.platforms.length ? t.platforms : ['Web'],
    skill: t.skill || '',
    goals: Array.isArray(t.goals) ? t.goals : [],
    github: t.github || '',
    weeklyPick: !!t.weekly_pick,
    isNew: !!t.new,
    seed: !!t.seed,
    order: i,
    added: t.added || t.date_added || '',
    source: t.source || '',
    dateAdded: t.added || t.date_added || '',
    website: t.website || '',
    github: t.github || '',
    repo: t.github || t.repo || null,
    stars: typeof t.github_stars === 'number' ? t.github_stars : null,
    openSource: !!t.open_source || /^open/i.test(t.pricing || ''),
    license: t.license || '',
    tags: Array.isArray(t.tags) ? t.tags : [],
    logo: t.logo || null, // site's real logos (assets/logos/*.png); letter badge if missing
  };
}

let META = { lastChecked: '', updated: '' };
export const getMeta = () => META;
// "549 tools · N new this week · 14 categories · every link checked" (same wording as the site)
export function summaryLine(tools) {
  const st = stats(tools);
  return st.total + ' tools · ' + st.week + ' new this week · ' + st.cats + ' categories · every link checked';
}

export async function getTools(force = false) {
  let cached = null;
  try {
    const raw = await AsyncStorage.getItem(CACHE_KEY);
    if (raw) cached = JSON.parse(raw);
    if (cached && cached.meta) META = cached.meta;
  } catch (e) {}
  if (!force && cached && Date.now() - cached.time < MAX_AGE) return cached.tools;
  try {
    const res = await fetch(TOOLS_URL, { cache: 'no-cache' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    const list = Array.isArray(data) ? data : data.tools || [];
    const tools = list.map(normalize);
    if (!Array.isArray(data)) META = { lastChecked: data.last_checked || '', updated: data.updated || data.generated || '' };
    await AsyncStorage.setItem(CACHE_KEY, JSON.stringify({ time: Date.now(), tools, meta: META }));
    return tools;
  } catch (e) {
    if (cached) return cached.tools;
    throw e;
  }
}

// Weekly picks: flagged picks first, then newest tools, up to 8
export function getPicks(tools) {
  const picks = tools.filter((t) => t.weeklyPick);
  const rest = tools.filter((t) => !t.weeklyPick)
    .sort((a, b) => (b.dateAdded || '').localeCompare(a.dateAdded || ''));
  return [...picks, ...rest].slice(0, 8);
}

// Favorites: same AsyncStorage key as before, plus an in-memory copy and listeners so every heart stays in sync.
let FAVS = null;
const FAV_LISTENERS = new Set();
export async function getFavorites() {
  if (FAVS) return FAVS;
  try { FAVS = JSON.parse((await AsyncStorage.getItem(FAV_KEY)) || '[]'); } catch (e) { FAVS = []; }
  return FAVS;
}
export function subscribeFavorites(fn) { FAV_LISTENERS.add(fn); return () => FAV_LISTENERS.delete(fn); }
export async function toggleFavorite(id) {
  const favs = await getFavorites();
  const next = favs.includes(id) ? favs.filter((f) => f !== id) : [...favs, id];
  FAVS = next;
  if (next.length > favs.length) require('./analytics').track('favorite_add', id);
  FAV_LISTENERS.forEach((fn) => fn(next));
  await AsyncStorage.setItem(FAV_KEY, JSON.stringify(next));
  return next;
}
