import React from 'react';
import { View, Text, Image, StyleSheet, ScrollView, Linking } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import HomeScreen from '../screens/HomeScreen';
import { LOGO_URL } from '../api/tools';

const Tab = createBottomTabNavigator();
const PURPLE = '#6D28D9';

function OverviewScreen() {
  return (
    <View style={s.center}>
      <Ionicons name="stats-chart" size={48} color={PURPLE} />
      <Text style={s.title}>Overview</Text>
      <Text style={s.body}>Browse, search, favorites and the agent finder quiz are coming next.</Text>
    </View>
  );
}

function AboutScreen() {
  return (
    <ScrollView contentContainerStyle={s.center}>
      <Image source={{ uri: LOGO_URL }} style={s.logo} resizeMode="contain" />
      <Text style={s.title}>AgentScout</Text>
      <Text style={s.body}>Find the right AI agent for the job. A curated directory of AI agents and tools, updated weekly.</Text>
      <Text style={s.link} onPress={() => Linking.openURL('https://clampdown-web.github.io/agentscout/')}>
        Visit the website
      </Text>
    </ScrollView>
  );
}

export default function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarActiveTintColor: PURPLE,
        tabBarInactiveTintColor: '#9CA3AF',
        headerTitleStyle: { fontWeight: '700' },
        tabBarIcon: ({ color, size, focused }) => {
          const icons = { 'AI Tools': 'grid', Overview: 'pie-chart', About: 'information-circle' };
          const name = icons[route.name] + (focused ? '' : '-outline');
          return <Ionicons name={name} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="AI Tools" component={HomeScreen} options={{ headerShown: false }} />
      <Tab.Screen name="Overview" component={OverviewScreen} />
      <Tab.Screen name="About" component={AboutScreen} />
    </Tab.Navigator>
  );
}

const s = StyleSheet.create({
  center: { flexGrow: 1, alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: '#F5F5F7' },
  logo: { width: 140, height: 140, borderRadius: 24, marginBottom: 12 },
  title: { fontSize: 22, fontWeight: '700', color: '#111827', marginTop: 12 },
  body: { fontSize: 15, color: '#4B5563', textAlign: 'center', marginTop: 8, lineHeight: 22 },
  link: { color: PURPLE, fontWeight: '700', marginTop: 16, fontSize: 16 },
});
