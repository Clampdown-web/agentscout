import React, { useEffect, useMemo, useState, useCallback } from 'react';
import { View, Text, TextInput, FlatList, ScrollView, Image, TouchableOpacity,
  StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { getTools, getPicks, LOGO_URL } from '../api/tools';

const PURPLE = '#6D28D9';
const DARK = '#4C1D95';

function Tile({ tool, onPress }) {
  return (
    <TouchableOpacity style={s.tile} onPress={onPress} activeOpacity={0.7}>
      <View style={s.tileIcon}>
        {tool.logo ? <Image source={{ uri: tool.logo }} style={s.tileImg} />
          : <Text style={s.letter}>{tool.name[0]}</Text>}
      </View>
      <Text style={s.tileName} numberOfLines={2}>{tool.name}</Text>
    </TouchableOpacity>
  );
}

export default function HomeScreen({ navigation }) {
  const [tools, setTools] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);
  const [query, setQuery] = useState('');
  const [chip, setChip] = useState('All');

  const load = useCallback(async (force) => {
    try {
      setError(null);
      setTools(await getTools(force));
    } catch (e) {
      setError('Could not load tools. Pull down to retry.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { load(false); }, [load]);

  const chips = useMemo(() => {
    const counts = {};
    tools.forEach((t) => { counts[t.category] = (counts[t.category] || 0) + 1; });
    return ['All', 'Free', ...Object.keys(counts).sort((a, b) => counts[b] - counts[a])];
  }, [tools]);

  const picks = useMemo(() => getPicks(tools), [tools]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return tools.filter((t) => {
      if (chip === 'Free' && t.priceTag !== 'free' && t.priceTag !== 'freemium') return false;
      if (chip !== 'All' && chip !== 'Free' && t.category !== chip) return false;
      if (!q) return true;
      return (t.name + ' ' + t.description + ' ' + t.category).toLowerCase().includes(q);
    });
  }, [tools, query, chip]);

  const open = (tool) => navigation.navigate('ToolDetail', { tool });

  const header = (
    <View>
      <View style={s.top}>
        <Image source={{ uri: LOGO_URL }} style={s.logo} />
        <View style={{ flex: 1 }}>
          <Text style={s.h1}>AgentScout</Text>
          <Text style={s.sub}>Latest useful AI agents</Text>
        </View>
        <View style={s.count}><Text style={s.countText}>{tools.length}</Text></View>
      </View>

      <View style={s.search}>
        <Ionicons name="search" size={18} color="#9CA3AF" />
        <TextInput style={s.input} placeholder="Search tools" placeholderTextColor="#9CA3AF"
          value={query} onChangeText={setQuery} />
        {query ? <Ionicons name="close-circle" size={18} color="#9CA3AF" onPress={() => setQuery('')} /> : null}
      </View>

      {!query && chip === 'All' && picks.length > 0 && (
        <View>
          <Text style={s.section}>Weekly picks</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16 }}>
            {picks.map((t) => (
              <TouchableOpacity key={t.id} style={s.pick} onPress={() => open(t)}>
                {t.logo ? <Image source={{ uri: t.logo }} style={s.pickImg} /> : null}
                <Text style={s.pickName} numberOfLines={1}>{t.name}</Text>
                <Text style={s.pickCat} numberOfLines={1}>{t.weeklyPick ? '⭐ Pick' : t.isNew ? 'New' : t.category}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 14 }}
        contentContainerStyle={{ paddingHorizontal: 16 }}>
        {chips.map((c) => (
          <TouchableOpacity key={c} onPress={() => setChip(c)} style={[s.chip, chip === c && s.chipOn]}>
            <Text style={[s.chipText, chip === c && s.chipTextOn]}>{c}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <Text style={s.section}>{chip === 'All' ? 'All tools' : chip} · {filtered.length}</Text>
      {error ? <Text style={s.error}>{error}</Text> : null}
    </View>
  );

  if (loading) {
    return <View style={s.loading}><ActivityIndicator size="large" color={PURPLE} /></View>;
  }

  return (
    <SafeAreaView style={s.screen} edges={['top']}>
      <FlatList
        data={filtered}
        keyExtractor={(t) => t.id}
        numColumns={3}
        ListHeaderComponent={header}
        columnWrapperStyle={{ paddingHorizontal: 10 }}
        renderItem={({ item }) => <Tile tool={item} onPress={() => open(item)} />}
        refreshControl={<RefreshControl refreshing={refreshing} colors={[PURPLE]}
          onRefresh={() => { setRefreshing(true); load(true); }} />}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ paddingBottom: 24 }}
      />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#F5F5F7' },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#F5F5F7' },
  top: { flexDirection: 'row', alignItems: 'center', padding: 16, paddingBottom: 8 },
  logo: { width: 44, height: 44, borderRadius: 12, marginRight: 12, backgroundColor: '#fff' },
  h1: { fontSize: 22, fontWeight: '800', color: '#111827' },
  sub: { fontSize: 13, color: '#6B7280' },
  count: { backgroundColor: '#DCFCE7', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4 },
  countText: { color: '#15803D', fontWeight: '700' },
  search: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', marginHorizontal: 16,
    marginTop: 8, borderRadius: 14, paddingHorizontal: 12, height: 46, borderWidth: 1, borderColor: '#E5E7EB' },
  input: { flex: 1, marginLeft: 8, fontSize: 15, color: '#111827' },
  section: { fontSize: 16, fontWeight: '700', color: '#111827', marginHorizontal: 16, marginTop: 16, marginBottom: 8 },
  pick: { width: 130, backgroundColor: '#fff', borderRadius: 16, padding: 12, marginRight: 10,
    borderWidth: 1, borderColor: '#EDE9FE' },
  pickImg: { width: 36, height: 36, borderRadius: 8, marginBottom: 8 },
  pickName: { fontWeight: '700', color: '#111827' },
  pickCat: { fontSize: 12, color: PURPLE, marginTop: 2 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: '#fff',
    marginRight: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  chipOn: { backgroundColor: DARK, borderColor: DARK },
  chipText: { color: '#374151', fontWeight: '600', textTransform: 'capitalize' },
  chipTextOn: { color: '#fff' },
  tile: { flex: 1 / 3, alignItems: 'center', padding: 6, marginBottom: 8 },
  tileIcon: { width: 72, height: 72, borderRadius: 18, backgroundColor: '#fff', alignItems: 'center',
    justifyContent: 'center', borderWidth: 1, borderColor: '#E5E7EB' },
  tileImg: { width: 44, height: 44, borderRadius: 8 },
  letter: { fontSize: 28, fontWeight: '800', color: PURPLE },
  tileName: { fontSize: 12, color: '#111827', textAlign: 'center', marginTop: 6, fontWeight: '600' },
  error: { color: '#B91C1C', marginHorizontal: 16 },
});
