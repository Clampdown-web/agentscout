import React, { useEffect, useState } from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet, Linking } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import useFavorites from '../api/useFavorites';
import { toggleFavorite, isNew, fmtDate, getTools } from '../api/tools';
import ToolCard from '../components/ToolCard';
import { track } from '../api/analytics';
import { useTheme, useStyles } from '../theme';


export default function ToolDetailScreen({ route, navigation }) {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  const tool = route.params?.tool;
  const fav = useFavorites().includes(tool && tool.id);
  const [all, setAll] = useState([]);
  useEffect(() => { getTools().then(setAll).catch(() => {}); }, []);
  // Same category, new and picked first (like the "Alternatives" block on tools/*.html)
  const alts = tool ? all.filter((t) => t.category === tool.category && t.id !== tool.id)
    .sort((a, b) => (b.weeklyPick - a.weeklyPick) || (isNew(b) - isNew(a)) || a.order - b.order).slice(0, 6) : [];

  async function onFav() {
    await toggleFavorite(tool.id);
  }

  if (!tool) return <View style={s.screen}><Text style={s.body}>Tool not found.</Text></View>;

  return (
    <ScrollView style={s.screen} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <View style={s.card}>
        <View style={s.row}>
          <View style={s.icon}>
            {tool.logo ? <Image source={{ uri: tool.logo }} style={s.img} />
              : <Text style={s.letter}>{tool.name[0]}</Text>}
          </View>
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={[s.name, { flex: 1 }]}>{tool.name}</Text>
              <TouchableOpacity onPress={onFav} hitSlop={10} accessibilityRole="button" accessibilityLabel={fav ? 'Remove from saved' : 'Save tool'}>
                <Ionicons name={fav ? 'heart' : 'heart-outline'} size={26} color={fav ? C.heart : C.accent} />
              </TouchableOpacity>
            </View>
            <View style={s.tags}>
              <Text style={s.tag}>{tool.category}</Text>
              <Text style={[s.tag, s.price]}>{tool.priceTag}</Text>
              {isNew(tool) ? <Text style={[s.tag, s.newTag]}>New</Text> : null}
            </View>
          </View>
        </View>
      </View>

      <View style={s.card}>
        <Text style={s.h2}>About</Text>
        <Text style={s.body}>{tool.description || 'No description yet.'}</Text>
        <Text style={s.meta}>Pricing: {tool.pricing}</Text>
        {tool.skill ? <Text style={s.meta}>Best for: {tool.skill}</Text> : null}
        {tool.added ? <Text style={s.meta}>Added {fmtDate(tool.added)}{tool.source ? ' · Source: ' + tool.source : ''}</Text> : null}
      </View>

      {tool.features.length > 0 && (
        <View style={s.card}>
          <Text style={s.h2}>Top features</Text>
          {tool.features.map((f, i) => (
            <View key={i} style={s.feat}>
              <Ionicons name="checkmark-circle" size={18} color={C.accent} />
              <Text style={s.featText}>{f}</Text>
            </View>
          ))}
        </View>
      )}

      <View style={s.card}>
        <Text style={s.h2}>Available on</Text>
        <View style={s.tags}>
          {tool.platforms.map((p) => (
            <View key={p} style={s.plat}>
              <Ionicons name={/android/i.test(p) ? 'logo-android' : /ios|mac|apple/i.test(p) ? 'logo-apple'
                : /cli|terminal/i.test(p) ? 'terminal' : 'globe-outline'} size={14} color={C.text} />
              <Text style={s.platText}>{p}</Text>
            </View>
          ))}
        </View>
      </View>

      {tool.website ? (
        <TouchableOpacity style={s.btn} onPress={() => { track('outbound_link', tool.id + ':website'); Linking.openURL(tool.website); }}>
          <Ionicons name="globe-outline" size={18} color={C.onAccent} />
          <Text style={s.btnText}>Website</Text>
        </TouchableOpacity>
      ) : null}
      {tool.github && tool.github !== tool.website ? (
        <TouchableOpacity style={tool.website ? s.btn2 : s.btn} onPress={() => { track('outbound_link', tool.id + ':github'); Linking.openURL(tool.github); }}>
          <Ionicons name="logo-github" size={18} color={tool.website ? C.accentText : C.onAccent} />
          <Text style={tool.website ? s.btn2Text : s.btnText}>GitHub</Text>
        </TouchableOpacity>
      ) : null}
      {!tool.website && !tool.github && tool.url ? (
        <TouchableOpacity style={s.btn} onPress={() => { track('outbound_link', tool.id + ':url'); Linking.openURL(tool.url); }}>
          <Ionicons name="open-outline" size={18} color={C.onAccent} />
          <Text style={s.btnText}>Open Website</Text>
        </TouchableOpacity>
      ) : null}

      {alts.length ? (
        <View style={{ marginTop: 4 }}>
          <Text style={[s.h2, { marginBottom: 8 }]}>Alternatives to {tool.name}</Text>
          {alts.map((t) => <ToolCard key={t.id} tool={t} onPress={() => navigation.push('ToolDetail', { tool: t })} />)}
        </View>
      ) : null}
    </ScrollView>
  );
}

const makeStyles = (C) => StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.soft },
  card: { backgroundColor: C.card, borderRadius: 16, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: C.line },
  row: { flexDirection: 'row', alignItems: 'center' },
  icon: { width: 64, height: 64, borderRadius: 16, backgroundColor: C.accentSoft, alignItems: 'center',
    justifyContent: 'center', marginRight: 14 },
  img: { width: 40, height: 40, borderRadius: 8 },
  letter: { fontSize: 26, fontWeight: '800', color: C.accentText },
  name: { fontSize: 20, fontWeight: '800', color: C.text },
  tags: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 6 },
  tag: { backgroundColor: C.line, color: C.accentText, fontSize: 12, fontWeight: '700', paddingHorizontal: 10,
    paddingVertical: 4, borderRadius: 10, marginRight: 6, marginBottom: 4, overflow: 'hidden', textTransform: 'capitalize' },
  price: { backgroundColor: C.accentSoft, color: C.accentText },
  newTag: { backgroundColor: C.newBg, color: C.newText },
  h2: { fontSize: 16, fontWeight: '700', color: C.text, marginBottom: 8 },
  body: { fontSize: 15, color: C.text, lineHeight: 22 },
  meta: { fontSize: 13, color: C.muted, marginTop: 8 },
  feat: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 6 },
  featText: { flex: 1, marginLeft: 8, fontSize: 14, color: C.text },
  plat: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.soft, borderRadius: 10,
    paddingHorizontal: 10, paddingVertical: 5, marginRight: 6, marginBottom: 6 },
  platText: { marginLeft: 4, fontSize: 13, color: C.text },
  btn: { backgroundColor: C.accent, borderRadius: 14, height: 52, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'center', marginTop: 4 },
  btnText: { color: C.onAccent, fontSize: 16, fontWeight: '700', marginLeft: 8 },
  btn2: { backgroundColor: C.card, borderColor: C.accent, borderWidth: 1, borderRadius: 14, height: 52,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 10 },
  btn2Text: { color: C.accentText, fontSize: 16, fontWeight: '700', marginLeft: 8 },
  link: { color: C.accentText, textAlign: 'center', marginTop: 14, fontWeight: '600' },
});
