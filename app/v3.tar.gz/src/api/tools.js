import AsyncStorage from '@react-native-async-storage/async-storage';

export const TOOLS_URL = 'https://clampdown-web.github.io/agentscout/api/tools.json';
export const LOGO_URL = 'https://clampdown-web.github.io/agentscout/logo-square.png';
const CACHE_KEY = 'agentscout_tools_v1';
const FAV_KEY = 'agentscout_favs_v1';
const MAX_AGE = 0; // always fetch fresh, cache only as offline fallback

function normalize(t, i) {
  const url = t.url || t.page || '';
  let host = '';
  try { host = url.replace(/^https?:\/\//, '').split('/')[0]; } catch (e) {}
  return {
    id: t.slug || String(i),
    name: t.name || 'Untitled',
    url,
    page: t.page || url,
    category: t.category || 'other',
    description: t.description || '',
    features: Array.isArray(t.key_features) ? t.key_features : [],
    pricing: t.pricing || 'See site',
    priceTag: t.price_tag || 'unknown',
    platforms: Array.isArray(t.platforms) && t.platforms.length ? t.platforms : ['Web'],
    skill: t.skill || '',
    goals: Array.isArray(t.goals) ? t.goals : [],
    weeklyPick: !!t.weekly_pick,
    isNew: !!t.new,
    dateAdded: t.date_added || '',
    repo: t.repo || null,
    logo: t.logo || (host ? 'https://www.google.com/s2/favicons?domain=' + host + '&sz=128' : null),
  };
}

export async function getTools(force = false) {
  let cached = null;
  try {
    const raw = await AsyncStorage.getItem(CACHE_KEY);
    if (raw) cached = JSON.parse(raw);
  } catch (e) {}
  if (!force && cached && Date.now() - cached.time < MAX_AGE) return cached.tools;
  try {
    const res = await fetch(TOOLS_URL);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    const list = Array.isArray(data) ? data : data.tools || [];
    const tools = list.map(normalize);
    await AsyncStorage.setItem(CACHE_KEY, JSON.stringify({ time: Date.now(), tools }));
    return tools;
  } catch (e) {
    if (cached) return cached.tools;
    throw e;
  }
}

// Weekly picks: flagged picks first, then newest tools, up to 8
export function getPicks(tools) {
  const picks = tools.filter((t) => t.weeklyPick);
  const rest = tools.filter((t) => !t.weeklyPick)
    .sort((a, b) => (b.dateAdded || '').localeCompare(a.dateAdded || ''));
  return [...picks, ...rest].slice(0, 8);
}

export async function getFavorites() {
  try { return JSON.parse((await AsyncStorage.getItem(FAV_KEY)) || '[]'); } catch (e) { return []; }
}

export async function toggleFavorite(id) {
  const favs = await getFavorites();
  const next = favs.includes(id) ? favs.filter((f) => f !== id) : [...favs, id];
  await AsyncStorage.setItem(FAV_KEY, JSON.stringify(next));
  return next;
}
