// AgentScout website palette (styles.css :root + dark theme)
export const C = {
  accent: '#5B5BF7', lavender: '#EFEFFE', darkPurple: '#25264D', frame: '#1c1f5a',
  bg: '#FFFFFF', soft: '#F7F8FA', line: '#E6E8EC', text: '#111111', muted: '#5E6573', faint: '#8A909C',
};
