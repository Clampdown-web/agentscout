import React, { useEffect, useState } from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet, Linking } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getFavorites, toggleFavorite } from '../api/tools';

const PURPLE = '#5B5BF7';

export default function ToolDetailScreen({ route, navigation }) {
  const tool = route.params?.tool;
  const [fav, setFav] = useState(false);

  useEffect(() => {
    if (tool) getFavorites().then((f) => setFav(f.includes(tool.id)));
  }, [tool]);

  useEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity onPress={onFav} hitSlop={10}>
          <Ionicons name={fav ? 'heart' : 'heart-outline'} size={24} color={fav ? '#E11D48' : PURPLE} />
        </TouchableOpacity>
      ),
    });
  });

  async function onFav() {
    const f = await toggleFavorite(tool.id);
    setFav(f.includes(tool.id));
  }

  if (!tool) return <View style={s.screen}><Text style={s.body}>Tool not found.</Text></View>;

  return (
    <ScrollView style={s.screen} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <View style={s.card}>
        <View style={s.row}>
          <View style={s.icon}>
            {tool.logo ? <Image source={{ uri: tool.logo }} style={s.img} />
              : <Text style={s.letter}>{tool.name[0]}</Text>}
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.name}>{tool.name}</Text>
            <View style={s.tags}>
              <Text style={s.tag}>{tool.category}</Text>
              <Text style={[s.tag, s.price]}>{tool.priceTag}</Text>
              {tool.isNew ? <Text style={[s.tag, s.newTag]}>new</Text> : null}
            </View>
          </View>
        </View>
      </View>

      <View style={s.card}>
        <Text style={s.h2}>About</Text>
        <Text style={s.body}>{tool.description || 'No description yet.'}</Text>
        <Text style={s.meta}>Pricing: {tool.pricing}</Text>
        {tool.skill ? <Text style={s.meta}>Best for: {tool.skill}</Text> : null}
      </View>

      {tool.features.length > 0 && (
        <View style={s.card}>
          <Text style={s.h2}>Top features</Text>
          {tool.features.map((f, i) => (
            <View key={i} style={s.feat}>
              <Ionicons name="checkmark-circle" size={18} color={PURPLE} />
              <Text style={s.featText}>{f}</Text>
            </View>
          ))}
        </View>
      )}

      <View style={s.card}>
        <Text style={s.h2}>Available on</Text>
        <View style={s.tags}>
          {tool.platforms.map((p) => (
            <View key={p} style={s.plat}>
              <Ionicons name={/android/i.test(p) ? 'logo-android' : /ios|mac|apple/i.test(p) ? 'logo-apple'
                : /cli|terminal/i.test(p) ? 'terminal' : 'globe-outline'} size={14} color="#111111" />
              <Text style={s.platText}>{p}</Text>
            </View>
          ))}
        </View>
      </View>

      <TouchableOpacity style={s.btn} onPress={() => tool.url && Linking.openURL(tool.url)}>
        <Ionicons name="open-outline" size={18} color="#fff" />
        <Text style={s.btnText}>Open Website</Text>
      </TouchableOpacity>
      {tool.repo ? (
        <Text style={s.link} onPress={() => Linking.openURL(tool.repo)}>View source code</Text>
      ) : null}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#FFFFFF' },
  card: { backgroundColor: '#fff', borderRadius: 16, padding: 16, marginBottom: 12 },
  row: { flexDirection: 'row', alignItems: 'center' },
  icon: { width: 64, height: 64, borderRadius: 16, backgroundColor: '#EFEFFE', alignItems: 'center',
    justifyContent: 'center', marginRight: 14 },
  img: { width: 40, height: 40, borderRadius: 8 },
  letter: { fontSize: 26, fontWeight: '800', color: PURPLE },
  name: { fontSize: 20, fontWeight: '800', color: '#111111' },
  tags: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 6 },
  tag: { backgroundColor: '#E6E8EC', color: PURPLE, fontSize: 12, fontWeight: '700', paddingHorizontal: 10,
    paddingVertical: 4, borderRadius: 10, marginRight: 6, marginBottom: 4, overflow: 'hidden', textTransform: 'capitalize' },
  price: { backgroundColor: '#EFEFFE', color: '#5B5BF7' },
  newTag: { backgroundColor: '#FEF3C7', color: '#B45309' },
  h2: { fontSize: 16, fontWeight: '700', color: '#111111', marginBottom: 8 },
  body: { fontSize: 15, color: '#111111', lineHeight: 22 },
  meta: { fontSize: 13, color: '#5E6573', marginTop: 8 },
  feat: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 6 },
  featText: { flex: 1, marginLeft: 8, fontSize: 14, color: '#111111' },
  plat: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F3F4F6', borderRadius: 10,
    paddingHorizontal: 10, paddingVertical: 5, marginRight: 6, marginBottom: 6 },
  platText: { marginLeft: 4, fontSize: 13, color: '#111111' },
  btn: { backgroundColor: PURPLE, borderRadius: 14, height: 52, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'center', marginTop: 4 },
  btnText: { color: '#fff', fontSize: 16, fontWeight: '700', marginLeft: 8 },
  link: { color: PURPLE, textAlign: 'center', marginTop: 14, fontWeight: '600' },
});
