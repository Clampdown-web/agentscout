import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, SectionList, ScrollView, Image, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { getTools } from '../api/tools';

const PURPLE = '#5B5BF7';
const DARK = '#5B5BF7';
const PRICES = ['Any price', 'Free', 'Freemium', 'Paid'];

export default function BrowseScreen({ navigation }) {
  const [tools, setTools] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cat, setCat] = useState('All');
  const [price, setPrice] = useState('Any price');

  useEffect(() => { getTools().then(setTools).catch(() => {}).finally(() => setLoading(false)); }, []);

  const cats = useMemo(() => ['All', ...[...new Set(tools.map((t) => t.category))].sort()], [tools]);

  const sections = useMemo(() => {
    const groups = {};
    tools.forEach((t) => {
      if (cat !== 'All' && t.category !== cat) return;
      if (price !== 'Any price' && t.priceTag !== price.toLowerCase()) return;
      (groups[t.category] = groups[t.category] || []).push(t);
    });
    return Object.keys(groups).sort().map((k) => ({ title: k, data: groups[k] }));
  }, [tools, cat, price]);

  if (loading) return <View style={s.loading}><ActivityIndicator size="large" color={PURPLE} /></View>;

  const Chips = ({ items, value, onChange }) => (
    <ScrollView horizontal style={{ flexGrow: 0 }} showsHorizontalScrollIndicator={false} contentContainerStyle={s.chips}>
      {items.map((c) => (
        <TouchableOpacity key={c} onPress={() => onChange(c)} style={[s.chip, value === c && s.chipOn]}>
          <Text style={[s.chipText, value === c && s.chipTextOn]}>{c}</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );

  return (
    <SafeAreaView style={s.screen} edges={['top']}>
      <Text style={s.h1}>Browse</Text>
      <Chips items={PRICES} value={price} onChange={setPrice} />
      <Chips items={cats} value={cat} onChange={setCat} />
      <SectionList
        sections={sections}
        keyExtractor={(t) => t.id}
        stickySectionHeadersEnabled={false}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 24 }}
        ListEmptyComponent={<Text style={s.empty}>No tools match these filters.</Text>}
        renderSectionHeader={({ section }) => (
          <Text style={s.section}>{section.title} · {section.data.length}</Text>
        )}
        renderItem={({ item }) => (
          <TouchableOpacity style={s.card} onPress={() => navigation.navigate('ToolDetail', { tool: item })}>
            <View style={s.icon}>
              {item.logo ? <Image source={{ uri: item.logo }} style={s.img} />
                : <Text style={s.letter}>{item.name[0]}</Text>}
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.name} numberOfLines={1}>{item.name}</Text>
              <Text style={s.desc} numberOfLines={2}>{item.description}</Text>
            </View>
            <Text style={s.price}>{item.priceTag}</Text>
            <Ionicons name="chevron-forward" size={18} color="#8A909C" />
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#FFFFFF' },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFFFFF' },
  h1: { fontSize: 22, fontWeight: '800', color: '#111111', paddingHorizontal: 16, paddingTop: 16 },
  chips: { paddingHorizontal: 16, paddingTop: 10, alignItems: 'center' },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: '#fff',
    marginRight: 8, borderWidth: 1, borderColor: '#E6E8EC' },
  chipOn: { backgroundColor: DARK, borderColor: DARK },
  chipText: { color: '#111111', fontWeight: '600', textTransform: 'capitalize' },
  chipTextOn: { color: '#fff' },
  section: { fontSize: 16, fontWeight: '700', color: '#111111', marginTop: 18, marginBottom: 8, textTransform: 'capitalize' },
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 14, padding: 12,
    marginBottom: 8, borderWidth: 1, borderColor: '#E6E8EC' },
  icon: { width: 44, height: 44, borderRadius: 12, backgroundColor: '#EFEFFE', alignItems: 'center',
    justifyContent: 'center', marginRight: 12 },
  img: { width: 28, height: 28, borderRadius: 6 },
  letter: { fontSize: 20, fontWeight: '800', color: PURPLE },
  name: { fontSize: 15, fontWeight: '700', color: '#111111' },
  desc: { fontSize: 12, color: '#5E6573', marginTop: 2 },
  price: { fontSize: 11, fontWeight: '700', color: '#5B5BF7', backgroundColor: '#EFEFFE', paddingHorizontal: 8,
    paddingVertical: 3, borderRadius: 8, marginHorizontal: 8, overflow: 'hidden', textTransform: 'capitalize' },
  empty: { textAlign: 'center', color: '#5E6573', marginTop: 40 },
});
