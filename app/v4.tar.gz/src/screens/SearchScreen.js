import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, TextInput, FlatList, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { getTools } from '../api/tools';
import { useTheme, useStyles } from '../theme';


export default function SearchScreen({ navigation }) {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  const [tools, setTools] = useState([]);
  const [query, setQuery] = useState('');

  useEffect(() => { getTools().then(setTools).catch(() => {}); }, []);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return tools;
    return tools.filter((t) => (t.name + ' ' + t.description).toLowerCase().includes(q));
  }, [tools, query]);

  return (
    <SafeAreaView style={s.screen} edges={['top']}>
      <Text style={s.h1}>Search</Text>
      <View style={s.search}>
        <Ionicons name="search" size={18} color={C.faint} />
        <TextInput style={s.input} placeholder={"Search " + tools.length + " AI agent tools"} placeholderTextColor={C.faint}
          value={query} onChangeText={setQuery} autoFocus autoCorrect={false} />
        {query ? <Ionicons name="close-circle" size={18} color={C.faint} onPress={() => setQuery('')} /> : null}
      </View>
      <Text style={s.count}>{results.length} tools</Text>
      <FlatList
        data={results}
        keyExtractor={(t) => t.id}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 24 }}
        ListEmptyComponent={<Text style={s.empty}>No tools found</Text>}
        renderItem={({ item }) => (
          <TouchableOpacity style={s.card} onPress={() => navigation.navigate('ToolDetail', { tool: item })}>
            <View style={s.icon}>
              {item.logo ? <Image source={{ uri: item.logo }} style={s.img} />
                : <Text style={s.letter}>{item.name[0]}</Text>}
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.name} numberOfLines={1}>{item.name}</Text>
              <Text style={s.desc} numberOfLines={2}>{item.description}</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={C.faint} />
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
}

const makeStyles = (C) => StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  h1: { fontSize: 22, fontWeight: '800', color: C.text, paddingHorizontal: 16, paddingTop: 16 },
  search: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, marginHorizontal: 16,
    marginTop: 10, borderRadius: 10, paddingHorizontal: 12, height: 46, borderWidth: 1, borderColor: C.line },
  input: { flex: 1, marginLeft: 8, fontSize: 15, color: C.text },
  count: { color: C.muted, fontSize: 13, marginHorizontal: 16, marginTop: 10, marginBottom: 6 },
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: 14, padding: 12,
    marginBottom: 8, borderWidth: 1, borderColor: C.line },
  icon: { width: 44, height: 44, borderRadius: 12, backgroundColor: C.accentSoft, alignItems: 'center',
    justifyContent: 'center', marginRight: 12 },
  img: { width: 36, height: 36, borderRadius: 8 },
  letter: { fontSize: 20, fontWeight: '800', color: C.accentText },
  name: { fontSize: 15, fontWeight: '700', color: C.text },
  desc: { fontSize: 12, color: C.muted, marginTop: 2 },
  empty: { textAlign: 'center', color: C.muted, marginTop: 40, fontSize: 15 },
});
