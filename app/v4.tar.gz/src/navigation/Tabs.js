import React from 'react';
import { View, Text, Image, StyleSheet, ScrollView, Linking } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import HomeScreen from '../screens/HomeScreen';
import BrowseScreen from '../screens/BrowseScreen';
import SearchScreen from '../screens/SearchScreen';
import { LOGO_URL } from '../api/tools';
import { useTheme, useStyles } from '../theme';

const Tab = createBottomTabNavigator();

function OverviewScreen() {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  return (
    <View style={s.center}>
      <Ionicons name="stats-chart" size={48} color={C.accent} />
      <Text style={s.title}>Overview</Text>
      <Text style={s.body}>Browse, search, favorites and the agent finder quiz are coming next.</Text>
    </View>
  );
}

function AboutScreen() {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  return (
    <ScrollView contentContainerStyle={s.center}>
      <Image source={{ uri: LOGO_URL }} style={s.logo} resizeMode="contain" />
      <Text style={s.title}>AgentScout</Text>
      <Text style={s.body}>Find the right AI agent for the job. A curated directory of AI agents and tools, updated weekly.</Text>
      <Text style={s.link} onPress={() => Linking.openURL('https://clampdown-web.github.io/agentscout/')}>
        Visit the website
      </Text>
    </ScrollView>
  );
}

export default function Tabs() {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarActiveTintColor: C.accent,
        tabBarInactiveTintColor: C.faint,
        tabBarStyle: { backgroundColor: C.card, borderTopColor: C.line },
        headerStyle: { backgroundColor: C.card },
        headerTintColor: C.text,
        sceneStyle: { backgroundColor: C.bg },
        headerTitleStyle: { fontWeight: '700' },
        tabBarIcon: ({ color, size, focused }) => {
          const icons = { 'AI Tools': 'grid', Browse: 'list', Search: 'search', Overview: 'pie-chart', About: 'information-circle' };
          const name = icons[route.name] + (focused ? '' : '-outline');
          return <Ionicons name={name} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="AI Tools" component={HomeScreen} options={{ headerShown: false }} />
      <Tab.Screen name="Browse" component={BrowseScreen} options={{ headerShown: false }} />
      <Tab.Screen name="Search" component={SearchScreen} options={{ headerShown: false }} />
      <Tab.Screen name="Overview" component={OverviewScreen} />
      <Tab.Screen name="About" component={AboutScreen} />
    </Tab.Navigator>
  );
}

const makeStyles = (C) => StyleSheet.create({
  center: { flexGrow: 1, alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: C.bg },
  logo: { width: 140, height: 140, borderRadius: 24, marginBottom: 12 },
  title: { fontSize: 22, fontWeight: '700', color: C.text, marginTop: 12 },
  body: { fontSize: 15, color: C.muted, textAlign: 'center', marginTop: 8, lineHeight: 22 },
  link: { color: C.accentText, fontWeight: '700', marginTop: 16, fontSize: 16 },
});
