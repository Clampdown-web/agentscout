import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { useColorScheme } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// AgentScout website palettes (styles.css :root and [data-theme=dark], generate.css)
export const light = {
  dark: false,
  bg: '#FFFFFF', soft: '#F7F8FA', card: '#FFFFFF', line: '#E6E8EC',
  text: '#111111', muted: '#5E6573', faint: '#8A909C',
  accent: '#5B5BF7', accentText: '#5B5BF7', accentSoft: '#EFEFFE', onAccent: '#FFFFFF',
  newBg: '#FEF3C7', newText: '#B45309', danger: '#B91C1C', heart: '#E11D48',
};
export const dark = {
  dark: true,
  bg: '#0E1015', soft: '#151821', card: '#171A22', line: '#2A2F3A',
  text: '#E8EAF0', muted: '#A9B0BE', faint: '#8E97A8',
  accent: '#5B5BF7', accentText: '#9393FF', accentSoft: '#25264D', onAccent: '#FFFFFF',
  newBg: '#3A2E12', newText: '#FBBF24', danger: '#F87171', heart: '#FB7185',
};
// Backward-compatible export
export const C = light;

const KEY = 'agentscout.themeMode';
const ThemeContext = createContext({ C: light, mode: 'system', setMode: () => {}, toggle: () => {} });

export function ThemeProvider({ children }) {
  const system = useColorScheme();
  const [mode, setModeState] = useState('system'); // 'system' | 'light' | 'dark'

  useEffect(() => {
    AsyncStorage.getItem(KEY).then((v) => { if (v === 'light' || v === 'dark' || v === 'system') setModeState(v); }).catch(() => {});
  }, []);

  const setMode = (m) => { setModeState(m); AsyncStorage.setItem(KEY, m).catch(() => {}); };
  const isDark = mode === 'system' ? system === 'dark' : mode === 'dark';
  const C = isDark ? dark : light;
  const value = useMemo(() => ({ C, mode, isDark, setMode, toggle: () => setMode(isDark ? 'light' : 'dark') }), [C, mode, isDark]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export const useTheme = () => useContext(ThemeContext);

// Build a StyleSheet from a palette, memoised per palette
export function useStyles(make) {
  const { C } = useTheme();
  return useMemo(() => make(C), [C]);
}
