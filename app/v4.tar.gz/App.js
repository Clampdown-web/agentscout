import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import Tabs from './src/navigation/Tabs';
import ToolDetailScreen from './src/screens/ToolDetailScreen';
import { ThemeProvider, useTheme } from './src/theme';

const Stack = createNativeStackNavigator();

function Root() {
  const { C, isDark } = useTheme();
  const base = isDark ? DarkTheme : DefaultTheme;
  const navTheme = { ...base, colors: { ...base.colors, primary: C.accent, background: C.bg, card: C.card,
    text: C.text, border: C.line, notification: C.accent } };
  return (
    <NavigationContainer theme={navTheme}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <Stack.Navigator>
        <Stack.Screen name="Main" component={Tabs} options={{ headerShown: false }} />
        <Stack.Screen name="ToolDetail" component={ToolDetailScreen}
          options={({ route }) => ({ title: route.params?.tool?.name || 'Tool', headerTintColor: C.accentText,
            headerStyle: { backgroundColor: C.card }, headerTitleStyle: { color: C.text } })} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <Root />
      </ThemeProvider>
    </SafeAreaProvider>
  );
}
