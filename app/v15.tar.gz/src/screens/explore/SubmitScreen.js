import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, ActivityIndicator, KeyboardAvoidingView, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme, useStyles } from '../../theme';
import { useSections } from './common';
import { track } from '../../api/analytics';

// Native version of submit.html. POSTs the same JSON to the same agentscout-image Worker /submit endpoint.
const ENDPOINT = 'https://agentscout-image.agentscouthq.workers.dev/submit';
const PRICING = ['Open source', 'Free', 'Freemium', 'Paid', 'Open source + cloud', 'Enterprise / contact sales'];

export default function SubmitScreen() {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  const { data } = useSections();
  // Same choices as submit.html: the site's categories plus "other".
  const base = (data && data.submit && data.submit.categories) || [];
  const cats = base.length && !base.includes('other') ? [...base, 'other'] : base;
  const [f, setF] = useState({ name: '', website: '', github: '', category: '', pricing: '', desc: '', email: '', x: '' });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [done, setDone] = useState(false);
  const set = (k) => (v) => setF({ ...f, [k]: v });
  const url = (u) => !u || /^https?:\/\/[^\s.]+\.[^\s]+$/i.test(u.trim());

  const submit = async () => {
    setErr('');
    if (!f.name.trim() || !f.website.trim() || !f.desc.trim()) return setErr('Please fill in the tool name, official website and a short description.');
    if (!url(f.website) || !url(f.github)) return setErr('Please enter full links starting with https://');
    if (f.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.email)) return setErr('Please check the email address.');
    setBusy(true);
    try {
      const r = await fetch(ENDPOINT, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-AgentScout-App': '1' },
        body: JSON.stringify({ ...f, name: f.name.trim(), website: f.website.trim(), github: f.github.trim(), desc: f.desc.trim(), company: '' }) });
      let j = {}; try { j = await r.json(); } catch (e) {}
      if (!r.ok || !j.ok) throw new Error(j.error || 'Something went wrong.');
      setDone(true); track('submit_tool');
    } catch (e) {
      setErr(e.message && e.message !== 'Network request failed' ? e.message : 'Could not reach the server. Please try again.');
    }
    setBusy(false);
  };

  if (done) {
    return (
      <View style={[s.screen, { padding: 16 }]}>
        <View style={s.box}>
          <Ionicons name="checkmark-circle" size={36} color={C.accent} />
          <Text style={s.h}>Thanks! Your tool was submitted.</Text>
          <Text style={s.p}>We check every submission by hand and add tools that fit the directory. If you left an email, we'll reply there.</Text>
          <TouchableOpacity style={[s.btn, { marginTop: 14 }]} onPress={() => { setF({ name: '', website: '', github: '', category: '', pricing: '', desc: '', email: '', x: '' }); setDone(false); }}>
            <Text style={s.btnText}>Submit another</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
  const Field = ({ k, label, req, ...p }) => (
    <View style={{ marginBottom: 12 }}>
      <Text style={s.label}>{label}{req ? <Text style={{ color: C.accentText }}> *</Text> : null}</Text>
      <TextInput style={[s.input, p.multiline && { height: 96, textAlignVertical: 'top', paddingTop: 10 }]} value={f[k]} onChangeText={set(k)}
        placeholderTextColor={C.faint} autoCapitalize="none" accessibilityLabel={label} {...p} />
    </View>
  );
  const Choice = ({ k, label, items }) => (
    <View style={{ marginBottom: 12 }}>
      <Text style={s.label}>{label}</Text>
      <View style={s.chips}>
        {items.map((c) => (
          <TouchableOpacity key={c} style={[s.chip, f[k] === c && s.chipOn]} onPress={() => set(k)(f[k] === c ? '' : c)}>
            <Text style={[s.chipText, f[k] === c && s.chipTextOn]}>{c}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
  return (
    <KeyboardAvoidingView style={s.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 48 }} keyboardShouldPersistTaps="handled">
        <Text style={s.p}>Know an AI agent tool we should list? Send it in. Every submission is checked by hand; listings are free.</Text>
        <View style={[s.box, { marginTop: 12 }]}>
          {Field({ k: 'name', label: 'Tool name', req: true, autoCapitalize: 'words', placeholder: 'e.g. Browser Use' })}
          {Field({ k: 'website', label: 'Official website', req: true, keyboardType: 'url', placeholder: 'https://' })}
          {Field({ k: 'github', label: 'GitHub repo (optional)', keyboardType: 'url', placeholder: 'https://github.com/…' })}
          {Choice({ k: 'category', label: 'Category', items: cats })}
          {Choice({ k: 'pricing', label: 'Pricing', items: PRICING })}
          {Field({ k: 'desc', label: 'What does it do?', req: true, multiline: true, autoCapitalize: 'sentences', maxLength: 500, placeholder: 'One or two sentences' })}
          {Field({ k: 'email', label: 'Your email (optional)', keyboardType: 'email-address', placeholder: 'you@example.com' })}
          {Field({ k: 'x', label: 'X handle (optional)', placeholder: '@handle' })}
          {err ? <Text style={s.err} accessibilityLiveRegion="polite">{err}</Text> : null}
          <TouchableOpacity style={[s.btn, busy && { opacity: 0.6 }]} onPress={submit} disabled={busy} accessibilityRole="button">
            {busy ? <ActivityIndicator color={C.bg} /> : <Text style={s.btnText}>Submit tool</Text>}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const makeStyles = (C) => StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  box: { backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 14, padding: 16 },
  h: { fontSize: 18, fontWeight: '800', color: C.text, marginTop: 8 },
  p: { fontSize: 14.5, color: C.muted, lineHeight: 21, marginTop: 4 },
  label: { fontSize: 14, fontWeight: '600', color: C.text, marginBottom: 6 },
  input: { height: 44, borderWidth: 1, borderColor: C.line, borderRadius: 8, paddingHorizontal: 12, fontSize: 15, color: C.text, backgroundColor: C.card },
  chips: { flexDirection: 'row', flexWrap: 'wrap' },
  chip: { borderWidth: 1, borderColor: C.line, borderRadius: 999, paddingHorizontal: 11, paddingVertical: 6, marginRight: 6, marginBottom: 6, backgroundColor: C.bg },
  chipOn: { backgroundColor: C.accent, borderColor: C.accent },
  chipText: { fontSize: 13, color: C.text },
  chipTextOn: { color: C.onAccent, fontWeight: '600' },
  err: { color: C.danger, marginBottom: 10 },
  btn: { height: 46, borderRadius: 8, backgroundColor: C.text, alignItems: 'center', justifyContent: 'center' },
  btnText: { color: C.bg, fontWeight: '600', fontSize: 15 },
});
