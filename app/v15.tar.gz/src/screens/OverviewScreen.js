import React, { useEffect, useRef, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Linking, Share, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getTools, stats } from '../api/tools';
import { getQuiz, rank, shareUrl } from '../api/quiz';
import useFavorites from '../api/useFavorites';
import ToolCard from '../components/ToolCard';
import { track } from '../api/analytics';
import { useScrollButtons } from '../components/ScrollButtons';
import { useTheme, useStyles } from '../theme';
import { SafeAreaView } from 'react-native-safe-area-context';
import ThemeToggle from '../components/ThemeToggle';


const STEPS = ['What you need done', 'How technical you are', 'Your budget', 'Whether you want open source'];

export default function OverviewScreen({ navigation }) {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  const ref = useRef(null);
  const scroll = useScrollButtons(ref);
  const [tools, setTools] = useState([]);
  const [quiz, setQuiz] = useState(null);
  const [err, setErr] = useState('');
  const [step, setStep] = useState(-1);
  const [ans, setAns] = useState({});
  const favs = useFavorites();

  useEffect(() => {
    getTools().then(setTools).catch(() => {});
    getQuiz().then(setQuiz).catch(() => setErr("Couldn't load the quiz. Check your connection."));
  }, []);

  const open = (t) => navigation.navigate('ToolDetail', { tool: t });
  const saved = tools.filter((t) => favs.includes(t.id));
  const st = stats(tools);
  const Q = quiz ? quiz.questions : [];
  const done = quiz && step >= Q.length;
  const results = done ? rank(tools, ans, quiz) : [];
  const pick = (key, id) => { const a = { ...ans, [key]: id }; setAns(a); setStep(step + 1); if (quiz && step + 1 >= quiz.questions.length) track('quiz_complete', a.goal); };
  const back = () => { const k = Q[step - 1].key; const a = { ...ans }; delete a[k]; setAns(a); setStep(step - 1); };
  const retake = () => { setAns({}); setStep(0); ref.current && ref.current.scrollTo({ y: 0, animated: true }); };
  const share = async () => {
    const url = shareUrl(ans, quiz);
    if (Platform.OS === 'web') return Linking.openURL(url);
    try { await Share.share({ message: 'My AI agent matches on AgentScout: ' + url, url }); } catch (e) { Linking.openURL(url); }
  };
  const label = (k) => { const q = Q.find((x) => x.key === k); const o = q && q.options.find((x) => x.id === ans[k]); return o ? o.label : ''; };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.bg }} edges={['top']}>
      <View style={s.titleRow}><Text style={s.title}>Saved</Text></View>
      <ScrollView ref={ref} contentContainerStyle={[s.wrap, { paddingBottom: scroll.padBottom }]} {...scroll.listProps}>
        {tools.length ? (
          <View style={s.stats}>
            {[[st.total, 'Tools'], [st.week, 'New this week'], [st.cats, 'Categories'], [saved.length, 'Saved']].map(([n, l]) => (
              <View key={l} style={s.stat}><Text style={s.statNum}>{n}</Text><Text style={s.statLab} numberOfLines={1}>{l}</Text></View>
            ))}
          </View>
        ) : null}

        <Text style={[s.h, { marginTop: 8 }]}>♥ Saved tools</Text>
        {saved.length ? saved.map((t) => <ToolCard key={t.id} tool={t} onPress={() => open(t)} />) : (
          <View style={[s.box, { alignItems: 'center' }]}>
            <Ionicons name="heart-outline" size={32} color={C.accent} />
            <Text style={[s.q, { textAlign: 'center', marginTop: 8, marginBottom: 4 }]}>No saved tools yet</Text>
            <Text style={[s.muted, { textAlign: 'center' }]}>Tap the heart on any tool to save it. Saves stay on this device.</Text>
          </View>
        )}

        <Text style={s.h}>Agent Finder Quiz</Text>
        <View style={s.box}>
          {err ? <Text style={s.q}>{err}</Text> : !quiz ? <Text style={s.muted}>Loading…</Text> : step < 0 ? (
            <>
              <Text style={s.q}>Four quick taps:</Text>
              {STEPS.map((t, i) => <Text key={t} style={s.li}>{i + 1}. {t}</Text>)}
              <Text style={[s.muted, { marginTop: 8, marginBottom: 14 }]}>We rank the best matches from the directory.</Text>
              <TouchableOpacity style={s.primary} onPress={() => setStep(0)} accessibilityRole="button">
                <Text style={s.primaryText}>Start the quiz</Text>
              </TouchableOpacity>
            </>
          ) : !done ? (
            <>
              <Text style={s.progress}>Question {step + 1} of {Q.length}{Q[step].optional ? ' · optional' : ''}</Text>
              <View style={s.bar}><View style={[s.barFill, { width: Math.round((step / Q.length) * 100) + '%' }]} /></View>
              <Text style={s.q}>{Q[step].q}</Text>
              {Q[step].options.map((o) => (
                <TouchableOpacity key={o.id} style={s.opt} onPress={() => pick(Q[step].key, o.id)} accessibilityRole="button">
                  <View style={{ flex: 1 }}>
                    <Text style={s.optText}>{o.label}</Text>
                    {o.hint ? <Text style={s.hint}>{o.hint}</Text> : null}
                  </View>
                  <Ionicons name="chevron-forward" size={18} color={C.faint} />
                </TouchableOpacity>
              ))}
              <View style={s.btnRow}>
                {step > 0 ? <TouchableOpacity style={s.secondary} onPress={back}><Text style={s.secondaryText}>← Back</Text></TouchableOpacity> : null}
                {Q[step].optional ? <TouchableOpacity style={s.secondary} onPress={() => pick(Q[step].key, 'any')}><Text style={s.secondaryText}>Skip</Text></TouchableOpacity> : null}
              </View>
            </>
          ) : (
            <>
              <Text style={s.progress}>Your answers</Text>
              <View style={s.chips}>{Q.map((q) => ans[q.key] ? <Text key={q.key} style={s.chip}>{label(q.key)}</Text> : null)}</View>
              <Text style={s.q}>{results.length ? `Your top ${results.length} matches` : 'No close matches'}</Text>
              <View style={s.btnRow}>
                <TouchableOpacity style={s.secondary} onPress={retake}><Text style={s.secondaryText}>↺ Retake</Text></TouchableOpacity>
                <TouchableOpacity style={s.primary} onPress={share}><Text style={s.primaryText}>Share</Text></TouchableOpacity>
              </View>
            </>
          )}
        </View>
        {results.map((t, i) => (
          <View key={t.id}><Text style={s.rank}>#{i + 1}</Text><ToolCard tool={t} onPress={() => open(t)} /></View>
        ))}

        <TouchableOpacity style={s.menu} onPress={() => Linking.openURL('https://agentscouthq.com/new.html')} accessibilityRole="link">
          <Ionicons name="sparkles-outline" size={20} color={C.accentText} />
          <Text style={s.menuText}>New tools on the website</Text>
          <Ionicons name="open-outline" size={18} color={C.faint} />
        </TouchableOpacity>
      </ScrollView>
      {scroll.buttons}
    </SafeAreaView>
  );
}

const makeStyles = (C) => StyleSheet.create({
  titleRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 16, paddingBottom: 4 },
  title: { flex: 1, fontSize: 22, fontWeight: '800', color: C.text },
  wrap: { padding: 16, paddingTop: 4 },
  stats: { flexDirection: 'row', backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 14, paddingVertical: 12, marginBottom: 6 },
  stat: { flex: 1, alignItems: 'center' },
  statNum: { fontSize: 20, fontWeight: '800', color: C.text },
  statLab: { fontSize: 11, color: C.muted, marginTop: 2 },
  h: { fontSize: 19, fontWeight: '800', color: C.text, marginTop: 18, marginBottom: 10 },
  box: { backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 14, padding: 16, marginBottom: 10 },
  progress: { fontSize: 12, fontWeight: '700', color: C.accentText, marginBottom: 6 },
  bar: { height: 6, borderRadius: 99, backgroundColor: C.line, marginBottom: 14, overflow: 'hidden' },
  barFill: { height: 6, backgroundColor: C.accent },
  q: { fontSize: 17, fontWeight: '700', color: C.text, marginBottom: 12, lineHeight: 23 },
  li: { fontSize: 15, color: C.text, lineHeight: 24, marginLeft: 4 },
  muted: { fontSize: 14, color: C.muted, lineHeight: 20 },
  opt: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: C.line, backgroundColor: C.bg, borderRadius: 12,
    paddingVertical: 12, paddingHorizontal: 14, marginBottom: 8, minHeight: 54 },
  optText: { fontSize: 15, color: C.text, fontWeight: '600' },
  hint: { fontSize: 13, color: C.muted, marginTop: 2 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 10 },
  chip: { fontSize: 12, color: C.text, borderWidth: 1, borderColor: C.line, borderRadius: 999, paddingHorizontal: 9, paddingVertical: 3,
    marginRight: 6, marginBottom: 6, overflow: 'hidden' },
  btnRow: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 4 },
  primary: { backgroundColor: C.accent, borderRadius: 999, paddingVertical: 11, paddingHorizontal: 18, alignSelf: 'flex-start', marginRight: 10 },
  primaryText: { color: C.onAccent, fontWeight: '700' },
  secondary: { borderWidth: 1, borderColor: C.line, borderRadius: 999, paddingVertical: 11, paddingHorizontal: 18, marginRight: 10 },
  secondaryText: { color: C.text, fontWeight: '700' },
  rank: { fontSize: 12, fontWeight: '800', color: C.accentText, marginBottom: 4 },
  menu: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 14,
    paddingVertical: 14, paddingHorizontal: 16, marginTop: 18 },
  menuText: { flex: 1, marginLeft: 12, fontSize: 15, fontWeight: '600', color: C.text },
});
