import React, { useRef, useEffect, useMemo, useState, useCallback } from 'react';
import { View, Text, TextInput, FlatList, ScrollView, Image, TouchableOpacity,
  StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { getPicks, getTools, getFavorites, LOGO_URL, newest, isThisWeek, fmtDate, stats, summaryLine, getMeta, shortDate } from '../api/tools';
import ThemeToggle, { useBarSize } from '../components/ThemeToggle';
import CheckedPill from '../components/CheckedPill';
import { CAT_ICONS } from '../api/catIcons';
import ToolCard from '../components/ToolCard';
import { useWindowDimensions } from 'react-native';
import { useTheme, useStyles } from '../theme';
import { useScrollButtons } from '../components/ScrollButtons';
import { getGeneratorDaily, getEditorsPick } from '../api/sections';
import { onLive } from '../api/live';
import { openTile } from './explore/ExploreScreen';
import { track, trackSearch } from '../api/analytics';



export default function HomeScreen({ navigation }) {
  const { C, isDark, toggle } = useTheme();
  const s = useStyles(makeStyles);
  const bar = useBarSize();
  const [tools, setTools] = useState([]);
  const listRef = useRef(null);
  const scroll = useScrollButtons(listRef);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);
  const [query, setQuery] = useState('');
  const [chip, setChip] = useState('All');
  const [favs, setFavs] = useState([]);
  const { width } = useWindowDimensions();
  const cols = width >= 700 ? 2 : 1;
  useEffect(() => navigation.addListener('focus', () => { getFavorites().then(setFavs); }), [navigation]);

  const load = useCallback(async (force) => {
    try {
      setError(null);
      setTools(await getTools(force));
    } catch (e) {
      setError('Could not load tools. Pull down to retry.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { load(false); }, [load]);
  const [daily, setDaily] = useState(null);
  useEffect(() => { getGeneratorDaily().then(setDaily).catch(() => {}); }, []);

  const chips = useMemo(() => {
    const counts = {};
    tools.forEach((t) => { counts[t.category] = (counts[t.category] || 0) + 1; });
    return ['All', 'Saved', 'Free', ...Object.keys(counts).sort((a, b) => counts[b] - counts[a])];
  }, [tools]);

  const ordered = useMemo(() => newest(tools), [tools]);
  const thisWeek = useMemo(() => ordered.filter(isThisWeek), [ordered]);
  const recent = useMemo(() => [...ordered.filter((t) => !t.seed), ...ordered.filter((t) => t.seed)].slice(0, 12), [ordered]);
  const st = useMemo(() => stats(tools), [tools]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return tools.filter((t) => {
      if (chip === 'Free' && t.priceTag !== 'free' && t.priceTag !== 'freemium') return false;
      if (chip === 'Saved' && !favs.includes(t.id)) return false;
      if (chip !== 'All' && chip !== 'Free' && chip !== 'Saved' && t.category !== chip) return false;
      if (!q) return true;
      return (t.name + ' ' + t.description + ' ' + t.category).toLowerCase().includes(q);
    });
  }, [tools, query, chip, favs]);

  const open = (tool) => navigation.navigate('ToolDetail', { tool });

  const [pickData, setPickData] = useState(null);
  useEffect(() => { const get = () => getEditorsPick().then(setPickData).catch(() => {}); get(); return onLive(() => { get(); load(false); }); }, [load]);
  const pickTool = useMemo(() => pickData && tools.find((t) => t.id === pickData.slug), [pickData, tools]);
  const home = !query && chip === 'All';

  const header = (
    <View>
      {/* Brand bar (site nav) */}
      <View style={s.top}>
        <Image source={{ uri: LOGO_URL }} style={s.logo} />
        <Text style={s.brand}>Agent<Text style={{ color: C.accentText }}>Scout</Text></Text>
      </View>

      {/* Hero, same order and copy as index.html */}
      <View style={s.hero}>
        <CheckedPill count={tools.length} style={{ marginTop: 0 }} />
        <Text style={[s.h1, width >= 600 && { fontSize: 36, lineHeight: 42 }]}>AI Agents Directory: the agent tools actually worth trying.</Text>
        <Text style={s.lede}>A curated, link-checked directory of agent tools for builders and everyday users, sorted by what they actually do.</Text>
      </View>
      {/* Quick links, styled like the website nav */}
      <ScrollView horizontal={width < 600} scrollEnabled={width < 600} showsHorizontalScrollIndicator={false}
        style={{ marginTop: 14, flexGrow: 0 }} contentContainerStyle={[{ paddingHorizontal: 16 }, width >= 600 && s.quickWrap]}>
        {QUICK.map(([label, key]) => (
          <TouchableOpacity key={key} style={s.quick} onPress={() => openTile(navigation, key)} accessibilityRole="link" hitSlop={4}>
            <Text style={s.quickText}>{label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <View style={s.searchRow}>
        <View style={[s.search, { height: bar.size }]}>
          <Ionicons name="search" size={18} color={C.faint} />
          <TextInput style={s.input} placeholder="What do you want an agent to do?" placeholderTextColor={C.faint}
            value={query} onChangeText={(v) => { setQuery(v); trackSearch(v); }} onSubmitEditing={() => trackSearch(query, true)} returnKeyType="search" accessibilityLabel="Search tools" />
          {query ? <Ionicons name="close-circle" size={18} color={C.faint} onPress={() => setQuery('')} /> : null}
        </View>
        <ThemeToggle />
      </View>
      <TouchableOpacity onPress={() => { track('button_click', 'quiz'); navigation.navigate('Saved'); }} hitSlop={{ top: 10, bottom: 10, left: 8, right: 8 }}
        accessibilityRole="link" accessibilityLabel="Not sure where to start? Take the 30-second Agent Finder Quiz" style={s.quizRow}>
        <Text style={s.quizText}>Not sure where to start? <Text style={s.quizLink}>Take the 30-second Agent Finder Quiz →</Text></Text>
      </TouchableOpacity>
      <View style={s.ctaRow}>
        <TouchableOpacity style={s.cta} onPress={() => { track('button_click', 'submit'); navigation.navigate('Submit'); }} accessibilityRole="button">
          <Ionicons name="add" size={18} color={C.onAccent} /><Text style={s.ctaText}>Submit a tool</Text>
        </TouchableOpacity>
      </View>
      <View style={s.heroStats}>
        <Text style={s.hs}><Text style={s.hsB}>{st.total}</Text> tools</Text>
        <Text style={s.hs}><Text style={s.hsB}>{st.week}</Text> new this week</Text>
        <Text style={s.hs}><Text style={s.hsB}>{st.cats}</Text> categories</Text>
        <Text style={s.hs}>Every link checked</Text>
      </View>

      {home ? (
        <>
          {/* Image generator card (site .homegen) */}
          <TouchableOpacity style={s.gen} onPress={() => { track('button_click', 'generate'); navigation.navigate('Generate'); }} accessibilityRole="button">
            {daily ? <Image source={{ uri: daily.image }} style={StyleSheet.absoluteFill} resizeMode="cover" /> : null}
            <View style={[StyleSheet.absoluteFill, { backgroundColor: isDark ? 'rgba(37,38,77,0.55)' : 'rgba(239,239,254,0.5)' }]} />
            <Text style={s.genH}>✨ Free AI Image Generator</Text>
            <Text style={s.genGo}>Open →</Text>
          </TouchableOpacity>

          {/* Recently added (site #recent): header, stats, summary, 12 newest */}
          <View style={s.rhead}>
            <Text style={[s.section, { marginHorizontal: 0 }]}>Recently added</Text>
            <TouchableOpacity onPress={() => navigation.navigate('NewTools')} hitSlop={8}><Text style={s.seeAll}>See all new tools →</Text></TouchableOpacity>
          </View>
          <View style={s.stats}>
            {[['Total tools', st.total], ['Last updated' + (st.last ? ' · ' + st.lastN + ' added' : ''), shortDate(st.last)], ['New this week', st.week], ['New this month', st.month], ['Categories', st.cats]].map(([k, v]) => (
              <View key={k} style={s.stat}><Text style={s.statNum} numberOfLines={1}>{v}</Text><Text style={s.statLab} numberOfLines={2}>{k}</Text></View>
            ))}
          </View>
          <Text style={s.total}>{summaryLine(tools)}</Text>
          <View style={cols > 1 ? s.grid2 : null}>
            {recent.map((t) => (
              <ToolCard key={t.id} tool={t} onPress={() => open(t)} style={[{ marginHorizontal: 16 }, cols > 1 && s.half]} />
            ))}
          </View>

          {/* Daily Editor's Pick (live api/editors-pick.json), above New this week */}
          {pickTool ? (
            <TouchableOpacity style={[s.ep, width >= 600 && s.epWide]} activeOpacity={0.8} accessibilityRole="button"
              onPress={() => { track('editors_pick_click', pickTool.id); open(pickTool); }}>
              <View style={[s.epIcon, width >= 600 && { marginRight: 18, marginBottom: 0 }]}>
                {pickTool.logo ? <Image source={{ uri: pickTool.logo }} style={s.epImg} /> : <Text style={s.letter}>{pickTool.name[0]}</Text>}
              </View>
              <View style={{ flex: width >= 600 ? 1 : 0 }}>
                <View style={s.epLabelRow}>
                  <View style={s.epStar}><Ionicons name="star" size={11} color="#fff" /></View>
                  <Text style={s.epLabel}>Editor's Pick</Text>
                  <Text style={s.epDate}> · {fmtDate(pickData.date)}</Text>
                </View>
                <Text style={s.epName}>{pickTool.name}</Text>
                <Text style={s.epWhy}>{pickData.why}</Text>
                <View style={{ flexDirection: 'row', marginTop: 8 }}>
                  <Text style={s.epChip}>{pickTool.category}</Text><Text style={[s.epChip, s.epPrice]}>{pickTool.priceTag}</Text>
                </View>
              </View>
            </TouchableOpacity>
          ) : null}

          {thisWeek.length > 0 ? (
            <View>
              <Text style={s.section}>New this week · {thisWeek.length}</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 4 }}>
                {thisWeek.slice(0, 20).map((t) => <ToolCard key={t.id} tool={t} variant="wide" onPress={() => open(t)} />)}
              </ScrollView>
            </View>
          ) : null}
        </>
      ) : null}

      {/* Directory (site #directory): category chips + all tools */}
      <Text style={s.section}>Directory</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16 }}>
        {chips.map((c) => (
          <TouchableOpacity key={c} onPress={() => setChip(c)} style={[s.chip, chip === c && s.chipOn, CAT_ICONS[c] && { flexDirection: 'row', alignItems: 'center' }]}>
            {CAT_ICONS[c] ? <Ionicons name={CAT_ICONS[c]} size={14} color={chip === c ? C.onAccent : C.accent} style={{ marginRight: 5 }} /> : null}
            <Text style={[s.chipText, chip === c && s.chipTextOn]}>{c}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <Text style={s.section}>{chip === 'All' ? 'All tools' : chip === 'Saved' ? 'Saved tools' : chip} · {filtered.length}</Text>
      {error ? <Text style={s.error}>{error}</Text> : null}
    </View>
  );
  if (loading) {
    return <View style={s.loading}><ActivityIndicator size="large" color={C.accent} /></View>;
  }

  return (
    <SafeAreaView style={s.screen} edges={['top']}>
      <FlatList
        ref={listRef}
        {...scroll.listProps}
        data={filtered}
        keyExtractor={(t) => t.id}
        key={'cols' + cols}
        numColumns={cols}
        ListHeaderComponent={header}
        columnWrapperStyle={cols > 1 ? { paddingHorizontal: 10 } : undefined}
        renderItem={({ item }) => <ToolCard tool={item} onPress={() => open(item)} style={cols > 1 ? { flex: 1, marginHorizontal: 6 } : { marginHorizontal: 16 }} />}
        refreshControl={<RefreshControl refreshing={refreshing} colors={[C.accent]}
          onRefresh={() => { setRefreshing(true); load(true); getEditorsPick().then(setPickData).catch(() => {}); }} />}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ paddingBottom: scroll.padBottom }}
      />
      {scroll.buttons}
    </SafeAreaView>
  );
}

const QUICK = [['Categories', 'Categories'], ['Tasks', 'Tasks'], ['Compare', 'CompareIndex'], ['Best', 'Best'], ['News', 'News'],
  ['Image generator', 'Generate'], ['Newsletter', 'Newsletter'], ['Quiz', 'Quiz'], ['Submit', 'Submit']];
const isDarkBg = (C) => (C.bg === '#FFFFFF' ? '#EFEFFE' : '#25264D');
const makeStyles = (C) => StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: C.bg },
  top: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: C.line },
  brand: { fontSize: 24, fontWeight: '800', color: C.text },
  hero: { paddingHorizontal: 20, paddingTop: 24, alignItems: 'center', backgroundColor: C.bg },
  lede: { fontSize: 16, color: C.muted, textAlign: 'center', lineHeight: 24, marginTop: 10, maxWidth: 620 },
  quizRow: { marginHorizontal: 16, marginTop: 12, alignItems: 'center' },
  quizText: { fontSize: 15, color: C.muted, textAlign: 'center' },
  quizLink: { color: C.accentText, fontWeight: '600' },
  ctaRow: { flexDirection: 'row', justifyContent: 'center', marginTop: 14, paddingHorizontal: 16 },
  cta: { flexDirection: 'row', alignItems: 'center', height: 44, paddingHorizontal: 20, borderRadius: 8, backgroundColor: C.accent, borderWidth: 1, borderColor: C.accent },
  ctaText: { color: C.onAccent, fontWeight: '600', fontSize: 15, marginLeft: 6 },
  ctaGhost: { flexDirection: 'row', alignItems: 'center', height: 44, paddingHorizontal: 16, borderRadius: 8, backgroundColor: C.card, borderWidth: 1, borderColor: C.line, marginLeft: 10 },
  ctaGhostText: { color: C.text, fontWeight: '500', fontSize: 15, marginLeft: 6 },
  heroStats: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', marginTop: 14, paddingHorizontal: 16 },
  hs: { fontSize: 13.5, color: C.muted, marginHorizontal: 8, marginVertical: 2 },
  hsB: { color: C.text, fontWeight: '700' },
  quick: { flexDirection: 'row', alignItems: 'center', height: 34, paddingHorizontal: 12, borderRadius: 999, backgroundColor: C.accentSoft, marginRight: 8 },
  quickText: { color: C.accentText, fontWeight: '600', fontSize: 13, marginLeft: 6 },
  gen: { marginHorizontal: 16, marginTop: 16, borderWidth: 1, borderColor: C.accent, borderRadius: 12, paddingVertical: 14, paddingHorizontal: 12, overflow: 'hidden', flexDirection: 'row', alignItems: 'center', backgroundColor: isDarkBg(C) },
  genH: { flex: 1, fontSize: 15, fontWeight: '700', color: C.accentText },
  genGo: { fontSize: 13, fontWeight: '600', color: C.accentText },
  ep: { marginHorizontal: 16, marginTop: 18, padding: 16, borderRadius: 16, borderWidth: 1, borderColor: C.accent, backgroundColor: C.accentSoft },
  epWide: { flexDirection: 'row', alignItems: 'center', padding: 20 },
  epIcon: { width: 64, height: 64, borderRadius: 16, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  epImg: { width: 48, height: 48, borderRadius: 10 },
  epLabelRow: { flexDirection: 'row', alignItems: 'center' },
  epStar: { width: 20, height: 20, borderRadius: 10, backgroundColor: C.accent, alignItems: 'center', justifyContent: 'center', marginRight: 6 },
  epLabel: { fontSize: 13, fontWeight: '800', color: C.accentText },
  epDate: { fontSize: 13, color: C.muted },
  epName: { fontSize: 20, fontWeight: '800', color: C.text, marginTop: 4 },
  epWhy: { fontSize: 15, color: C.text, lineHeight: 21, marginTop: 4 },
  epChip: { fontSize: 11.5, fontWeight: '600', color: C.text, borderWidth: 1, borderColor: C.line, backgroundColor: C.card, borderRadius: 999, paddingHorizontal: 8, paddingVertical: 2, marginRight: 6, overflow: 'hidden', textTransform: 'capitalize' },
  epPrice: { color: C.accentText },
  quickWrap: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', width: '100%' },
  quick: { height: 34, justifyContent: 'center', paddingHorizontal: 14, borderRadius: 999, borderWidth: 1, borderColor: C.line, backgroundColor: C.card, marginRight: 8, marginBottom: 8 },
  quickText: { color: C.muted, fontWeight: '500', fontSize: 14 },
  featured: { marginHorizontal: 16, marginTop: 16, padding: 12, borderRadius: 14, backgroundColor: C.accentSoft, borderWidth: 1, borderColor: C.accent },
  featLabel: { fontSize: 11, fontWeight: '800', letterSpacing: 1, color: C.accentText, marginBottom: 8 },
  logo: { width: 56, height: 56, borderRadius: 15, marginRight: 14, backgroundColor: C.card },
  h1: { fontSize: 28, lineHeight: 34, fontWeight: '800', color: C.text, textAlign: 'center', marginTop: 14, maxWidth: 680 },
  sub: { fontSize: 13, color: C.muted },
  searchRow: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 16, marginTop: 8 },
  search: { flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: C.card,
    borderRadius: 10, paddingHorizontal: 12, height: 46, borderWidth: 1, borderColor: C.line },
  input: { flex: 1, marginLeft: 8, fontSize: 15, color: C.text },
  section: { fontSize: 16, fontWeight: '700', color: C.text, marginHorizontal: 16, marginTop: 16, marginBottom: 8 },
  pick: { width: 130, backgroundColor: C.accentSoft, borderRadius: 12, padding: 12, marginRight: 10,
    borderWidth: 1, borderColor: C.accent },
  pickImg: { width: 36, height: 36, borderRadius: 8, marginBottom: 8 },
  pickName: { fontWeight: '700', color: C.text },
  pickCat: { fontSize: 12, color: C.accentText, marginTop: 2 },
  chip: { height: 30, justifyContent: 'center', paddingHorizontal: 12, borderRadius: 999, backgroundColor: C.card,
    marginRight: 8, borderWidth: 1, borderColor: C.line },
  chipOn: { backgroundColor: C.accent, borderColor: C.accent },
  chipText: { color: C.text, fontWeight: '600', textTransform: 'capitalize' },
  chipTextOn: { color: C.onAccent },
  tile: { flex: 1 / 3, alignItems: 'center', padding: 6, marginBottom: 8 },
  tileIcon: { width: 72, height: 72, borderRadius: 12, backgroundColor: C.card, alignItems: 'center',
    justifyContent: 'center', borderWidth: 1, borderColor: C.line },
  tileImg: { width: 48, height: 48, borderRadius: 10 },
  letter: { fontSize: 28, fontWeight: '800', color: C.accentText },
  tileName: { fontSize: 12, color: C.text, textAlign: 'center', marginTop: 6, fontWeight: '600' },
  error: { color: C.danger, marginHorizontal: 16 },
  stats: { flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: 12, marginTop: 10 },
  stat: { width: '31%', margin: '1%', backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 12, paddingVertical: 8, paddingHorizontal: 10 },
  statNum: { fontSize: 18, fontWeight: '800', color: C.text },
  statLab: { fontSize: 11, color: C.muted },
  checked: { color: C.faint, fontSize: 12, marginHorizontal: 16, marginTop: 2 },
  grid2: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 10 },
  half: { width: '47%', marginHorizontal: '1.5%' },
  total: { color: C.muted, fontSize: 13, marginHorizontal: 16, marginTop: 10, marginBottom: 10, fontWeight: '600' },
  rhead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginHorizontal: 16 },
  seeAll: { color: C.accentText, fontWeight: '700', marginTop: 8 },
  rcard: { flexDirection: 'row', backgroundColor: C.card, borderRadius: 14, padding: 12, marginHorizontal: 16,
    marginBottom: 8, borderWidth: 1, borderColor: C.line },
  ricon: { width: 44, height: 44, borderRadius: 12, backgroundColor: C.accentSoft, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  rimg: { width: 28, height: 28, borderRadius: 6 },
  rname: { fontSize: 15, fontWeight: '700', color: C.text },
  rdesc: { fontSize: 12, color: C.muted, marginTop: 2 },
  rmeta: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
  rdate: { fontSize: 12, color: C.muted },
});
