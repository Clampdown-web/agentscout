import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Privacy choices, same rules as the website (consent.js):
// - Necessary (always on): favorites, theme, cached tool list, image cooldown.
// - Analytics: the anonymous counts in analytics.js.
// - Embeds: the Beehiiv newsletter sign-up WebView (Beehiiv may set its own cookies).
// The Worker's /geo says whether the visitor is in a strict region (EU/EEA, UK, CH, BR, US privacy-law states);
// any failure counts as strict. Strict: first-launch modal, nothing optional runs until a choice is made.
// Elsewhere: small dismissible notice, analytics + embeds on by default, opt-out one tap away.
const KEY = 'agentscout_consent_v1';
const GEO = 'https://agentscout-image.agentscouthq.workers.dev/geo';
const S = { ready: false, decided: false, strict: true, analytics: false, embeds: false, pickerOpen: false };
const subs = new Set();
let initP = null;
const snap = () => ({ ...S });
const emit = () => { const s = snap(); subs.forEach((f) => { try { f(s); } catch (e) {} }); };

export const getConsent = snap;
export function subscribe(f) { subs.add(f); return () => subs.delete(f); }
// null = no decision yet in a strict region (hold, send nothing); true/false otherwise
export function analyticsAllowed() { if (!S.ready || (S.strict && !S.decided)) return null; return S.analytics; }

export function initConsent() {
  if (initP) return initP;
  initP = (async () => {
    try {
      const j = JSON.parse((await AsyncStorage.getItem(KEY)) || 'null');
      if (j && j.v === 1) { Object.assign(S, { ready: true, decided: true, strict: !!j.strict, analytics: !!j.analytics, embeds: !!j.embeds }); emit(); return; }
    } catch (e) {}
    let strict = true;
    try {
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 3000);
      const r = await fetch(GEO, { headers: { 'X-AgentScout-App': '1' }, signal: ctl.signal });
      clearTimeout(t);
      if (r.ok) { const j = await r.json(); strict = !(j && j.strict === false); }
    } catch (e) {}
    Object.assign(S, { ready: true, strict, analytics: !strict, embeds: !strict });
    emit();
  })();
  return initP;
}
export async function setConsent(analytics, embeds) {
  Object.assign(S, { analytics: !!analytics, embeds: !!embeds, decided: true, pickerOpen: false });
  emit();
  try { await AsyncStorage.setItem(KEY, JSON.stringify({ v: 1, analytics: S.analytics, embeds: S.embeds, strict: S.strict, ts: new Date().toISOString() })); } catch (e) {}
}
export function openPrivacyChoices() { S.pickerOpen = true; emit(); }
export function closePrivacyChoices() { S.pickerOpen = false; emit(); }
export function useConsent() {
  const [s, set] = useState(snap());
  useEffect(() => { set(snap()); return subscribe(set); }, []);
  return s;
}
