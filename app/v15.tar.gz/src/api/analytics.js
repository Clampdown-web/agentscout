import AsyncStorage from '@react-native-async-storage/async-storage';
import { analyticsAllowed, subscribe } from './consent';

// Anonymous usage counts. No personal data, no IP storage: the Worker keeps only daily aggregate counters.
// Only with analytics consent (see consent.js): in strict regions nothing is sent (or stored) until the user
// accepts; elsewhere it's on by default and can be turned off under Privacy choices.
// Batched and fire-and-forget; silently drops events when offline.
const URL_ = 'https://agentscout-image.agentscouthq.workers.dev/track';
const ID_KEY = 'agentscout_install_id';
let Q = [], timer = null, pendingOpen = false;

function flush() {
  timer = null;
  if (!Q.length) return;
  const a = analyticsAllowed();
  if (a === null) return;            // waiting for a choice: hold in memory, send nothing
  if (!a) { Q = []; return; }        // declined: drop
  const events = Q.splice(0, 50);
  fetch(URL_, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-AgentScout-App': '1' },
    body: JSON.stringify({ source: 'app', events }) }).catch(() => {});
}
export function track(e, k, q) {
  if (analyticsAllowed() === false) return;
  const ev = { e };
  if (k) ev.k = String(k).slice(0, 80);
  if (q) ev.q = String(q).toLowerCase().trim().slice(0, 60);
  if (Q.length < 200) Q.push(ev);
  if (!timer) timer = setTimeout(flush, 3000);
}
subscribe(() => {
  const a = analyticsAllowed();
  if (a === true) { if (pendingOpen) { pendingOpen = false; trackOpen(); } flush(); }
  else if (a === false) { Q = []; pendingOpen = false; AsyncStorage.removeItem(ID_KEY).catch(() => {}); }
});
// app_first_open (install proxy): a random id saved once, only after analytics consent; only its absence is used,
// it is never sent.
export async function trackOpen() {
  const a = analyticsAllowed();
  if (a === false) return;
  if (a === null) { pendingOpen = true; return; }
  try {
    const id = await AsyncStorage.getItem(ID_KEY);
    if (!id) {
      const rnd = Date.now().toString(36) + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
      await AsyncStorage.setItem(ID_KEY, rnd);
      track('app_first_open');
    }
  } catch (e) {}
  track('app_open');
}
let st = null;
export function trackSearch(q, now) {
  clearTimeout(st);
  const v = String(q || '').trim();
  if (v.length < 2) return;
  if (now) track('search', null, v); else st = setTimeout(() => track('search', null, v), 1500);
}
