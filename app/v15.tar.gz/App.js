import React, { useEffect } from 'react';
import { AppState } from 'react-native';
import { refreshAll } from './src/api/live';
import { trackOpen } from './src/api/analytics';
import { initConsent } from './src/api/consent';
import ConsentPrompt from './src/components/ConsentPrompt';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import Tabs from './src/navigation/Tabs';
import ToolDetailScreen from './src/screens/ToolDetailScreen';
import NewToolsScreen from './src/screens/NewToolsScreen';
import ToolListScreen from './src/screens/explore/ToolListScreen';
import { CategoriesScreen, TasksScreen, BestScreen, CompareIndexScreen } from './src/screens/explore/ListScreens';
import CompareDetailScreen from './src/screens/explore/CompareDetailScreen';
import NewsScreen from './src/screens/explore/NewsScreen';
import GenerateScreen from './src/screens/explore/GenerateScreen';
import NewsletterScreen from './src/screens/explore/NewsletterScreen';
import SubmitScreen from './src/screens/explore/SubmitScreen';
import BadgesScreen from './src/screens/explore/BadgesScreen';
import FreeToolsScreen from './src/screens/explore/FreeToolsScreen';
import { ThemeProvider, useTheme } from './src/theme';

const Stack = createNativeStackNavigator();

function Root() {
  const { C, isDark } = useTheme();
  const base = isDark ? DarkTheme : DefaultTheme;
  const navTheme = { ...base, colors: { ...base.colors, primary: C.accent, background: C.bg, card: C.card,
    text: C.text, border: C.line, notification: C.accent } };
  const hdr = { headerTintColor: C.accentText, headerStyle: { backgroundColor: C.card }, headerTitleStyle: { color: C.text }, headerBackTitle: 'Back' };
  return (
    <>
    <NavigationContainer theme={navTheme}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <Stack.Navigator>
        <Stack.Screen name="Main" component={Tabs} options={{ headerShown: false }} />
        <Stack.Screen name="ToolDetail" component={ToolDetailScreen}
          options={({ route }) => ({ title: route.params?.tool?.name || 'Tool', headerTintColor: C.accentText,
            headerStyle: { backgroundColor: C.card }, headerTitleStyle: { color: C.text } })} />
        <Stack.Screen name="NewTools" component={NewToolsScreen}
          options={{ title: 'New tools', headerTintColor: C.accentText, headerStyle: { backgroundColor: C.card }, headerTitleStyle: { color: C.text } }} />
        {[['Categories', CategoriesScreen, 'Categories'], ['Tasks', TasksScreen, 'Tasks'],
          ['CompareIndex', CompareIndexScreen, 'Compare'], ['Best', BestScreen, 'Best'], ['News', NewsScreen, 'Agent news'],
          ['Generate', GenerateScreen, 'Image Generator'], ['Newsletter', NewsletterScreen, 'Newsletter'], ['Submit', SubmitScreen, 'Submit a tool'], ['Badges', BadgesScreen, 'Maker badges'], ['FreeTools', FreeToolsScreen, 'Free tools']]
          .map(([name, comp, title]) => <Stack.Screen key={name} name={name} component={comp} options={{ ...hdr, title }} />)}
        <Stack.Screen name="ToolList" component={ToolListScreen} options={({ route }) => ({ ...hdr, title: route.params?.title || 'Tools' })} />
        <Stack.Screen name="CompareDetail" component={CompareDetailScreen} options={({ route }) => ({ ...hdr, title: route.params?.cmp?.title || 'Compare' })} />
      </Stack.Navigator>
    </NavigationContainer>
    <ConsentPrompt />
    </>
  );
}

export default function App() {
  useEffect(() => {
    initConsent(); refreshAll(); trackOpen();
    let last = AppState.currentState;
    const sub = AppState.addEventListener('change', (st) => { if (last.match(/inactive|background/) && st === 'active') { refreshAll(); trackOpen(); } last = st; });
    return () => sub.remove();
  }, []);
  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <Root />
      </ThemeProvider>
    </SafeAreaProvider>
  );
}
