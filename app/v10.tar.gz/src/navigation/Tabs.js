import React from 'react';
import { View, Text, Image, StyleSheet, ScrollView, Linking, TouchableOpacity } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import HomeScreen from '../screens/HomeScreen';
import BrowseScreen from '../screens/BrowseScreen';
import SavedScreen from '../screens/OverviewScreen';
import ExploreScreen from '../screens/explore/ExploreScreen';
import { useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import NewsletterSection from '../components/NewsletterSection';
import ThemeToggle from '../components/ThemeToggle';
import { LOGO_URL } from '../api/tools';
import { useTheme, useStyles } from '../theme';

const Tab = createBottomTabNavigator();

const SITE = 'https://clampdown-web.github.io/agentscout/';
const LINKS = [
  ['sparkles-outline', 'New tools', SITE + 'new.html'],
  ['help-circle-outline', 'Agent Finder Quiz', SITE + 'quiz.html'],
  ['globe-outline', 'Website', SITE],
  ['add-circle-outline', 'Submit a tool', SITE + 'submit.html'],
];

function AboutScreen() {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.bg }} edges={['top']}>
    <View style={s.titleRow}><Text style={s.screenTitle}>About</Text><ThemeToggle /></View>
    <ScrollView contentContainerStyle={s.center}>
      <Image source={{ uri: LOGO_URL }} style={s.logo} resizeMode="contain" />
      <Text style={s.title}>AgentScout</Text>
      <Text style={s.body}>Find the right AI agent for the job. A curated directory of AI agents and tools, updated daily.</Text>
      <View style={s.menu}>
        {LINKS.map(([icon, label, url], i) => (
          <TouchableOpacity key={label} style={[s.row, i && s.rowLine]} onPress={() => Linking.openURL(url)} accessibilityRole="link">
            <Ionicons name={icon} size={20} color={C.accentText} />
            <Text style={s.rowText}>{label}</Text>
            <Ionicons name="open-outline" size={18} color={C.faint} />
          </TouchableOpacity>
        ))}
        <NewsletterSection style={s.rowLine} />
      </View>
      <Text style={[s.body, { fontSize: 12.5, marginTop: 16 }]}>The app counts anonymous usage (no personal data) to improve AgentScout.</Text>
    </ScrollView>
    </SafeAreaView>
  );
}

export default function Tabs() {
  const { width } = useWindowDimensions();
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarLabelPosition: width >= 600 ? 'beside-icon' : 'below-icon',
        tabBarLabelStyle: { fontSize: width >= 600 ? 13 : 11, fontWeight: '600' },
        tabBarActiveTintColor: C.accent,
        tabBarInactiveTintColor: C.faint,
        tabBarStyle: { backgroundColor: C.card, borderTopColor: C.line },
        headerStyle: { backgroundColor: C.card },
        headerTintColor: C.text,
        sceneStyle: { backgroundColor: C.bg },
        headerTitleStyle: { fontWeight: '700' },
        tabBarIcon: ({ color, size, focused }) => {
          const icons = { Home: 'home', 'All Tools': 'apps', Explore: 'compass', Saved: 'heart', About: 'information-circle' };
          const name = icons[route.name] + (focused ? '' : '-outline');
          return <Ionicons name={name} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
      <Tab.Screen name="All Tools" component={BrowseScreen} options={{ headerShown: false }} />
      <Tab.Screen name="Explore" component={ExploreScreen} options={{ headerShown: false }} />
      <Tab.Screen name="Saved" component={SavedScreen} options={{ headerShown: false }} />
      <Tab.Screen name="About" component={AboutScreen} options={{ headerShown: false }} />
    </Tab.Navigator>
  );
}

const makeStyles = (C) => StyleSheet.create({
  titleRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 16, paddingBottom: 4, backgroundColor: C.bg },
  screenTitle: { flex: 1, fontSize: 22, fontWeight: '800', color: C.text },
  center: { flexGrow: 1, alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: C.bg },
  logo: { width: 140, height: 140, borderRadius: 24, marginBottom: 12 },
  title: { fontSize: 22, fontWeight: '700', color: C.text, marginTop: 12 },
  body: { fontSize: 15, color: C.muted, textAlign: 'center', marginTop: 8, lineHeight: 22 },
  menu: { alignSelf: 'stretch', maxWidth: 520, width: '100%', marginTop: 20, backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 14, alignSelf: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 16 },
  rowLine: { borderTopWidth: 1, borderTopColor: C.line },
  rowText: { flex: 1, marginLeft: 12, fontSize: 15, fontWeight: '600', color: C.text },
  link: { color: C.accentText, fontWeight: '700', marginTop: 16, fontSize: 16 },
});
