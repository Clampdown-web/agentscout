import React, { useEffect, useState } from 'react';
import { View, Text, Modal, Pressable, Switch, ScrollView, StyleSheet, Linking } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme, useStyles } from '../theme';
import { useConsent, setConsent, openPrivacyChoices, closePrivacyChoices } from '../api/consent';

const PRIVACY = 'https://clampdown-web.github.io/agentscout/privacy.html';

function Btn({ label, onPress, primary, s }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" android_ripple={{ color: '#5B5BF733' }}
      style={({ pressed }) => [s.btn, primary && s.btnPrimary, pressed && { opacity: 0.8 }]}>
      <Text style={[s.btnText, primary && s.btnTextPrimary]}>{label}</Text>
    </Pressable>
  );
}

// Strict regions: first-launch modal (Accept all / Reject all / Customize). Elsewhere: a small, non-blocking notice.
// "Privacy choices" on the About screen reopens the picker at any time.
export default function ConsentPrompt() {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  const c = useConsent();
  const [custom, setCustom] = useState(false);
  const [an, setAn] = useState(false);
  const [em, setEm] = useState(false);
  const picker = c.pickerOpen || custom;
  useEffect(() => { if (picker) { setAn(c.analytics); setEm(c.embeds); } }, [picker]);
  if (!c.ready) return null;

  const firstStrict = c.strict && !c.decided;
  const close = () => { setCustom(false); closePrivacyChoices(); };
  const done = (a, e) => { setCustom(false); setConsent(a, e); };

  if (picker || firstStrict) {
    return (
      <Modal transparent animationType="fade" visible onRequestClose={() => { if (picker) close(); }} statusBarTranslucent>
        <View style={s.overlay}>
          <View style={s.card} accessibilityViewIsModal>
            <ScrollView contentContainerStyle={{ padding: 20 }}>
              {picker ? (
                <>
                  <Text style={s.h} accessibilityRole="header">Privacy choices</Text>
                  <Text style={s.p}>Choose what AgentScout may use. You can change this anytime under Privacy choices on the About screen.</Text>
                  <Row s={s} C={C} title="Necessary" desc="Always on. Saved tools, theme, the cached tool list and the image generator cooldown, kept only on this device." value disabled />
                  <Row s={s} C={C} title="Analytics" desc="Anonymous counts of app opens, searches and taps. No personal data; stored only as daily totals." value={an} onChange={setAn} />
                  <Row s={s} C={C} title="Embedded content" desc="The newsletter sign-up, run by Beehiiv. Beehiiv may set its own cookies when you use it." value={em} onChange={setEm} />
                  <View style={s.btns}>
                    <Btn s={s} primary label="Save choices" onPress={() => done(an, em)} />
                    <Btn s={s} label="Accept all" onPress={() => done(true, true)} />
                    <Btn s={s} label="Reject all" onPress={() => done(false, false)} />
                  </View>
                  {c.decided ? <Pressable onPress={close} accessibilityRole="button" style={s.cancel}><Text style={s.link}>Cancel</Text></Pressable> : null}
                </>
              ) : (
                <>
                  <Text style={s.h} accessibilityRole="header">Your privacy choices</Text>
                  <Text style={s.p}>We'd like to count anonymous usage (nothing that identifies you) and load the newsletter sign-up from Beehiiv, which may set its own cookies. Nothing optional runs until you choose.</Text>
                  <View style={s.btns}>
                    <Btn s={s} label="Accept all" onPress={() => done(true, true)} />
                    <Btn s={s} label="Reject all" onPress={() => done(false, false)} />
                    <Btn s={s} label="Customize" onPress={() => setCustom(true)} />
                  </View>
                </>
              )}
              <Pressable onPress={() => Linking.openURL(PRIVACY)} accessibilityRole="link" style={s.cancel}><Text style={s.link}>Privacy policy</Text></Pressable>
            </ScrollView>
          </View>
        </View>
      </Modal>
    );
  }
  if (!c.decided) {
    return (
      <View style={s.note} accessibilityLabel="Privacy notice">
        <Text style={s.noteText}>We count anonymous usage to improve AgentScout.</Text>
        <View style={{ flexDirection: 'row', marginTop: 6 }}>
          <Pressable onPress={() => setConsent(false, c.embeds)} accessibilityRole="button" hitSlop={8}><Text style={s.link}>Opt out</Text></Pressable>
          <Text style={s.noteText}>  ·  </Text>
          <Pressable onPress={openPrivacyChoices} accessibilityRole="button" hitSlop={8}><Text style={s.link}>Privacy choices</Text></Pressable>
        </View>
        <Pressable onPress={() => setConsent(c.analytics, c.embeds)} accessibilityRole="button" accessibilityLabel="Dismiss privacy notice" hitSlop={10} style={s.x}>
          <Ionicons name="close" size={20} color={C.muted} />
        </Pressable>
      </View>
    );
  }
  return null;
}

function Row({ s, C, title, desc, value, onChange, disabled }) {
  return (
    <View style={s.row}>
      <View style={{ flex: 1, paddingRight: 12 }}>
        <Text style={s.rowTitle}>{title}</Text>
        <Text style={s.rowDesc}>{desc}</Text>
      </View>
      <Switch value={!!value} onValueChange={onChange} disabled={disabled} accessibilityLabel={disabled ? `${title}, always on` : title}
        trackColor={{ false: C.line, true: C.accent }} thumbColor="#FFFFFF" ios_backgroundColor={C.line} />
    </View>
  );
}

const makeStyles = (C) => StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 16 },
  card: { width: '100%', maxWidth: 520, maxHeight: '90%', backgroundColor: C.card, borderRadius: 16, borderWidth: 1, borderColor: C.line },
  h: { fontSize: 19, fontWeight: '800', color: C.text, marginBottom: 6 },
  p: { fontSize: 14.5, color: C.muted, lineHeight: 21, marginBottom: 12 },
  row: { flexDirection: 'row', alignItems: 'center', borderTopWidth: 1, borderTopColor: C.line, paddingVertical: 12 },
  rowTitle: { fontSize: 15, fontWeight: '700', color: C.text },
  rowDesc: { fontSize: 13, color: C.muted, lineHeight: 18, marginTop: 2 },
  btns: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 14 },
  btn: { flexGrow: 1, minHeight: 44, paddingHorizontal: 14, borderRadius: 10, borderWidth: 1, borderColor: C.line, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' },
  btnPrimary: { backgroundColor: C.text, borderColor: C.text },
  btnText: { fontSize: 15, fontWeight: '600', color: C.text },
  btnTextPrimary: { color: C.bg },
  cancel: { alignSelf: 'center', marginTop: 14, padding: 4 },
  link: { color: C.accentText, fontWeight: '600', fontSize: 14 },
  note: { position: 'absolute', left: 12, right: 12, bottom: 96, backgroundColor: C.card, borderRadius: 12, borderWidth: 1, borderColor: C.line,
    paddingVertical: 10, paddingLeft: 14, paddingRight: 40, shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 10, elevation: 6 },
  noteText: { color: C.muted, fontSize: 13.5 },
  x: { position: 'absolute', top: 8, right: 8 },
});
