import React from 'react';
import { TouchableOpacity, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../theme';

// Inline light/dark toggle. Lives only at the end of a search bar row or a screen title row (never in a
// header corner), so the top-right stays clear. Round, 40px on phones, 48px on tablets (>=600px), same border and card background as the search bar.
// Search bar height and toggle size: 40px phone / 48px tablet; gap 8 / 12.
export function useBarSize() {
  const { width } = useWindowDimensions();
  const tablet = width >= 600;
  return { size: tablet ? 48 : 40, gap: tablet ? 12 : 8 };
}

export default function ThemeToggle({ style }) {
  const { C, isDark, toggle } = useTheme();
  const { size, gap } = useBarSize();
  return (
    <TouchableOpacity onPress={toggle} hitSlop={8} accessibilityRole="button"
      accessibilityLabel={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
      style={[{ width: size, height: size, marginLeft: gap, borderRadius: size / 2, alignSelf: 'center', borderWidth: 1, borderColor: C.line,
        backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' }, style]}>
      <Ionicons name={isDark ? 'sunny-outline' : 'moon-outline'} size={size >= 48 ? 21 : 19} color={C.text} />
    </TouchableOpacity>
  );
}
