import React from 'react';
import { View, Text, useWindowDimensions } from 'react-native';
import { useTheme } from '../theme';
import { getMeta, fmtDate } from '../api/tools';

// Copy of the website hero badge (.eyebrow): accent text on accent-soft, full pill, 4/10 padding, no border,
// "549 tools · Links checked Oct 16, 2026". Count and date come from the live api/tools.json.
export default function CheckedPill({ count, style, align = 'center' }) {
  const { C } = useTheme();
  const { width } = useWindowDimensions();
  const fs = width >= 600 ? 14 : 12;
  const lc = getMeta().lastChecked;
  if (!count && !lc) return null;
  const text = [count ? count + ' tools' : null, lc ? 'Links checked ' + fmtDate(lc) : null].filter(Boolean).join(' · ');
  return (
    <View style={[{ alignItems: align === 'center' ? 'center' : 'flex-start', paddingHorizontal: 16, marginTop: 10 }, style]}>
      <Text accessibilityRole="text" style={{ fontSize: fs, lineHeight: fs + 5, fontWeight: '500', color: C.accentText,
        backgroundColor: C.accentSoft, borderRadius: 999, paddingVertical: 4, paddingHorizontal: 10, overflow: 'hidden',
        textAlign: 'center', maxWidth: '100%' }}>{text}</Text>
    </View>
  );
}
