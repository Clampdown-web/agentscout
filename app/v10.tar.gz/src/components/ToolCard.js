import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { useStyles, useTheme } from '../theme';
import { Ionicons } from '@expo/vector-icons';
import { isNew, fmtDate, toggleFavorite } from '../api/tools';
import useFavorites from '../api/useFavorites';
import { track } from '../api/analytics';

// One card for every tool list, like the website's cards:
// logo left; name + New badge + 2-3 line description; "Added <date>"; category and pricing chips.
// variant="wide" is the ~280px card used in horizontal rows.
export default function ToolCard({ tool, onPress, variant, style }) {
  const s = useStyles(makeStyles);
  const { C } = useTheme();
  const fav = useFavorites().includes(tool.id);
  const wide = variant === 'wide';
  return (
    <TouchableOpacity style={[s.card, wide && s.wide, style]} onPress={() => { track('tool_click', tool.id); onPress && onPress(); }} activeOpacity={0.75}
      accessibilityRole="button" accessibilityLabel={tool.name + (isNew(tool) ? ', new' : '')}>
      <View style={s.top}>
        <View style={s.icon}>
          {tool.logo ? <Image source={{ uri: tool.logo }} style={s.img} resizeMode="contain" />
            : <Text style={s.letter}>{(tool.name || '?')[0]}</Text>}
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <View style={s.nameRow}>
            <Text style={s.name} numberOfLines={1}>{tool.name}</Text>
            {isNew(tool) ? <Text style={s.newBadge}>New</Text> : null}
            <View style={{ flex: 1 }} />
            <TouchableOpacity onPress={() => toggleFavorite(tool.id)} hitSlop={10} style={s.heart}
              accessibilityRole="button" accessibilityLabel={fav ? 'Remove ' + tool.name + ' from saved' : 'Save ' + tool.name}>
              <Ionicons name={fav ? 'heart' : 'heart-outline'} size={20} color={fav ? (C.heart || C.accent) : C.faint} />
            </TouchableOpacity>
          </View>
          <Text style={s.desc} numberOfLines={wide ? 2 : 3}>{tool.description}</Text>
        </View>
      </View>
      <View style={s.foot}>
        {tool.added ? <Text style={s.date}>Added {fmtDate(tool.added)}</Text> : null}
        <View style={s.chips}>
          <Text style={s.chip} numberOfLines={1}>{tool.category}</Text>
          <Text style={[s.chip, s.price]} numberOfLines={1}>{tool.priceTag}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const makeStyles = (C) => StyleSheet.create({
  card: { backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 14, padding: 14, marginBottom: 10 },
  wide: { width: 280, marginRight: 10, marginBottom: 0 },
  top: { flexDirection: 'row', alignItems: 'flex-start' },
  icon: { width: 44, height: 44, borderRadius: 12, backgroundColor: C.accentSoft, alignItems: 'center', justifyContent: 'center',
    marginRight: 12, overflow: 'hidden' },
  img: { width: 32, height: 32, borderRadius: 6 },
  letter: { fontSize: 20, fontWeight: '800', color: C.accentText },
  heart: { marginLeft: 8 },
  nameRow: { flexDirection: 'row', alignItems: 'center' },
  name: { flexShrink: 1, fontSize: 15.5, fontWeight: '700', color: C.text },
  newBadge: { marginLeft: 8, fontSize: 11, fontWeight: '700', color: C.text, borderWidth: 1, borderColor: C.text, borderRadius: 999,
    paddingHorizontal: 7, paddingVertical: 1, overflow: 'hidden' },
  desc: { fontSize: 13, lineHeight: 18, color: C.muted, marginTop: 4 },
  foot: { marginTop: 10, flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap' },
  date: { fontSize: 12, color: C.muted, marginRight: 8, marginVertical: 2 },
  chips: { flexDirection: 'row', flexShrink: 1 },
  chip: { fontSize: 11, fontWeight: '600', color: C.text, borderWidth: 1, borderColor: C.line, backgroundColor: C.bg, borderRadius: 999,
    paddingHorizontal: 8, paddingVertical: 2, marginRight: 6, overflow: 'hidden', textTransform: 'capitalize', maxWidth: 150 },
  price: { color: C.accentText, backgroundColor: C.accentSoft, borderColor: C.accentSoft },
});
