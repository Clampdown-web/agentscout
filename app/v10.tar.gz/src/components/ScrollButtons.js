import React, { useState, useCallback, useContext, useEffect, useRef } from 'react';
import { View, TouchableOpacity, StyleSheet, useWindowDimensions, Animated } from 'react-native';
import { BottomTabBarHeightContext } from '@react-navigation/bottom-tabs';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../theme';

// Floating up/down buttons, matching the website: bottom-right, up above down, 16px apart,
// 52px/40px inset on tablet, 48px/24px on phone, plus safe area. Screens sit above the tab bar already.
// FlatList/ScrollView: scrollToOffset(0) / scrollToEnd. SectionList (pass { sections }): top = offset 0 via the
// scroll responder; end = scrollToLocation on the last item of the last non-empty section (viewPosition 1), then a
// follow-up scrollToEnd so the footer is fully shown. onScrollToIndexFailed jumps near the target and retries.
export function buttonMetrics(width) {
  const tablet = width >= 600;
  const size = tablet ? 52 : 44, gap = tablet ? 16 : 12, edge = tablet ? 32 : 16;
  return { size, gap, edge, stack: size * 2 + gap };
}

export function useScrollButtons(ref, opts = {}) {
  const { width } = useWindowDimensions();
  const padBottom = buttonMetrics(width).stack + 24; // so the last card is never under the buttons
  const [y, setY] = useState(0);
  const [content, setContent] = useState(0);
  const [view, setView] = useState(0);
  const onScroll = useCallback((e) => setY(e.nativeEvent.contentOffset.y), []);
  const onContentSizeChange = useCallback((w, h) => setContent(h), []);
  const onLayout = useCallback((e) => setView(e.nativeEvent.layout.height), []);
  const scrollable = content > view + 200;
  const showUp = scrollable && y > 300;
  const showDown = scrollable && y < content - view - 300;
  const responder = () => ref.current && (ref.current.getScrollResponder ? ref.current.getScrollResponder() : ref.current);
  const sections = opts.sections;
  const lastLoc = () => {
    if (!sections) return null;
    for (let i = sections.length - 1; i >= 0; i--) {
      const n = (sections[i].data || []).length;
      if (n) return { sectionIndex: i, itemIndex: n - 1 };
    }
    return null;
  };
  const respEnd = () => { const r = responder(); r && r.scrollToEnd && r.scrollToEnd({ animated: true }); };
  const toTop = () => {
    const l = ref.current; if (!l) return;
    if (l.scrollToOffset) l.scrollToOffset({ offset: 0, animated: true });
    else { const r = responder(); r && r.scrollTo && r.scrollTo({ x: 0, y: 0, animated: true }); }
  };
  const toEnd = () => {
    const l = ref.current; if (!l) return;
    const loc = lastLoc();
    if (loc && l.scrollToLocation) {
      l.scrollToLocation({ ...loc, viewPosition: 1, animated: true });
      setTimeout(respEnd, 450);
    } else if (l.scrollToEnd) l.scrollToEnd({ animated: true });
    else respEnd();
  };
  const onScrollToIndexFailed = useCallback((info) => {
    const r = responder();
    r && r.scrollTo && r.scrollTo({ y: info.averageItemLength * info.index, animated: false });
    setTimeout(() => { const loc = lastLoc(); const l = ref.current; if (loc && l && l.scrollToLocation) l.scrollToLocation({ ...loc, viewPosition: 1, animated: true }); setTimeout(respEnd, 400); }, 120);
  }, [sections]);
  return { padBottom, listProps: { onScroll, onContentSizeChange, onLayout, scrollEventThrottle: 32, ...(sections ? { onScrollToIndexFailed } : {}) },
    buttons: <ScrollButtons showUp={showUp} showDown={showDown} onUp={toTop} onDown={toEnd} /> };
}

function FadeButton({ visible, style, onPress, label, icon, color }) {
  const op = useRef(new Animated.Value(visible ? 1 : 0)).current;
  const [mounted, setMounted] = useState(visible);
  useEffect(() => {
    if (visible) setMounted(true);
    Animated.timing(op, { toValue: visible ? 1 : 0, duration: 150, useNativeDriver: true })
      .start(({ finished }) => { if (finished && !visible) setMounted(false); });
  }, [visible]);
  if (!mounted) return null;
  return (
    <Animated.View style={[style, { opacity: op }]} pointerEvents={visible ? 'auto' : 'none'}>
      <TouchableOpacity style={StyleSheet.absoluteFill} onPress={onPress} hitSlop={8}
        accessibilityRole="button" accessibilityLabel={label}>
        <View style={s.center}><Ionicons name={icon} size={22} color={color} /></View>
      </TouchableOpacity>
    </Animated.View>
  );
}

// Phone (<600): 44px, 12px gap, 16px right/bottom. Tablet: 52px, 16px gap, 32px. Measured from the top of the
// tab bar inside tabs (the scene already ends there, also in landscape); on stack screens add the bottom safe inset.
export default function ScrollButtons({ showUp, showDown, onUp, onDown }) {
  const { C, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const tabBar = useContext(BottomTabBarHeightContext);
  const { size, gap, edge } = buttonMetrics(width);
  const bottom = edge + (tabBar ? 0 : insets.bottom);
  const bg = (C.card.length === 7 ? C.card + 'EB' : C.card); // ~92% opaque card colour
  const btn = { position: 'absolute', right: 0, width: size, height: size, borderRadius: size / 2, backgroundColor: bg,
    borderWidth: 1, borderColor: C.line, shadowColor: '#000', shadowOpacity: isDark ? 0.45 : 0.14, shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 }, elevation: 3 };
  return (
    <View pointerEvents="box-none" style={[s.wrap, { right: edge + insets.right, bottom, width: size, height: size * 2 + gap }]}>
      <FadeButton visible={showUp} style={[btn, { bottom: showDown ? size + gap : 0 }]} onPress={onUp}
        label="Scroll to top" icon="arrow-up" color={C.text} />
      <FadeButton visible={showDown} style={[btn, { bottom: 0 }]} onPress={onDown}
        label="Scroll to bottom" icon="arrow-down" color={C.text} />
    </View>
  );
}
const s = StyleSheet.create({ wrap: { position: 'absolute', zIndex: 10 }, center: { flex: 1, alignItems: 'center', justifyContent: 'center' } });
