import React, { useState } from 'react';
import { View, Text, TouchableOpacity, LayoutAnimation, Platform, UIManager, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { WebView } from 'react-native-webview';
import { useTheme, useStyles } from '../theme';
import { track } from '../api/analytics';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) UIManager.setLayoutAnimationEnabledExperimental(true);

// Same content as the website's inline newsletter panel. Expands in place (LayoutAnimation); signup runs in an
// embedded WebView of the Beehiiv subscribe page, so the app never opens a browser.
const LATEST = { title: 'AgentScout Weekly #1: 5 agent tools worth trying', date: 'Oct 16, 2026', sub: 'Labeled for builders and everyday users' };
const SUBSCRIBE = 'https://agentscout.beehiiv.com/subscribe';
const HOST = 'agentscout.beehiiv.com';

export default function NewsletterSection({ style, initiallyOpen }) {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  const [open, setOpen] = useState(!!initiallyOpen);
  const toggle = () => { LayoutAnimation.configureNext(LayoutAnimation.create(180, 'easeInEaseOut', 'opacity')); if (!open) track('button_click', 'newsletter'); setOpen(!open); };
  return (
    <View style={style}>
      <TouchableOpacity style={s.row} onPress={toggle} accessibilityRole="button" accessibilityState={{ expanded: open }}
        accessibilityLabel={open ? 'Hide newsletter signup' : 'Show newsletter signup'}>
        <Ionicons name="mail-outline" size={20} color={C.accentText} />
        <Text style={s.rowText}>Newsletter</Text>
        <Ionicons name={open ? 'chevron-up' : 'chevron-down'} size={18} color={C.faint} />
      </TouchableOpacity>
      {open ? (
        <View style={s.body}>
          <Text style={s.h}>Get the best new AI agents, weekly</Text>
          <Text style={s.p}>One short email with new tools, launches and what's worth trying. Free, unsubscribe anytime.</Text>
          <View style={s.latest}>
            <Text style={s.badge}>Latest issue</Text>
            <Text style={s.latestTitle}>{LATEST.title}</Text>
            <Text style={s.p}>{LATEST.date} · {LATEST.sub}</Text>
          </View>
          <View style={s.web}>
            <WebView source={{ uri: SUBSCRIBE }} style={{ flex: 1, backgroundColor: 'transparent' }} nestedScrollEnabled
              originWhitelist={['https://*']} setSupportMultipleWindows={false}
              onShouldStartLoadWithRequest={(r) => r.url.includes(HOST) || r.url.includes('challenges.cloudflare.com') || r.url.startsWith('about:')}
              startInLoadingState />
          </View>
          <Text style={s.note}>Enter your email and tap Subscribe above. You stay in the app.</Text>
        </View>
      ) : null}
    </View>
  );
}

const makeStyles = (C) => StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 16 },
  rowText: { flex: 1, marginLeft: 12, fontSize: 15, fontWeight: '600', color: C.text },
  body: { paddingHorizontal: 16, paddingBottom: 16 },
  h: { fontSize: 17, fontWeight: '800', color: C.text, marginBottom: 6 },
  p: { fontSize: 14, color: C.muted, lineHeight: 20 },
  latest: { marginTop: 10, marginBottom: 12 },
  badge: { alignSelf: 'flex-start', fontSize: 12, color: C.text, borderWidth: 1, borderColor: C.line, borderRadius: 999,
    paddingHorizontal: 8, paddingVertical: 2, marginBottom: 4, overflow: 'hidden' },
  latestTitle: { fontSize: 14.5, fontWeight: '700', color: C.text },
  web: { height: 420, borderRadius: 12, overflow: 'hidden', borderWidth: 1, borderColor: C.line },
  note: { fontSize: 12.5, color: C.muted, marginTop: 8 },
});
