import React from 'react';
import { Text, StyleSheet } from 'react-native';
import { useStyles } from '../theme';
import { isNew } from '../api/tools';

// Same rule as the website: "New" = added within the last 14 days.
export default function NewChip({ tool, style }) {
  const s = useStyles(makeStyles);
  if (!isNew(tool)) return null;
  return <Text style={[s.chip, style]}>New</Text>;
}
const makeStyles = (C) => StyleSheet.create({
  chip: { fontSize: 11, fontWeight: '700', color: C.text, borderWidth: 1, borderColor: C.text, borderRadius: 999,
    paddingHorizontal: 7, paddingVertical: 1, marginRight: 6, overflow: 'hidden' },
});
