import AsyncStorage from '@react-native-async-storage/async-storage';

// Anonymous usage counts. No personal data, no IP storage: the Worker keeps only daily aggregate counters.
// Batched and fire-and-forget; silently drops events when offline.
const URL_ = 'https://agentscout-image.agentscouthq.workers.dev/track';
const ID_KEY = 'agentscout_install_id';
let Q = [], timer = null;

function flush() {
  timer = null;
  if (!Q.length) return;
  const events = Q.splice(0, 50);
  fetch(URL_, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-AgentScout-App': '1' },
    body: JSON.stringify({ source: 'app', events }) }).catch(() => {});
}
export function track(e, k, q) {
  const ev = { e };
  if (k) ev.k = String(k).slice(0, 80);
  if (q) ev.q = String(q).toLowerCase().trim().slice(0, 60);
  Q.push(ev);
  if (!timer) timer = setTimeout(flush, 3000);
}
// app_first_open (install proxy): a random id saved once; only its absence is used, it is never sent.
export async function trackOpen() {
  try {
    const id = await AsyncStorage.getItem(ID_KEY);
    if (!id) {
      const rnd = Date.now().toString(36) + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
      await AsyncStorage.setItem(ID_KEY, rnd);
      track('app_first_open');
    }
  } catch (e) {}
  track('app_open');
}
let st = null;
export function trackSearch(q, now) {
  clearTimeout(st);
  const v = String(q || '').trim();
  if (v.length < 2) return;
  if (now) track('search', null, v); else st = setTimeout(() => track('search', null, v), 1500);
}
