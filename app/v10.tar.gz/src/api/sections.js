import AsyncStorage from '@react-native-async-storage/async-storage';

// Site sections published by the website build (api/sections.json) and the daily generator art manifest.
export const SITE = 'https://clampdown-web.github.io/agentscout/';
const KEY = 'agentscout_sections_v1';
let MEM = null;

export async function getSections(force = false) {
  if (MEM && !force) return MEM;
  try {
    const r = await fetch(SITE + 'api/sections.json?t=' + Math.floor(Date.now() / 300000), { cache: 'no-cache' });
    if (!r.ok) throw new Error('sections ' + r.status);
    MEM = await r.json();
    AsyncStorage.setItem(KEY, JSON.stringify(MEM)).catch(() => {});
    return MEM;
  } catch (e) {
    const c = await AsyncStorage.getItem(KEY).catch(() => null);
    if (c) { MEM = JSON.parse(c); return MEM; }
    throw e;
  }
}

// Same live manifest the website's generate.js reads; short cache-bust so a new day shows on launch/refresh.
export async function getGeneratorDaily() {
  const r = await fetch(SITE + 'api/generator-daily.json?t=' + Math.floor(Date.now() / 300000), { cache: 'no-cache' });
  if (!r.ok) throw new Error('daily ' + r.status);
  return r.json();
}

// Daily Editor's Pick (api/editors-pick.json), last good copy kept for offline use.
export async function getEditorsPick() {
  try {
    const r = await fetch(SITE + 'api/editors-pick.json?t=' + Math.floor(Date.now() / 300000), { cache: 'no-cache' });
    if (!r.ok) throw new Error('pick ' + r.status);
    const j = await r.json();
    AsyncStorage.setItem('agentscout_pick_v1', JSON.stringify(j)).catch(() => {});
    return j;
  } catch (e) {
    const c = await AsyncStorage.getItem('agentscout_pick_v1').catch(() => null);
    if (c) return JSON.parse(c);
    throw e;
  }
}
