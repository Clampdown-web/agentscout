import { useEffect, useState } from 'react';
import { getFavorites, subscribeFavorites } from './tools';

// Live list of saved tool ids; re-renders whenever any heart is toggled.
export default function useFavorites() {
  const [favs, setFavs] = useState([]);
  useEffect(() => {
    let on = true;
    getFavorites().then((f) => on && setFavs(f));
    const off = subscribeFavorites((f) => on && setFavs(f));
    return () => { on = false; off(); };
  }, []);
  return favs;
}
