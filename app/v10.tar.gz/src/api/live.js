import { getTools } from './tools';
import { getSections } from './sections';

// Live refresh bus: App.js calls refreshAll() on launch and whenever the app returns to the foreground;
// screens subscribe with onLive() and re-read their data. Last good copies stay in AsyncStorage for offline use.
const L = new Set();
export function onLive(fn) { L.add(fn); return () => L.delete(fn); }
let busy = false;
export async function refreshAll() {
  if (busy) return; busy = true;
  try { await Promise.allSettled([getTools(true), getSections(true)]); } finally { busy = false; }
  L.forEach((fn) => { try { fn(); } catch (e) {} });
}
