// Exact port of the website's /quiz-score.js, so the same answers give the same ranking as /quiz.html.
// Questions and weights come live from api/quiz.json. Tools may be raw feed rows or normalized app tools.
export const QUIZ_URL = 'https://clampdown-web.github.io/agentscout/api/quiz.json';
export const SITE_QUIZ = 'https://clampdown-web.github.io/agentscout/quiz.html';

export async function getQuiz() {
  const r = await fetch(QUIZ_URL + '?t=' + Date.now(), { cache: 'no-cache' });
  if (!r.ok) throw new Error('quiz ' + r.status);
  return r.json();
}

export function score(t, a, quiz) {
  var W = quiz.weights, s = 0;
  var g = (quiz.questions[0].options || []).filter(function (o) { return o.id === a.goal; })[0];
  if (g) {
    if (g.categories.indexOf(t.category) >= 0) s += W.goal.category;
    if ((t.goals || []).some(function (x) { return g.goals.indexOf(x) >= 0; })) s += W.goal.goals;
    if (!s && W.goal.requireMatch) return -1;
  }
  var sk = t.skill === 'no-code' ? 'no-code' : 'developer';
  if (W.skill[a.skill]) s += W.skill[a.skill][sk] || 0;
  var p = t.price_tag || t.priceTag || 'unknown';
  if (W.budget[a.budget]) s += W.budget[a.budget][p] || 0;
  if (W.oss[a.oss]) s += W.oss[a.oss][t.github ? 'github' : 'none'];
  if (t.weekly_pick || t.weeklyPick) s += W.bonus.weekly_pick;
  if (t.logo) s += W.bonus.logo;
  return s;
}

export function rank(tools, a, quiz) {
  var max = (quiz.results && quiz.results.max) || 8;
  return tools.map(function (t, i) { return { t: t, s: score(t, a, quiz), i: i }; })
    .filter(function (x) { return x.s > 0; })
    .sort(function (x, y) { return y.s - x.s || x.i - y.i; })
    .slice(0, max).map(function (x) { return x.t; });
}

export function shareUrl(a, quiz) {
  const h = quiz.questions.filter((q) => a[q.key]).map((q) => q.key + '=' + encodeURIComponent(a[q.key])).join('&');
  return SITE_QUIZ + (h ? '#' + h : '');
}
