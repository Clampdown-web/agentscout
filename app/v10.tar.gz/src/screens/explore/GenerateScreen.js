import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, Image, ImageBackground, StyleSheet, ActivityIndicator, useWindowDimensions } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { useScrollButtons } from '../../components/ScrollButtons';
import { useTheme, useStyles } from '../../theme';
import { getGeneratorDaily } from '../../api/sections';
import { track } from '../../api/analytics';

// Mirrors generate.html + generate.js: same headings, prompt row, example chips, 45s cooldown, Worker endpoint,
// error/rate-limit messages, lavender result panel and notes. The card background is the same live daily art
// (api/generator-daily.json, which the site also reads) under the same flat 50% (light) / 55% (dark) overlay.
const WORKER_URL = 'https://agentscout-image.agentscouthq.workers.dev/generate';
const EX = ['A friendly robot agent sorting a toolbox of glowing app icons', 'A team of tiny AI agents building a website, isometric illustration',
  'A coding agent typing at a futuristic terminal, neon blue', 'A voice AI assistant as a glowing sound wave character', 'An AI browser agent surfing the web on a paper airplane'];
const SH = ['Robot toolbox', 'Tiny agents', 'Neon coder', 'Voice wave', 'Paper plane'];
const COOL = 45000, KEY = 'as_ig_last';

export default function GenerateScreen() {
  const { C, isDark } = useTheme();
  const s = useStyles(makeStyles);
  const { width } = useWindowDimensions();
  const ref = useRef(null);
  const scroll = useScrollButtons(ref);
  const [daily, setDaily] = useState(null);
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const [left, setLeft] = useState(0);
  const [img, setImg] = useState(null);
  const [saveMsg, setSaveMsg] = useState('');

  useEffect(() => { getGeneratorDaily().then(setDaily).catch(() => {}); }, []);
  useEffect(() => {
    let t;
    const tick = async () => {
      const l = +(await AsyncStorage.getItem(KEY)) || 0;
      const r = Math.max(0, COOL - (Date.now() - l));
      setLeft(r);
      if (r > 0) t = setTimeout(tick, 1000);
    };
    tick();
    return () => clearTimeout(t);
  }, [busy]);

  const generate = async () => {
    const p = q.trim().slice(0, 300);
    if (!p || busy || left > 0) return;
    setBusy(true); setSaveMsg(''); setStatus('Generating… this usually takes a few seconds.');
    await AsyncStorage.setItem(KEY, String(Date.now()));
    try {
      const r = await fetch(WORKER_URL, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-AgentScout-App': '1' }, body: JSON.stringify({ prompt: p, turnstileToken: '' }) });
      const ct = r.headers.get('Content-Type') || '';
      if (!(r.ok && /^image\//.test(ct))) {
        let j = {}; try { j = await r.json(); } catch (e) {}
        throw new Error(j.error || (r.status === 429 ? "Today's free images are used up. Please try again tomorrow." : 'Image generation failed. Please try again shortly.'));
      }
      const bytes = new Uint8Array(await r.arrayBuffer());
      const f = new File(Paths.cache, 'agentscout-image-' + Date.now() + '.jpg');
      f.create(); f.write(bytes);
      setImg(f.uri); setStatus(''); track('image_generate');
    } catch (e) {
      setStatus(e.message && e.message !== 'Network request failed' ? e.message : 'The generator is unavailable right now. Please try again later.');
    }
    setBusy(false);
  };
  const save = async () => {
    if (!img) return;
    if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(img, { mimeType: 'image/jpeg', dialogTitle: 'Save image' });
    else setSaveMsg('Sharing isn’t available on this device.');
  };

  const statusText = busy ? status : left > 0 ? 'Next image in ' + Math.ceil(left / 1000) + 's' : status;
  const overlay = daily ? (isDark ? daily.overlay.dark : daily.overlay.light) : (isDark ? 'rgba(37,38,77,0.55)' : 'rgba(239,239,254,0.5)');
  const base = isDark ? '#25264D' : '#EFEFFE';
  const imgW = Math.min(width - 32 - 26 - 20, 760);

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <ScrollView ref={ref} {...scroll.listProps} keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ padding: 16, paddingBottom: scroll.padBottom, alignItems: 'center' }}>
        <View style={s.col}>
          <Text style={s.h1}>Free AI Image Generator: No Sign-up</Text>
          <Text style={s.lede}>Describe an image and generate it. Try one of the AI agent prompts below.</Text>
          <View style={[s.card, { backgroundColor: base }]}>
            <ImageBackground source={daily ? { uri: daily.image } : null} resizeMode="cover" style={StyleSheet.absoluteFill} />
            <View style={[StyleSheet.absoluteFill, { backgroundColor: overlay }]} />
            <Text style={s.h2}>✨ Free AI Image Generator</Text>
            <View style={s.row}>
              <TextInput style={s.input} value={q} onChangeText={setQ} maxLength={300} placeholder="Describe an image…"
                placeholderTextColor={C.faint} returnKeyType="go" onSubmitEditing={generate} accessibilityLabel="Prompt" />
              <TouchableOpacity style={[s.btn, (busy || left > 0 || !q.trim()) && s.btnOff]} onPress={generate}
                disabled={busy || left > 0} accessibilityRole="button">
                {busy ? <ActivityIndicator color={C.bg} size="small" /> : <Text style={s.btnText}>Generate</Text>}
              </TouchableOpacity>
            </View>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 6 }} keyboardShouldPersistTaps="handled">
              {EX.map((e, i) => (
                <TouchableOpacity key={i} style={s.ex} onPress={() => setQ(e)} accessibilityLabel={e}>
                  <Text style={s.exText}>{SH[i]}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            {statusText ? <Text style={s.status} accessibilityLiveRegion="polite">{statusText}</Text> : null}
            {img ? (
              <View style={s.out}>
                <Image source={{ uri: img }} style={{ width: imgW, height: imgW, borderRadius: 10, backgroundColor: C.accentSoft }} accessibilityLabel="Generated image" />
                <Text style={s.outLinks}><Text style={s.link} onPress={save}>Download</Text> · <Text style={s.link} onPress={save}>Share</Text></Text>
                {saveMsg ? <Text style={s.status}>{saveMsg}</Text> : null}
              </View>
            ) : null}
            <Text style={s.cardNote} numberOfLines={1}>FLUX.1 [schnell], Apache 2.0 · free to use · keep it SFW</Text>
          </View>
          <Text style={s.note}><Text style={{ fontWeight: '700' }}>Free, no sign-up.</Text> Images are made with FLUX.1 [schnell], which is Apache 2.0 licensed, so you can use the images you create however you like.</Text>
          <Text style={s.note}>Free demo powered by Cloudflare Workers AI (FLUX.1 schnell). Limited to about 150 images a day across all visitors; if it's used up, try again tomorrow.</Text>
          <Text style={s.note}>Content policy: keep prompts safe for work. No sexual, hateful, violent or illegal content, and no images of real people. A safety filter is on, and some prompts are refused.</Text>
        </View>
      </ScrollView>
      {scroll.buttons}
    </View>
  );
}

const makeStyles = (C) => StyleSheet.create({
  col: { width: '100%', maxWidth: 760 },
  h1: { fontSize: 28, fontWeight: '800', color: C.text, textAlign: 'center', marginBottom: 6, lineHeight: 34 },
  lede: { fontSize: 16, color: C.muted, textAlign: 'center', marginBottom: 14, lineHeight: 23 },
  card: { borderWidth: 1, borderColor: C.accent, borderRadius: 12, paddingVertical: 10, paddingHorizontal: 12, overflow: 'hidden' },
  h2: { fontSize: 15, fontWeight: '700', color: C.accentText },
  row: { flexDirection: 'row', marginTop: 8 },
  input: { flex: 1, minWidth: 0, fontSize: 15, paddingVertical: 7, paddingHorizontal: 10, borderWidth: 1, borderColor: C.line, borderRadius: 9, backgroundColor: C.card, color: C.text },
  btn: { marginLeft: 6, backgroundColor: C.text, borderWidth: 1, borderColor: C.text, borderRadius: 8, paddingHorizontal: 14, justifyContent: 'center', minWidth: 92, alignItems: 'center' },
  btnOff: { opacity: 0.6 },
  btnText: { color: C.bg, fontWeight: '500', fontSize: 15 },
  ex: { borderWidth: 1, borderColor: C.line, backgroundColor: C.card, borderRadius: 8, paddingHorizontal: 9, paddingVertical: 3, marginRight: 6 },
  exText: { fontSize: 12, color: C.text },
  status: { fontSize: 12.5, color: C.muted, marginTop: 4 },
  out: { marginTop: 8, backgroundColor: C.accentSoft, borderWidth: 1, borderColor: 'rgba(91,91,247,0.15)', borderRadius: 14, padding: 10 },
  outLinks: { marginTop: 4, fontSize: 13, color: C.muted },
  link: { color: C.accentText, fontWeight: '600' },
  cardNote: { fontSize: 11, color: C.muted, marginTop: 6 },
  note: { fontSize: 13, color: C.muted, lineHeight: 19, marginTop: 10 },
});
