import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, TextInput, ScrollView, TouchableOpacity, Image, StyleSheet, Linking, RefreshControl, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { refreshAll } from '../../api/live';
import { toggleFavorite, fmtDate } from '../../api/tools';
import useFavorites from '../../api/useFavorites';
import { track } from '../../api/analytics';
import { useScrollButtons } from '../../components/ScrollButtons';
import { useTheme, useStyles } from '../../theme';
import { useSections, Loading, rowStyles } from './common';

// Explore > Compare: "Compare any two tools" picker (type-ahead over live api/tools.json) above the 14 written matchups.
// Same fields and behaviour as the picker at the top of compare/index.html on the website.

function Picker({ label, tools, value, onPick, s, C }) {
  const [q, setQ] = useState(value ? value.name : '');
  const [open, setOpen] = useState(false);
  useEffect(() => { setQ(value ? value.name : ''); }, [value && value.id]);
  const hits = useMemo(() => {
    const v = q.trim().toLowerCase();
    const list = v ? tools.filter((t) => t.name.toLowerCase().includes(v) || t.id.includes(v))
      .sort((a, b) => a.name.toLowerCase().indexOf(v) - b.name.toLowerCase().indexOf(v)) : tools;
    return list.slice(0, 6);
  }, [q, tools]);
  return (
    <View style={{ flex: 1, minWidth: 0 }}>
      <Text style={s.label}>{label}</Text>
      <View style={s.inputWrap}>
        <Ionicons name="search" size={16} color={C.faint} />
        <TextInput style={s.input} value={q} placeholder="Type a tool name" placeholderTextColor={C.faint}
          onChangeText={(t) => { setQ(t); setOpen(true); if (value) onPick(null); }} onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)} autoCorrect={false} autoCapitalize="none" accessibilityLabel={label} />
        {q ? <TouchableOpacity hitSlop={8} onPress={() => { setQ(''); onPick(null); setOpen(true); }} accessibilityLabel={'Clear ' + label}>
          <Ionicons name="close-circle" size={18} color={C.faint} /></TouchableOpacity> : null}
      </View>
      {open && !value ? (
        <View style={s.drop}>
          {hits.length ? hits.map((t) => (
            <TouchableOpacity key={t.id} style={s.opt} onPress={() => { onPick(t); setQ(t.name); setOpen(false); }} accessibilityRole="button">
              <Logo t={t} s={s} size={24} />
              <View style={{ flex: 1, marginLeft: 10 }}>
                <Text style={s.optName} numberOfLines={1}>{t.name}</Text>
                <Text style={s.optCat} numberOfLines={1}>{t.category}</Text>
              </View>
            </TouchableOpacity>
          )) : <Text style={[s.optCat, { padding: 10 }]}>No match</Text>}
        </View>
      ) : null}
    </View>
  );
}

function Logo({ t, s, size = 28 }) {
  return (
    <View style={[s.logoBox, { width: size + 8, height: size + 8 }]}>
      {t.logo ? <Image source={{ uri: t.logo }} style={{ width: size, height: size, borderRadius: 6 }} resizeMode="contain" />
        : <Text style={s.letter}>{(t.name || '?')[0].toUpperCase()}</Text>}
    </View>
  );
}

export default function CompareIndexScreen({ navigation, route }) {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  const rs = useStyles(rowStyles);
  const { data, tools, err } = useSections();
  const favs = useFavorites();
  const { width } = useWindowDimensions();
  const tablet = width >= 600;
  const ref = useRef(null);
  const scroll = useScrollButtons(ref);
  const [rf, setRf] = useState(false);
  const sorted = useMemo(() => [...tools].sort((a, b) => a.name.localeCompare(b.name)), [tools]);
  const by = useMemo(() => Object.fromEntries(tools.map((t) => [t.id, t])), [tools]);
  const [aId, setA] = useState(route.params?.a || '');
  const [bId, setB] = useState(route.params?.b || '');
  const [shown, setShown] = useState(null); // [aId, bId] of the table on screen
  useEffect(() => { if (route.params?.a) setA(route.params.a); }, [route.params?.a]);
  const A = by[aId] || null, B = by[bId] || null;

  if (!data) return <Loading err={err} />;

  const go = (a = aId, b = bId) => {
    if (!by[a] || !by[b] || a === b) return;
    setShown([a, b]); track('compare_pick', a + ':' + b);
    setTimeout(() => ref.current && ref.current.scrollTo && ref.current.scrollTo({ y: 0, animated: true }), 0);
  };
  const swap = () => { setA(bId); setB(aId); if (shown) setShown([bId, aId]); };
  const RA = shown && by[shown[0]], RB = shown && by[shown[1]];
  const match = RA && RB ? data.compare.find((c) => (c.a === RA.id && c.b === RB.id) || (c.a === RB.id && c.b === RA.id)) : null;
  const ready = A && B && A.id !== B.id;

  const rows = RA && RB ? [
    ['Category', (t) => <Text style={s.chip}>{t.category}</Text>],
    ['Pricing', (t) => t.pricing],
    ['Open source', (t) => (t.openSource ? 'Yes' + (t.license ? ' (' + t.license + ')' : '') : 'No')],
    ['License', (t) => t.license || (t.openSource ? 'See repo' : '–')],
    ['GitHub stars', (t) => (t.stars ? t.stars.toLocaleString('en-US') : '–')],
    ['Description', (t) => t.description],
    ['Best for', (t) => { const g = t.tags.length ? t.tags : t.goals; return g.length ? <View style={s.chips}>{g.map((x) => <Text key={x} style={s.tag}>{x}</Text>)}</View> : '–'; }],
    ['Added', (t) => (t.added ? fmtDate(t.added) : '–')],
    ['Links', (t) => (
      <View style={s.chips}>
        {(t.website || t.url) ? <TouchableOpacity style={s.linkBtn} onPress={() => { track('outbound_link', t.id + ':website'); Linking.openURL(t.website || t.url); }}>
          <Ionicons name="globe-outline" size={14} color={C.accentText} /><Text style={s.linkText}>Website</Text></TouchableOpacity> : null}
        {t.github ? <TouchableOpacity style={s.linkBtn} onPress={() => { track('outbound_link', t.id + ':github'); Linking.openURL(t.github); }}>
          <Ionicons name="logo-github" size={14} color={C.accentText} /><Text style={s.linkText}>GitHub</Text></TouchableOpacity> : null}
      </View>
    )],
  ] : [];
  const cell = (v) => (typeof v === 'string' ? <Text style={s.td}>{v}</Text> : v);
  const Head = ({ t }) => {
    const fav = favs.includes(t.id);
    return (
      <View style={s.headCell}>
        <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', flex: 1, minWidth: 0 }} onPress={() => navigation.push('ToolDetail', { tool: t })}>
          <Logo t={t} s={s} size={tablet ? 28 : 22} />
          <Text style={s.headName} numberOfLines={2}>{t.name}</Text>
        </TouchableOpacity>
        <TouchableOpacity hitSlop={10} onPress={() => toggleFavorite(t.id)} accessibilityLabel={fav ? 'Remove ' + t.name + ' from saved' : 'Save ' + t.name}>
          <Ionicons name={fav ? 'heart' : 'heart-outline'} size={20} color={fav ? C.heart : C.faint} />
        </TouchableOpacity>
      </View>
    );
  };
  const labW = 150;

  const children = [
    <View key="picker" style={s.card}>
      <Text style={s.h2}>Compare any two tools</Text>
      <Text style={s.lede}>Pick any two of the {tools.length} tools in the directory and see them side by side.</Text>
      <View style={tablet ? s.pickRowT : null}>
        <Picker label="Tool A" tools={sorted} value={A} onPick={(t) => setA(t ? t.id : '')} s={s} C={C} />
        <TouchableOpacity style={[s.swap, tablet ? { marginTop: 22 } : null]} onPress={swap} accessibilityLabel="Swap tools">
          <Ionicons name={tablet ? 'swap-horizontal' : 'swap-vertical'} size={20} color={C.accentText} />
        </TouchableOpacity>
        <Picker label="Tool B" tools={sorted} value={B} onPick={(t) => setB(t ? t.id : '')} s={s} C={C} />
      </View>
      <TouchableOpacity style={[s.go, !ready && { opacity: 0.5 }]} disabled={!ready} onPress={() => go()} accessibilityRole="button">
        <Ionicons name="git-compare-outline" size={18} color={C.onAccent} /><Text style={s.goText}>Compare</Text>
      </TouchableOpacity>
      {A && B && A.id === B.id ? <Text style={[s.lede, { marginTop: 8, marginBottom: 0 }]}>Pick two different tools.</Text> : null}
    </View>,
  ];
  let sticky = [];
  if (RA && RB) {
    if (match) children.push(
      <TouchableOpacity key="match" style={s.match} onPress={() => navigation.navigate('CompareDetail', { cmp: match })}>
        <Text style={s.matchText}>We have a written comparison for this pair: <Text style={{ fontWeight: '800' }}>{match.title} →</Text></Text>
      </TouchableOpacity>);
    sticky = [children.length];
    children.push(
      <View key="head" style={[s.thead, s.tableTop]}>
        {tablet ? <View style={{ width: labW }} /> : null}
        <Head t={RA} /><Head t={RB} />
      </View>);
    children.push(
      <View key="body" style={s.tableBody}>
        {rows.map(([l, f], i) => tablet ? (
          <View key={l} style={[s.tr, i % 2 ? s.alt : null]}>
            <Text style={[s.th, { width: labW }]}>{l}</Text>
            <View style={s.tdBox}>{cell(f(RA))}</View><View style={s.tdBox}>{cell(f(RB))}</View>
          </View>
        ) : (
          <View key={l} style={[s.trP, i % 2 ? s.alt : null]}>
            <Text style={s.thP}>{l}</Text>
            <View style={{ flexDirection: 'row' }}>
              <View style={s.tdBox}>{cell(f(RA))}</View><View style={s.tdBox}>{cell(f(RB))}</View>
            </View>
          </View>
        ))}
      </View>);
    children.push(<Text key="disc" style={s.disc}>Facts come from our directory listings. Check each official site for current pricing.</Text>);
  }
  children.push(<Text key="mh" style={[s.h2, { marginTop: 18, marginBottom: 4 }]}>Written comparisons</Text>);
  children.push(<Text key="ml" style={rs.lede}>{data.compare.length + ' side-by-side comparisons.'}</Text>);
  data.compare.forEach((c) => children.push(
    <TouchableOpacity key={c.slug} style={rs.row} onPress={() => navigation.navigate('CompareDetail', { cmp: c })} accessibilityRole="button">
      <View style={{ flex: 1 }}>
        <Text style={rs.title}>{c.title}</Text>
        <Text style={rs.sub} numberOfLines={2}>{(c.rows.find((r) => r[0] === 'Category') || [])[1]}</Text>
      </View>
      <Ionicons name="chevron-forward" size={18} color={C.faint} style={{ marginLeft: 8 }} />
    </TouchableOpacity>));

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <ScrollView ref={ref} {...scroll.listProps} stickyHeaderIndices={sticky} keyboardShouldPersistTaps="handled"
        refreshControl={<RefreshControl refreshing={rf} onRefresh={() => { setRf(true); refreshAll().finally(() => setRf(false)); }} colors={[C.accent]} tintColor={C.accent} />}
        contentContainerStyle={{ padding: 16, paddingBottom: scroll.padBottom, maxWidth: 1000, width: '100%', alignSelf: 'center' }}>
        {children}
      </ScrollView>
      {scroll.buttons}
    </View>
  );
}

const makeStyles = (C) => StyleSheet.create({
  card: { backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 14, padding: 16, marginBottom: 14 },
  h2: { fontSize: 19, fontWeight: '700', color: C.text },
  lede: { fontSize: 14, color: C.muted, lineHeight: 20, marginTop: 4, marginBottom: 12 },
  label: { fontSize: 12.5, color: C.muted, marginBottom: 4 },
  inputWrap: { flexDirection: 'row', alignItems: 'center', height: 44, borderWidth: 1, borderColor: C.line, borderRadius: 10, paddingHorizontal: 10, backgroundColor: C.bg },
  input: { flex: 1, marginLeft: 8, fontSize: 15, color: C.text, height: 44 },
  drop: { marginTop: 4, borderWidth: 1, borderColor: C.line, borderRadius: 10, backgroundColor: C.card, padding: 4 },
  opt: { flexDirection: 'row', alignItems: 'center', padding: 8, borderRadius: 8 },
  optName: { fontSize: 14.5, fontWeight: '600', color: C.text },
  optCat: { fontSize: 12, color: C.muted },
  pickRowT: { flexDirection: 'row', alignItems: 'flex-start' },
  swap: { alignSelf: 'center', width: 44, height: 40, borderRadius: 10, borderWidth: 1, borderColor: C.line, alignItems: 'center', justifyContent: 'center', marginVertical: 8, marginHorizontal: 10, backgroundColor: C.soft },
  go: { marginTop: 14, height: 48, borderRadius: 12, backgroundColor: C.accent, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  goText: { color: C.onAccent, fontSize: 16, fontWeight: '700', marginLeft: 8 },
  match: { backgroundColor: C.accentSoft, borderRadius: 12, padding: 12, marginBottom: 12 },
  matchText: { color: C.accentText, fontSize: 14, lineHeight: 20 },
  tableTop: { borderWidth: 1, borderColor: C.line, borderTopLeftRadius: 12, borderTopRightRadius: 12 },
  thead: { flexDirection: 'row', backgroundColor: C.card, paddingVertical: 4 },
  tableBody: { borderWidth: 1, borderTopWidth: 0, borderColor: C.line, borderBottomLeftRadius: 12, borderBottomRightRadius: 12, overflow: 'hidden', backgroundColor: C.card },
  headCell: { flex: 1, flexDirection: 'row', alignItems: 'center', padding: 8, minWidth: 0 },
  headName: { flex: 1, marginLeft: 8, fontSize: 14.5, fontWeight: '700', color: C.text },
  logoBox: { borderRadius: 8, backgroundColor: C.accentSoft, alignItems: 'center', justifyContent: 'center' },
  letter: { fontSize: 14, fontWeight: '800', color: C.accentText },
  tr: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: C.line },
  trP: { borderTopWidth: 1, borderTopColor: C.line, paddingTop: 8 },
  alt: { backgroundColor: C.soft },
  th: { padding: 10, fontSize: 13, fontWeight: '500', color: C.faint },
  thP: { paddingHorizontal: 10, fontSize: 11.5, fontWeight: '600', letterSpacing: 0.5, textTransform: 'uppercase', color: C.faint },
  tdBox: { flex: 1, padding: 10, minWidth: 0 },
  td: { fontSize: 13.5, color: C.text, lineHeight: 19 },
  chips: { flexDirection: 'row', flexWrap: 'wrap' },
  chip: { alignSelf: 'flex-start', fontSize: 12, fontWeight: '600', color: C.accentText, backgroundColor: C.accentSoft, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 2, overflow: 'hidden', textTransform: 'capitalize' },
  tag: { fontSize: 11.5, color: C.muted, backgroundColor: C.soft, borderWidth: 1, borderColor: C.line, borderRadius: 6, paddingHorizontal: 7, paddingVertical: 2, marginRight: 4, marginBottom: 4, overflow: 'hidden' },
  linkBtn: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: C.line, borderRadius: 8, paddingHorizontal: 9, paddingVertical: 6, marginRight: 6, marginBottom: 6, backgroundColor: C.card },
  linkText: { marginLeft: 5, fontSize: 13, fontWeight: '600', color: C.accentText },
  disc: { fontSize: 12.5, color: C.muted, marginTop: 8 },
});
