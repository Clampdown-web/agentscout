import React, { useRef } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image, StyleSheet, useWindowDimensions } from 'react-native';
import { useScrollButtons } from '../../components/ScrollButtons';
import { useTheme, useStyles } from '../../theme';
import { useSections } from './common';

// Side-by-side table + verdict, from compare/*.html via api/sections.json.
export default function CompareDetailScreen({ route, navigation }) {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  const { cmp } = route.params;
  const { tools } = useSections();
  const by = Object.fromEntries(tools.map((t) => [t.id, t]));
  const A = by[cmp.a], B = by[cmp.b];
  const [na, nb] = cmp.title.split(' vs ');
  const { width } = useWindowDimensions();
  const labW = width >= 600 ? 170 : 104;
  const ref = useRef(null);
  const scroll = useScrollButtons(ref);
  const Head = ({ t, n }) => (
    <TouchableOpacity style={s.headCell} disabled={!t} onPress={() => navigation.navigate('ToolDetail', { tool: t })}>
      {t && t.logo ? <Image source={{ uri: t.logo }} style={s.logo} /> : null}
      <Text style={s.headName}>{n}</Text>
    </TouchableOpacity>
  );
  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <ScrollView ref={ref} {...scroll.listProps} contentContainerStyle={{ padding: 16, paddingBottom: scroll.padBottom }}>
        <Text style={s.h1}>{cmp.title}</Text>
        <Text style={s.lede}>{cmp.verdict}</Text>
        <View style={s.table}>
          <View style={[s.tr, s.thead]}>
            <View style={{ width: labW }} />
            <Head t={A} n={na} /><Head t={B} n={nb} />
          </View>
          {cmp.rows.map((r, i) => (
            <View key={r[0]} style={[s.tr, i % 2 ? s.alt : null]}>
              <Text style={[s.th, { width: labW }]}>{r[0]}</Text>
              <Text style={s.td}>{r[1]}</Text>
              <Text style={s.td}>{r[2]}</Text>
            </View>
          ))}
        </View>
        {cmp.note ? <Text style={s.note}>{cmp.note}</Text> : null}
      </ScrollView>
      {scroll.buttons}
    </View>
  );
}

const makeStyles = (C) => StyleSheet.create({
  h1: { fontSize: 24, fontWeight: '800', color: C.text, marginBottom: 6 },
  lede: { fontSize: 15, color: C.muted, lineHeight: 22, marginBottom: 14 },
  table: { borderWidth: 1, borderColor: C.line, borderRadius: 12, overflow: 'hidden', backgroundColor: C.card },
  tr: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: C.line },
  thead: { borderTopWidth: 0, backgroundColor: C.soft },
  alt: { backgroundColor: C.soft },
  headCell: { flex: 1, padding: 10, alignItems: 'flex-start' },
  logo: { width: 28, height: 28, borderRadius: 6, marginBottom: 6 },
  headName: { fontSize: 14, fontWeight: '700', color: C.accentText },
  th: { padding: 10, fontSize: 13, fontWeight: '600', color: C.text },
  td: { flex: 1, padding: 10, fontSize: 13, color: C.text, lineHeight: 18 },
  note: { fontSize: 13, color: C.muted, marginTop: 12, lineHeight: 19 },
});
