import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { useStyles } from '../../theme';

// free-tools.html: free tools built by AgentScout.
export default function FreeToolsScreen({ navigation }) {
  const s = useStyles(makeStyles);
  return (
    <ScrollView style={s.screen} contentContainerStyle={{ padding: 16 }}>
      <Text style={s.h1}>Free tools</Text>
      <Text style={s.lede}>Free tools built by AgentScout. No sign-up needed.</Text>
      <View style={s.card}>
        <View style={s.row}><View style={s.ico}><Text style={{ fontSize: 20 }}>✨</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={s.name}>AI Image Generator</Text>
            <View style={s.badges}><Text style={[s.b, s.free]}>Free</Text><Text style={[s.b, s.cat]}>image</Text></View>
          </View>
        </View>
        <Text style={s.hook}>Type a prompt and get an image in seconds. Powered by FLUX.1 [schnell].</Text>
        <TouchableOpacity style={s.btn} onPress={() => navigation.navigate('Generate')} accessibilityRole="button"><Text style={s.btnText}>Open</Text></TouchableOpacity>
      </View>
    </ScrollView>
  );
}
const makeStyles = (C) => StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  h1: { fontSize: 24, fontWeight: '800', color: C.text },
  lede: { fontSize: 15, color: C.muted, marginTop: 6, marginBottom: 14 },
  card: { backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 12, padding: 16, maxWidth: 420 },
  row: { flexDirection: 'row', alignItems: 'center' },
  ico: { width: 40, height: 40, borderRadius: 10, backgroundColor: C.accentSoft, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  name: { fontSize: 16, fontWeight: '700', color: C.text },
  badges: { flexDirection: 'row', marginTop: 4 },
  b: { fontSize: 11.5, fontWeight: '600', borderRadius: 999, paddingHorizontal: 8, paddingVertical: 2, marginRight: 6, overflow: 'hidden' },
  free: { color: C.newText, backgroundColor: C.newBg },
  cat: { color: C.accentText, backgroundColor: C.accentSoft },
  hook: { fontSize: 14, color: C.muted, lineHeight: 20, marginTop: 10 },
  btn: { alignSelf: 'flex-start', marginTop: 12, height: 38, paddingHorizontal: 16, borderRadius: 8, backgroundColor: C.text, justifyContent: 'center' },
  btnText: { color: C.bg, fontWeight: '500' },
});
