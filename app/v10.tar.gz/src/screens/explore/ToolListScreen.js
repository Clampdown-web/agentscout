import React, { useMemo, useRef , useState } from 'react';
import { View, Text, FlatList, useWindowDimensions, RefreshControl } from 'react-native';
import ToolCard from '../../components/ToolCard';
import { refreshAll } from '../../api/live';
import { useScrollButtons } from '../../components/ScrollButtons';
import { useTheme, useStyles } from '../../theme';
import { useSections, Loading, rowStyles } from './common';

// Generic tool list for a category, task or best-of list. params: { title, lede, category?, slugs? }
export default function ToolListScreen({ route, navigation }) {
  const { C } = useTheme();
  const s = useStyles(rowStyles);
  const { tools } = useSections();
  const { lede, category, slugs } = route.params || {};
  const { width } = useWindowDimensions();
  const cols = width >= 700 ? 2 : 1;
  const ref = useRef(null);
  const scroll = useScrollButtons(ref);
  const [rf, setRf] = useState(false);
  const list = useMemo(() => {
    if (category) return tools.filter((t) => t.category === category);
    if (slugs) { const by = Object.fromEntries(tools.map((t) => [t.id, t])); return slugs.map((x) => by[x]).filter(Boolean); }
    return tools;
  }, [tools, category, slugs]);
  if (!tools.length) return <Loading />;
  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <FlatList ref={ref} {...scroll.listProps} refreshControl={<RefreshControl refreshing={rf} onRefresh={() => { setRf(true); refreshAll().finally(() => setRf(false)); }} colors={[C.accent]} tintColor={C.accent} />} key={'c' + cols} numColumns={cols} data={list} keyExtractor={(t) => t.id}
        columnWrapperStyle={cols > 1 ? { gap: 10 } : undefined}
        contentContainerStyle={{ padding: 16, paddingBottom: scroll.padBottom }}
        ListHeaderComponent={<Text style={s.lede}>{lede ? lede + ' · ' : ''}{list.length} tools</Text>}
        renderItem={({ item }) => <ToolCard tool={item} style={cols > 1 ? { flex: 1 } : null} onPress={() => navigation.navigate('ToolDetail', { tool: item })} />} />
      {scroll.buttons}
    </View>
  );
}
