import React, { useRef } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme, useStyles } from '../../theme';
import { useScrollButtons } from '../../components/ScrollButtons';
import { SafeAreaView } from 'react-native-safe-area-context';
import ThemeToggle from '../../components/ThemeToggle';
import { track } from '../../api/analytics';

// Hub for every website section. 2 columns on phones, 3 on tablets, 4 on wide tablets.
export const TILES = [
  { key: 'Categories', icon: 'albums-outline', label: 'Categories', sub: 'Browse by type' },
  { key: 'Tasks', icon: 'checkbox-outline', label: 'Tasks', sub: 'Agents by job' },
  { key: 'CompareIndex', icon: 'git-compare-outline', label: 'Compare', sub: '14 matchups' },
  { key: 'Best', icon: 'trophy-outline', label: 'Best', sub: 'Lists & MCP/Cursor guides' },
  { key: 'News', icon: 'newspaper-outline', label: 'News', sub: 'Agent news' },
  { key: 'Generate', icon: 'color-wand-outline', label: 'Image Gen', sub: 'Free AI images' },
  { key: 'Newsletter', icon: 'mail-outline', label: 'Newsletter', sub: 'Weekly picks' },
  { key: 'Quiz', icon: 'help-circle-outline', label: 'Quiz', sub: 'Find your agent' },
  { key: 'Submit', icon: 'add-circle-outline', label: 'Submit a tool', sub: 'Get listed' },
  { key: 'NewTools', icon: 'sparkles-outline', label: 'New tools', sub: 'Last 30 days' },
  { key: 'FreeTools', icon: 'gift-outline', label: 'Free tools', sub: 'Built by AgentScout' },
  { key: 'Badges', icon: 'ribbon-outline', label: 'Maker badges', sub: 'Embed a badge' },
];

const TRACKED = { Submit: 'submit', Quiz: 'quiz', Newsletter: 'newsletter', CompareIndex: 'compare', Generate: 'generate' };
export function openTile(navigation, key) {
  if (TRACKED[key]) track('button_click', TRACKED[key]);
  if (key === 'Quiz') navigation.navigate('Main', { screen: 'Saved' });
  else navigation.navigate(key);
}

export default function ExploreScreen({ navigation }) {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  const { width } = useWindowDimensions();
  const cols = width >= 1000 ? 4 : width >= 600 ? 3 : 2;
  const ref = useRef(null);
  const scroll = useScrollButtons(ref);
  const gap = 10, tileW = (width - 32 - gap * (cols - 1)) / cols;
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.bg }} edges={['top']}>
      <View style={s.titleRow}><Text style={s.title}>Explore</Text><ThemeToggle /></View>
      <ScrollView ref={ref} contentContainerStyle={{ padding: 16, paddingBottom: scroll.padBottom }} {...scroll.listProps}>
        <Text style={s.lede}>Everything on the AgentScout website, in the app.</Text>
        <View style={s.grid}>
          {TILES.map((t, i) => (
            <TouchableOpacity key={t.key} style={[s.tile, { width: tileW, marginRight: (i + 1) % cols ? gap : 0 }]}
              onPress={() => openTile(navigation, t.key)} accessibilityRole="button" accessibilityLabel={t.label}>
              <View style={s.icon}><Ionicons name={t.icon} size={24} color={C.accentText} /></View>
              <Text style={s.label} numberOfLines={1}>{t.label}</Text>
              <Text style={s.sub} numberOfLines={1}>{t.sub}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
      {scroll.buttons}
    </SafeAreaView>
  );
}

const makeStyles = (C) => StyleSheet.create({
  titleRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 16 },
  title: { flex: 1, fontSize: 22, fontWeight: '800', color: C.text },
  lede: { fontSize: 14, color: C.muted, marginBottom: 12 },
  grid: { flexDirection: 'row', flexWrap: 'wrap' },
  tile: { backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 14, padding: 14, marginBottom: 10, minHeight: 112 },
  icon: { width: 42, height: 42, borderRadius: 12, backgroundColor: C.accentSoft, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  label: { fontSize: 15, fontWeight: '700', color: C.text },
  sub: { fontSize: 12.5, color: C.muted, marginTop: 2 },
});
