import React, { useState } from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { useTheme, useStyles } from '../../theme';
import { SITE } from '../../api/sections';

// badges.html: the four badges plus copy-ready HTML / Markdown snippets (same text as the site).
const KINDS = [['listed', 'Listed', 'for any tool in the directory.'], ['featured', 'Featured', "for tools we've picked as featured."]];
const html = (k, v) => `<a href="${SITE}" target="_blank" rel="noopener noreferrer"><img src="${SITE}badges/${k}-${v}.svg" alt="${k === 'featured' ? 'Featured' : 'Listed'} on AgentScout" width="220" height="54"></a>`;
const md = (k, v) => `[![${k === 'featured' ? 'Featured' : 'Listed'} on AgentScout](${SITE}badges/${k}-${v}.svg)](${SITE})`;

export default function BadgesScreen() {
  const s = useStyles(makeStyles);
  const [copied, setCopied] = useState('');
  const copy = async (id, text) => { await Clipboard.setStringAsync(text); setCopied(id); setTimeout(() => setCopied(''), 1800); };
  return (
    <ScrollView style={s.screen} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <Text style={s.h1}>Badges for makers</Text>
      <Text style={s.lede}>If your tool is on AgentScout, you can show it. Badges are free and link to your tool's page, so readers can see how it compares.</Text>
      <Text style={s.h2}>How to embed</Text>
      <Text style={s.p}>1. Pick a badge and a light or dark version.{'\n'}2. Tap Copy HTML (for websites) or Copy Markdown (for a GitHub README).{'\n'}3. Paste it where you want the badge to appear.</Text>
      {KINDS.map(([k, label, desc]) => (
        <View key={k} style={s.card}>
          <Text style={s.p}><Text style={{ fontWeight: '700' }}>{label}</Text>: {desc}</Text>
          {['light', 'dark'].map((v) => (
            <View key={v} style={s.variant}>
              <Image source={{ uri: `${SITE}badges/${k}-${v}.png` }} style={s.badge} resizeMode="contain" accessibilityLabel={`${label} on AgentScout (${v})`} />
              <View style={s.btnRow}>
                {[['HTML', html(k, v)], ['Markdown', md(k, v)]].map(([t, val]) => {
                  const id = k + v + t;
                  return (
                    <TouchableOpacity key={t} style={s.btn} onPress={() => copy(id, val)} accessibilityRole="button">
                      <Text style={s.btnText}>{copied === id ? 'Copied' : 'Copy ' + t}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
              <Text style={s.code} selectable numberOfLines={3}>{md(k, v)}</Text>
            </View>
          ))}
        </View>
      ))}
    </ScrollView>
  );
}
const makeStyles = (C) => StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  h1: { fontSize: 24, fontWeight: '800', color: C.text },
  lede: { fontSize: 15, color: C.muted, lineHeight: 22, marginTop: 6 },
  h2: { fontSize: 17, fontWeight: '700', color: C.text, marginTop: 18, marginBottom: 6 },
  p: { fontSize: 14, color: C.text, lineHeight: 21 },
  card: { backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 14, padding: 14, marginTop: 14 },
  variant: { marginTop: 12 },
  badge: { width: 220, height: 54 },
  btnRow: { flexDirection: 'row', marginTop: 8 },
  btn: { height: 36, paddingHorizontal: 14, borderRadius: 8, borderWidth: 1, borderColor: C.line, backgroundColor: C.card, justifyContent: 'center', marginRight: 8 },
  btnText: { color: C.text, fontWeight: '500', fontSize: 13.5 },
  code: { fontSize: 11.5, color: C.muted, marginTop: 6, fontFamily: 'monospace' },
});
