import React from 'react';
import { ScrollView, View } from 'react-native';
import NewsletterSection from '../../components/NewsletterSection';
import { useTheme } from '../../theme';

export default function NewsletterScreen() {
  const { C } = useTheme();
  return (
    <ScrollView style={{ backgroundColor: C.bg }} contentContainerStyle={{ padding: 16 }}>
      <View style={{ backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 14 }}>
        <NewsletterSection initiallyOpen />
      </View>
    </ScrollView>
  );
}
