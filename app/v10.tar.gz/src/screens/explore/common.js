import React, { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, StyleSheet } from 'react-native';
import { getSections } from '../../api/sections';
import { getTools } from '../../api/tools';
import { onLive } from '../../api/live';
import { useTheme } from '../../theme';

export function useSections() {
  const [data, setData] = useState(null);
  const [tools, setTools] = useState([]);
  const [err, setErr] = useState('');
  useEffect(() => {
    getSections().then(setData).catch(() => setErr("Couldn't load. Check your connection."));
    getTools().then(setTools).catch(() => {});
    return onLive(() => { getSections().then(setData).catch(() => {}); getTools().then(setTools).catch(() => {}); });
  }, []);
  return { data, tools, err };
}

export function Loading({ err }) {
  const { C } = useTheme();
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: C.bg, padding: 24 }}>
      {err ? <Text style={{ color: C.muted }}>{err}</Text> : <ActivityIndicator color={C.accent} size="large" />}
    </View>
  );
}

export const headerOpts = (C, title) => ({ title, headerTintColor: C.accentText, headerStyle: { backgroundColor: C.card }, headerTitleStyle: { color: C.text } });

export const rowStyles = (C) => StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 14, padding: 14, marginBottom: 10 },
  title: { fontSize: 15.5, fontWeight: '700', color: C.text },
  sub: { fontSize: 13, color: C.muted, marginTop: 3, lineHeight: 18 },
  count: { fontSize: 12, fontWeight: '600', color: C.accentText, backgroundColor: C.accentSoft, borderRadius: 999, paddingHorizontal: 9, paddingVertical: 3, overflow: 'hidden', marginLeft: 10 },
  lede: { fontSize: 14, color: C.muted, lineHeight: 20, marginBottom: 12 },
});
