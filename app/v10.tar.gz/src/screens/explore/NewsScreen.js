import React, { useRef , useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, RefreshControl } from 'react-native';
import { refreshAll } from '../../api/live';
import { useScrollButtons } from '../../components/ScrollButtons';
import { useTheme, useStyles } from '../../theme';
import { useSections, Loading } from './common';
import { fmtDate } from '../../api/tools';

// news.html items (news.json via api/sections.json). Tapping a story with a listed tool opens that tool.
export default function NewsScreen({ navigation }) {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  const { data, tools, err } = useSections();
  const ref = useRef(null);
  const scroll = useScrollButtons(ref);
  const [rf, setRf] = useState(false);
  if (!data) return <Loading err={err} />;
  const by = Object.fromEntries(tools.map((t) => [t.id, t]));
  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <FlatList ref={ref} {...scroll.listProps} refreshControl={<RefreshControl refreshing={rf} onRefresh={() => { setRf(true); refreshAll().finally(() => setRf(false)); }} colors={[C.accent]} tintColor={C.accent} />} data={data.news} keyExtractor={(n, i) => n.url || String(i)}
        contentContainerStyle={{ padding: 16, paddingBottom: scroll.padBottom }}
        ListHeaderComponent={<Text style={s.lede}>Agent news, updated daily.</Text>}
        ListEmptyComponent={<Text style={s.lede}>No news right now.</Text>}
        renderItem={({ item }) => {
          const t = item.tool && by[item.tool];
          return (
            <TouchableOpacity style={s.card} disabled={!t} onPress={() => navigation.navigate('ToolDetail', { tool: t })}>
              <Text style={s.meta}>{fmtDate((item.date || '').slice(0, 10))} · {item.source}</Text>
              <Text style={s.title}>{item.title}</Text>
              <Text style={s.sum}>{item.summary}</Text>
              {t ? <Text style={s.tool}>See {t.name} →</Text> : null}
            </TouchableOpacity>
          );
        }} />
      {scroll.buttons}
    </View>
  );
}
const makeStyles = (C) => StyleSheet.create({
  lede: { fontSize: 14, color: C.muted, marginBottom: 12 },
  card: { backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 14, padding: 16, marginBottom: 10 },
  meta: { fontSize: 12, color: C.muted, marginBottom: 4 },
  title: { fontSize: 16, fontWeight: '700', color: C.text, lineHeight: 22 },
  sum: { fontSize: 14, color: C.muted, lineHeight: 20, marginTop: 6 },
  tool: { fontSize: 13.5, fontWeight: '700', color: C.accentText, marginTop: 8 },
});
