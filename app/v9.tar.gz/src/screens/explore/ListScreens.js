import React, { useRef , useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, RefreshControl } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { refreshAll } from '../../api/live';
import { useScrollButtons } from '../../components/ScrollButtons';
import { useTheme, useStyles } from '../../theme';
import { useSections, Loading, rowStyles } from './common';

function Rows({ items, render, header, onPress }) {
  const { C } = useTheme();
  const s = useStyles(rowStyles);
  const ref = useRef(null);
  const scroll = useScrollButtons(ref);
  const [rf, setRf] = useState(false);
  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <FlatList ref={ref} {...scroll.listProps} refreshControl={<RefreshControl refreshing={rf} onRefresh={() => { setRf(true); refreshAll().finally(() => setRf(false)); }} colors={[C.accent]} tintColor={C.accent} />} data={items} keyExtractor={(x, i) => x.slug || String(i)}
        contentContainerStyle={{ padding: 16, paddingBottom: scroll.padBottom }}
        ListHeaderComponent={header ? <Text style={s.lede}>{header}</Text> : null}
        renderItem={({ item }) => {
          const r = render(item);
          return (
            <TouchableOpacity style={s.row} onPress={() => onPress(item)} accessibilityRole="button">
              <View style={{ flex: 1 }}>
                <Text style={s.title}>{r.title}</Text>
                {r.sub ? <Text style={s.sub} numberOfLines={2}>{r.sub}</Text> : null}
              </View>
              {r.count != null ? <Text style={s.count}>{r.count}</Text> : null}
              <Ionicons name="chevron-forward" size={18} color={C.faint} style={{ marginLeft: 8 }} />
            </TouchableOpacity>
          );
        }} />
      {scroll.buttons}
    </View>
  );
}

export function CategoriesScreen({ navigation }) {
  const { data, err } = useSections();
  if (!data) return <Loading err={err} />;
  return <Rows items={data.categories} header={data.categories.length + ' categories, same as the website.'}
    render={(c) => ({ title: c.name.charAt(0).toUpperCase() + c.name.slice(1), count: c.count })}
    onPress={(c) => navigation.navigate('ToolList', { title: c.name.charAt(0).toUpperCase() + c.name.slice(1), category: c.name })} />;
}

export function TasksScreen({ navigation }) {
  const { data, err } = useSections();
  if (!data) return <Loading err={err} />;
  return <Rows items={data.tasks} header="AI agents grouped by the job you want done."
    render={(t) => ({ title: t.title, sub: t.description, count: t.tools.length })}
    onPress={(t) => navigation.navigate('ToolList', { title: t.title, lede: t.description, slugs: t.tools })} />;
}

export function BestScreen({ navigation }) {
  const { data, err } = useSections();
  if (!data) return <Loading err={err} />;
  return <Rows items={data.best} header="Curated best-of lists from the directory."
    render={(b) => ({ title: b.title, sub: b.lede, count: b.tools.length })}
    onPress={(b) => navigation.navigate('ToolList', { title: b.title, lede: '', slugs: b.tools })} />;
}

export { default as CompareIndexScreen } from './CompareIndexScreen';
