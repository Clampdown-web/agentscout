import React, { useRef, useEffect, useMemo, useState } from 'react';
import { View, Text, SectionList, ScrollView, Image, TouchableOpacity, StyleSheet, ActivityIndicator, TextInput, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { getTools, newest, isNew } from '../api/tools';
import ToolCard from '../components/ToolCard';
import { useTheme, useStyles } from '../theme';
import CheckedPill from '../components/CheckedPill';
import ThemeToggle, { useBarSize } from '../components/ThemeToggle';
import { track, trackSearch } from '../api/analytics';
import { onLive } from '../api/live';
import { useScrollButtons } from '../components/ScrollButtons';

const PRICES = ['Any price', 'Free', 'Freemium', 'Paid'];
const SORTS = ['By category', 'Newest first', 'New only'];

export default function BrowseScreen({ navigation }) {
  const { C } = useTheme();
  const s = useStyles(makeStyles);
  const listRef = useRef(null);
  const [tools, setTools] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cat, setCat] = useState('All');
  const [price, setPrice] = useState('Any price');
  const [sort, setSort] = useState('By category');
  const [query, setQuery] = useState('');
  const bar = useBarSize();

  const [refreshing, setRefreshing] = useState(false);
  useEffect(() => { getTools().then(setTools).catch(() => {}).finally(() => setLoading(false)); return onLive(() => getTools().then(setTools).catch(() => {})); }, []);
  const onRefresh = () => { setRefreshing(true); getTools(true).then(setTools).catch(() => {}).finally(() => setRefreshing(false)); };

  const cats = useMemo(() => ['All', ...[...new Set(tools.map((t) => t.category))].sort()], [tools]);

  const sections = useMemo(() => {
    const q = query.trim().toLowerCase();
    const keep = (t) => (!q || (t.name + ' ' + t.description + ' ' + t.category).toLowerCase().includes(q)) && (cat === 'All' || t.category === cat) && (price === 'Any price' || t.priceTag === price.toLowerCase())
      && (sort !== 'New only' || isNew(t));
    if (sort !== 'By category') {
      const list = newest(tools).filter(keep);
      return list.length ? [{ title: sort === 'New only' ? 'New (last 14 days)' : 'Newest first', data: list }] : [];
    }
    const groups = {};
    tools.filter(keep).forEach((t) => {
      (groups[t.category] = groups[t.category] || []).push(t);
    });
    // New tools first inside each category, like the website's category pages
    return Object.keys(groups).sort().map((k) => ({ title: k, data: [...groups[k]].sort((a, b) => (isNew(b) - isNew(a)) || (isNew(a) ? (b.added || '').localeCompare(a.added || '') : 0)) }));
  }, [tools, cat, price, sort, query]);
  const scroll = useScrollButtons(listRef, { sections });

  if (loading) return <View style={s.loading}><ActivityIndicator size="large" color={C.accent} /></View>;

  const Chips = ({ items, value, onChange }) => (
    <View style={s.chipBar}><ScrollView horizontal style={{ flexGrow: 0 }} showsHorizontalScrollIndicator={false} contentContainerStyle={s.chips}>
      {items.map((c) => (
        <TouchableOpacity key={c} onPress={() => onChange(c)} style={[s.chip, value === c && s.chipOn]}>
          <Text style={[s.chipText, value === c && s.chipTextOn]}>{c}</Text>
        </TouchableOpacity>
      ))}
    </ScrollView></View>
  );

  return (
    <SafeAreaView style={s.screen} edges={['top']}>
      <View style={s.titleRow}>
        <Text style={[s.h1, { flex: 1 }]}>All Tools <Text style={s.count}>{tools.length} tools</Text></Text>
      </View>
      <View style={s.searchRow}>
        <View style={[s.search, { height: bar.size }]}>
          <Ionicons name="search" size={18} color={C.faint} />
          <TextInput style={s.input} placeholder={"Search " + tools.length + " AI agent tools"} placeholderTextColor={C.faint}
            value={query} onChangeText={(v) => { setQuery(v); trackSearch(v); }} onSubmitEditing={() => trackSearch(query, true)} returnKeyType="search" autoCorrect={false} accessibilityLabel="Search tools" />
          {query ? <Ionicons name="close-circle" size={18} color={C.faint} onPress={() => setQuery('')} /> : null}
        </View>
        <ThemeToggle />
      </View>
      <CheckedPill count={tools.length} align="left" style={{ marginTop: 6 }} />
      <Chips items={SORTS} value={sort} onChange={setSort} />
      <Chips items={PRICES} value={price} onChange={setPrice} />
      <Chips items={cats} value={cat} onChange={setCat} />
      <SectionList
        ref={listRef}
        {...scroll.listProps}
        sections={sections}
        keyExtractor={(t) => t.id}
        stickySectionHeadersEnabled={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[C.accent]} tintColor={C.accent} />}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: scroll.padBottom }}
        ListEmptyComponent={<Text style={s.empty}>No tools match these filters.</Text>}
        renderSectionHeader={({ section }) => (
          <Text style={s.section}>{section.title} · {section.data.length}</Text>
        )}
        renderItem={({ item }) => <ToolCard tool={item} onPress={() => navigation.navigate('ToolDetail', { tool: item })} />}
      />
      {scroll.buttons}
    </SafeAreaView>
  );
}

const makeStyles = (C) => StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: C.bg },
  explore: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 16, marginTop: 10, padding: 12, borderRadius: 12, backgroundColor: C.accentSoft },
  exploreText: { flex: 1, marginLeft: 10, color: C.accentText, fontWeight: '600', fontSize: 13.5 },
  searchRow: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 16, marginTop: 10 },
  search: { flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: 10, paddingHorizontal: 12, borderWidth: 1, borderColor: C.line },
  input: { flex: 1, marginLeft: 8, fontSize: 15, color: C.text },
  titleRow: { flexDirection: 'row', alignItems: 'center' },
  h1: { fontSize: 22, fontWeight: '800', color: C.text, paddingHorizontal: 16, paddingTop: 16 },
  chipBar: { height: 40, marginTop: 8 },
  chips: { paddingHorizontal: 16, alignItems: 'center' },
  chip: { height: 30, justifyContent: 'center', alignSelf: 'center', paddingHorizontal: 12, borderRadius: 999, backgroundColor: C.card,
    marginRight: 8, borderWidth: 1, borderColor: C.line },
  chipOn: { backgroundColor: C.accent, borderColor: C.accent },
  chipText: { fontSize: 13, color: C.text, fontWeight: '600', textTransform: 'capitalize' },
  chipTextOn: { color: C.onAccent },
  section: { fontSize: 16, fontWeight: '700', color: C.text, marginTop: 18, marginBottom: 8, textTransform: 'capitalize' },
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: 14, padding: 12,
    marginBottom: 8, borderWidth: 1, borderColor: C.line },
  icon: { width: 44, height: 44, borderRadius: 12, backgroundColor: C.accentSoft, alignItems: 'center',
    justifyContent: 'center', marginRight: 12 },
  img: { width: 28, height: 28, borderRadius: 6 },
  letter: { fontSize: 20, fontWeight: '800', color: C.accentText },
  name: { fontSize: 15, fontWeight: '700', color: C.text },
  desc: { fontSize: 12, color: C.muted, marginTop: 2 },
  price: { fontSize: 11, fontWeight: '700', color: C.accentText, backgroundColor: C.accentSoft, paddingHorizontal: 8,
    paddingVertical: 3, borderRadius: 8, marginHorizontal: 8, overflow: 'hidden', textTransform: 'capitalize' },
  count: { fontSize: 14, fontWeight: '600', color: C.muted },
  empty: { textAlign: 'center', color: C.muted, marginTop: 40 },
});
